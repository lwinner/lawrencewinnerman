// A site's own drawing (decision 0019, relay entry 55): a site moving onto Heliostet with its look as
// it is keeps its own frame (the page around the parts: head, masthead, footer) and its own variants
// of Heliostet's parts, each an Astro component in its repository, named in astro.config.mjs:
//
//   heliostet({ own: { frame: 'src/press/Frame.astro', variants: { 'list:press-latest': 'src/press/Latest.astro' } } })
//
// Heliostet still owns the rest: the content, the addresses, the pages as data, the site check. A
// variant is checked against its part's fields like any other; one marked { title: true } draws the
// page's main heading, for a page whose header is its first part.

import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { isPartType, PARTS } from '../parts/registry.js';
import type { Pager } from '../parts/types.js';

export interface OwnOptions {
  frame?: string;
  variants?: Record<string, string | { component: string; title?: boolean }>;
}

/** What the site's frame is given for each page it draws. */
export interface OwnPage {
  /** This page's address: on page 2 of a list, /latest/2. */
  address: string;
  /** The page file's address: /latest. */
  base: string;
  title: string;
  eyebrow?: string;
  intro?: string;
  seo?: { title?: string; description?: string; shareImage?: string; noindex?: boolean; graph?: string; type?: string };
  /** The page file's (or template's) frameOptions. */
  options: Record<string, string | number | boolean>;
  pager?: Pager;
  /** On a collection's page, its item: the collection, the address, the route's parameters, and the bound fields. */
  entry?: { collection: string; address: string; params: Record<string, string>; title: string; description: string; fields: Record<string, unknown> };
}

export interface OwnFrameProps {
  page: OwnPage;
}

export class OwnDrawingError extends Error {
  override name = 'OwnDrawingError';
}

const KEY = /^([a-z-]+):([a-z0-9]+(?:-[a-z0-9]+)*)$/;

/** The site's own variants, checked: each names a part, isn't one of Heliostet's variants, and its file is there. */
export function ownVariantList(root: URL, own: OwnOptions | undefined): { key: string; file: string; title: boolean }[] {
  return Object.entries(own?.variants ?? {}).map(([key, value]) => {
    const m = KEY.exec(key);
    if (!m) throw new OwnDrawingError(`The own variant “${key}” is named "part:variant", in lowercase with hyphens: list:press-latest.`);
    const [, type, variant] = m as unknown as [string, string, string];
    if (!isPartType(type)) throw new OwnDrawingError(`The own variant “${key}” names no part: there’s no part called “${type}.”`);
    if (PARTS[type].variants.some((v) => v.id === variant)) throw new OwnDrawingError(`The own variant “${key}” has the name of one of Heliostet’s; give it the site’s own: ${type}:<site>-${variant}.`);
    const component = typeof value === 'string' ? value : value.component;
    const file = new URL(component, root);
    if (!existsSync(file)) throw new OwnDrawingError(`The own variant “${key}” is drawn by ${component}, which isn’t there.`);
    return { key, file: fileURLToPath(file), title: typeof value === 'object' && value.title === true };
  });
}

const modulePath = (file: string) => JSON.stringify(file.replace(/\\/g, '/'));

/** The module SitePage and SiteEntry import the site's own frame from. It's a module of its own, apart from the
 *  variants, so a page that leaves the frame (ownFrame: false) carries none of the frame's stylesheet: Astro bundles a
 *  page's CSS by what its route imports. */
export function ownFrameModuleCode(root: URL, own: OwnOptions | undefined): string {
  if (!own?.frame) return 'export const OwnFrame = null;';
  const frame = new URL(own.frame, root);
  if (!existsSync(frame)) throw new OwnDrawingError(`The site’s own frame is ${own.frame}, which isn’t there.`);
  return `import OwnFrameComponent from ${modulePath(fileURLToPath(frame))};\nexport const OwnFrame = OwnFrameComponent;`;
}

/** The module Part, SitePage, and SiteEntry import the site's own variants from. */
export function ownModuleCode(root: URL, own: OwnOptions | undefined): string {
  const variants = ownVariantList(root, own);
  const path = modulePath;
  const lines: string[] = [];
  variants.forEach((v, i) => lines.push(`import Own${i} from ${path(v.file)};`));
  lines.push(`export const ownVariants = { ${variants.map((v, i) => `${JSON.stringify(v.key)}: Own${i}`).join(', ')} };`);
  return lines.join('\n');
}
