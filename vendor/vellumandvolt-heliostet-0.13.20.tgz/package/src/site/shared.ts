// Parts shared across pages (relay entry 53, section 3). A shared part placed "right" or "left"
// goes at the end of the page's first run with that side on, so it closes that column; a page with
// that side off everywhere doesn't show it. "band-end" is a band after the page's last row, before
// the footer. Each page keeps a shared part (the default), hides it, or replaces it; a page that
// places one itself, as { "shared": "<id>" } in any slot, shows it there and only there.

import type { LayoutRow } from './layout.js';
import type { PlacedPart, SharedFile } from './schema.js';

type Choice = 'keep' | 'hide' | { replace: PlacedPart };
type AnyPart = PlacedPart | { shared: string } | ({ bind: 'item' } & Omit<PlacedPart, 'type'> & { type: string });

/** The page's rows with its shared parts in place, and every { shared } reference filled in. */
export function withShared<P extends AnyPart>(rows: LayoutRow<P>[], shared: SharedFile, choices: Record<string, Choice>): LayoutRow<Exclude<P, { shared: string }>>[] {
  type Out = Exclude<P, { shared: string }>;
  const byId = new Map(shared.parts.map((s) => [s.id, s]));
  const placedHere = new Set<string>();
  const partFor = (id: string): Out | null => {
    const entry = byId.get(id);
    const choice = choices[id] ?? 'keep';
    if (!entry || choice === 'hide') return null;
    return (typeof choice === 'object' ? choice.replace : entry.part) as Out;
  };
  const fill = (parts: P[]): Out[] =>
    parts.flatMap((p) => {
      if ('shared' in p) {
        placedHere.add(p.shared);
        const part = partFor(p.shared);
        return part ? [part] : [];
      }
      return [p as Out];
    });
  const out: LayoutRow<Out>[] = rows.map((r) => ({
    id: r.id,
    join: r.join,
    // A row's background goes with it (relay entry 113).
    ...((r as { band?: string }).band ? { band: (r as { band?: string }).band } : {}),
    // So does its place in the section above it (the kit fidelity entry).
    ...((r as { tight?: boolean }).tight ? { tight: true } : {}),
    main: fill(r.main),
    left: { on: r.left.on, parts: fill(r.left.parts) },
    right: { on: r.right.on, parts: fill(r.right.parts) },
  }));

  for (const entry of shared.parts) {
    if (placedHere.has(entry.id)) continue;
    const part = partFor(entry.id);
    if (!part) continue;
    if (entry.place === 'band-end') {
      out.push({ id: `shared-${entry.id}`, join: true, main: [part], left: { on: false, parts: [] }, right: { on: false, parts: [] } });
      continue;
    }
    const side = entry.place;
    const first = out.findIndex((r) => r[side].on);
    if (first < 0) continue;
    // The end of that first run: the rows after it that keep the side on and join it.
    let last = first;
    while (out[last + 1]?.[side].on && out[last + 1]?.join) last += 1;
    out[last]![side].parts.push(part);
  }
  return out;
}
