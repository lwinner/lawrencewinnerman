// What the parts' components share: a link's address and words, a query run against the site's
// content, dates in house style, prices, and a store's products. Nothing here reaches the browser.

import type { ImageValue, QueryValue } from './fields.js';
import type { ContentItem, LinkValue, PartContext, ShopifyProduct, Store } from './types.js';

/** A link field's value as an address and its words, or null when it's empty. */
export function linkOf(value: unknown): LinkValue | null {
  if (typeof value === 'string') return value ? { to: value } : null;
  if (value && typeof value === 'object' && typeof (value as LinkValue).to === 'string') return value as LinkValue;
  return null;
}

/** An address that leaves the site opens as itself; a page on the site does not. */
export const external = (to: string) => /^https?:\/\//.test(to);

export function imageOf(value: unknown): ImageValue | null {
  const v = value as ImageValue | null | undefined;
  return v && typeof v.src === 'string' && v.src ? v : null;
}

export const textOf = (value: unknown): string => (typeof value === 'string' ? value : '');

const ESCAPES: Record<string, string> = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

/**
 * Short text as HTML: everything escaped, and emphasis the only formatting a short text allows,
 * so a book title can be italic per Chicago (relay entry 53): *Light Shines Through*.
 */
export function em(value: unknown): string {
  return textOf(value)
    .replace(/[&<>"']/g, (c) => ESCAPES[c] ?? c)
    .replace(/\*([^*\n]+)\*/g, '<em>$1</em>');
}

/** Short text with its emphasis marks taken out, for an attribute or an accessible name. */
export const plain = (value: unknown): string => textOf(value).replace(/\*([^*\n]+)\*/g, '$1');
export const listOf = (value: unknown): string[] => (Array.isArray(value) ? value.filter((v): v is string => typeof v === 'string' && Boolean(v.trim())) : []);
export const groupOf = (value: unknown): Record<string, unknown>[] => (Array.isArray(value) ? value.filter((v): v is Record<string, unknown> => typeof v === 'object' && v !== null) : []);

const KIND: Record<QueryValue['source'], ContentItem['kind']> = { stories: 'story', chapters: 'chapter', episodes: 'episode', videos: 'video' };

/** Every item a query matches, in its order, before its count and skip. */
export function queryMatches(query: QueryValue | undefined, ctx: PartContext): ContentItem[] {
  if (!query) return [];
  const f = query.filters ?? {};
  // A byline filter names a person or a principal, and finds every item they're bylined on, first or not.
  const byline = (item: ContentItem) => item.byline === f.byline || (item.bylines ?? []).includes(f.byline!) || (item.people ?? []).includes(f.byline!);
  const found = ctx.items.filter(
    (item) =>
      item.kind === KIND[query.source] &&
      (!f.outlet || item.outlet === f.outlet) &&
      (!f.topic || (item.topics ?? []).includes(f.topic)) &&
      (!f.series || item.series === f.series) &&
      (!f.byline || byline(item)) &&
      (!f.tag || (item.tags ?? []).includes(f.tag)),
  );
  return query.sort === 'order' ? found : [...found].sort((a, b) => (query.sort === 'oldest' ? a.date.localeCompare(b.date) : b.date.localeCompare(a.date)));
}

/**
 * A query run against the site's content: its source, its filters, its order, its count, after any
 * it skips. On a list over numbered pages, page 2 is the count after page 1's, and on (relay entry 55).
 */
export function runQuery(query: QueryValue | undefined, ctx: PartContext, page = 1): ContentItem[] {
  if (!query) return [];
  const start = (query.skip ?? 0) + (page - 1) * query.count;
  return queryMatches(query, ctx).slice(start, start + query.count);
}

/** How many numbered pages a list runs over: at least one, even with nothing on it yet. */
export function pagesOf(query: QueryValue, ctx: PartContext): number {
  return Math.max(1, Math.ceil(Math.max(0, queryMatches(query, ctx).length - (query.skip ?? 0)) / query.count));
}

/** Page n of a list at an address: the address itself, then /2, /3, and on. */
export function pageAddress(address: string, n: number): string {
  return n === 1 ? address : `${address === '/' ? '' : address}/${n}`;
}

// Chicago's month abbreviations: May, June, and July aren't shortened, and September is "Sept."
const MONTHS = ['Jan.', 'Feb.', 'March', 'April', 'May', 'June', 'July', 'Aug.', 'Sept.', 'Oct.', 'Nov.', 'Dec.'];

function partsOf(iso: string, timeZone: string): { y: number; m: number; d: number } {
  // A bare day (2026-10-20) is that day wherever the reader is.
  if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) {
    const [y, m, d] = iso.split('-').map(Number) as [number, number, number];
    return { y, m: m - 1, d };
  }
  const p = new Intl.DateTimeFormat('en-US', { timeZone, year: 'numeric', month: 'numeric', day: 'numeric' }).formatToParts(new Date(iso));
  const get = (t: string) => Number(p.find((x) => x.type === t)?.value ?? 0);
  return { y: get('year'), m: get('month') - 1, d: get('day') };
}

/** "Oct. 23, 2026," or "Oct. 23" with year: false. */
export function shortDate(iso: string, timeZone: string, year = true): string {
  const { y, m, d } = partsOf(iso, timeZone);
  return `${MONTHS[m]} ${d}${year ? `, ${y}` : ''}`;
}

const MONTHS_LONG = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

/** "October 21, 2026": a story card's date (relay entry 59). */
export function longDate(iso: string, timeZone: string): string {
  const { y, m, d } = partsOf(iso, timeZone);
  return `${MONTHS_LONG[m]} ${d}, ${y}`;
}

/** The ISO day, for a time element. */
export function isoDay(iso: string, timeZone: string): string {
  const { y, m, d } = partsOf(iso, timeZone);
  return `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

/** "$34," or "$34.50" when there are cents. */
export function price(amount: string): string {
  const n = Number(amount);
  return Number.isFinite(n) ? `$${Number.isInteger(n) ? n : n.toFixed(2)}` : amount;
}

/** The store a part names, from the client record. */
export const storeOf = (name: string, ctx: PartContext): Store | null => ctx.stores.find((s) => s.name === name) ?? null;

/** A product's page on its store. */
export const productUrl = (store: Store, p: ShopifyProduct) => `${store.url.replace(/\/$/, '')}/products/${encodeURIComponent(p.handle)}`;

/**
 * The products a merch part shows, in its order. A sold-out product is skipped, replaced by the
 * store's next one that isn't already shown, or empties the part, as the part says.
 */
export function productsFor(store: Store, handles: string[], whenSoldOut: string): ShopifyProduct[] {
  const inStock = (p: ShopifyProduct) => p.variants.some((v) => v.available);
  const picked = handles.map((h) => store.products.find((p) => p.handle === h)).filter((p): p is ShopifyProduct => Boolean(p));
  if (picked.every(inStock)) return picked;
  if (whenSoldOut === 'hide') return [];
  const shown = picked.filter(inStock);
  if (whenSoldOut === 'next') {
    const spare = store.products.filter((p) => inStock(p) && !picked.includes(p));
    return [...shown, ...spare.slice(0, picked.length - shown.length)];
  }
  return shown;
}

/** Where an address is, by name, for "Read on Substack." */
export function platformOf(to: string): string | null {
  const host = /^https?:\/\/([^/]+)/.exec(to)?.[1]?.toLowerCase() ?? '';
  if (host.endsWith('substack.com')) return 'Substack';
  if (host.endsWith('medium.com')) return 'Medium';
  if (host.endsWith('youtube.com') || host === 'youtu.be') return 'YouTube';
  return null;
}
