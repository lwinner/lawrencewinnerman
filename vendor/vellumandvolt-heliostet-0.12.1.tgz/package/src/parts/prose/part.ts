// Prose: written text under an optional heading.
import { link, rich, text } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const prose: PartDefinition = {
  type: 'prose',
  name: 'Prose',
  what: 'Written text.',
  schema: {
    heading: text('Heading', 80, 'A heading above the text. Optional.'),
    body: rich('Text', 20000, 'The text, with headings, links, lists, and emphasis.', true),
    eyebrow: text('Kicker', 60, 'A word or two above the heading. Optional.'),
    action: link('Button', 'A button under the text, and its words. Optional.'),
    secondAction: link('Second button', 'A second button beside the first, and its words. Optional.'),
    liveFor: text('Live while', 80, 'A show’s name, as the shows feed names it: the band shows Live Now while it’s on air. Optional.'),
  },
  variants: [
    { id: 'normal', label: 'Normal' },
    { id: 'wide', label: 'Wide' },
    { id: 'section', label: 'Section: a heading and text, set as a front page sets them' },
    { id: 'section-wide', label: 'Section, full width' },
    { id: 'header', label: 'Page header' },
    { id: 'title-and-body', label: 'Title over paragraphs' },
    { id: 'paragraphs', label: 'Paragraphs' },
    { id: 'meta', label: 'A small line' },
    { id: 'band', label: 'Band: a kicker and a large title beside a line and buttons, with Live Now while a show is on' },
    { id: 'notes', label: 'Notes: short notes side by side, each a heading and its paragraph' },
    { id: 'page-body', label: 'A Markdown page’s body' },
    { id: 'table', label: 'A table' },
    // Relay entry 57: the Press's sections, drawn in its look.
    { id: 'not-found', label: 'Not found: a dateline, a large title, a line, and two buttons, for a page that isn’t there' },
    // Relay entry 59.
    { id: 'intro', label: 'Intro: a kicker, a large title, and a lede, to open a page' },
    { id: 'columns', label: 'Columns: the text in two columns, split by a rule (---)' },
  ],
  component: 'prose/Prose.astro',
  fixtures: [
    {
      type: 'prose',
      variant: 'normal',
      fields: {
        heading: 'Work With Me',
        body: 'I take on a small number of engagements as projects, retainers, or advisory hours, for technology companies and independent media. Clients stay confidential.',
      },
    },
    // Relay entry 59: two columns, the satire label set in italics.
    {
      type: 'prose',
      variant: 'columns',
      fields: {
        body: '## The Receipts\n\nEvery claim in a story links to its source, listed under the story.\n\n---\n\n## The Satire\n\nA story marked *Contains satire* is invented on purpose, and says so above its title.',
      },
    },
  ],
};
