// Services: what someone can hire this person for, two to six offers.
import { group, link, list, onlyIn, text, yes } from '../fields.js';

const pricing = ['pricing'] as const;
import type { PartDefinition } from '../types.js';

export const services: PartDefinition = {
  type: 'services',
  name: 'Services',
  what: 'What you can be hired for.',
  schema: {
    heading: text('Heading', 80, 'A heading above the services. Optional.'),
    label: text('Name for screen readers', 80, 'What the list is, for people who can’t see it, when it has no heading. Optional.'),
    items: group('Services', 'service', 1, 12, {
      title: text('Title', 160, 'The service’s name.', true),
      line: text('One line', 240, 'What it is, in a sentence.', true),
      forWhom: text('Who it’s for', 120, 'Who it suits: For publishers and newsletters. Optional.'),
      // Relay entry 112: a short tag on the card, as Projects' lengths.
      chip: text('Chip', 30, 'A short tag on the card: About two weeks. Optional.'),
      rung: onlyIn(pricing, text('Step', 40, 'In pricing, the step it is: Start here, Mirror. Optional.')),
      amount: onlyIn(pricing, text('Price', 40, 'In pricing, its price: $1,500. Optional.')),
      per: onlyIn(pricing, text('Per', 120, 'In pricing, what the price is for: build, then $99 a month. Optional.')),
      includes: onlyIn(pricing, list('Includes', 0, 8, 160, 'In pricing, what it includes, a line each. Optional.')),
      action: onlyIn(pricing, link('Button', 'In pricing, its button and the words on it. Optional.')),
      featured: onlyIn(pricing, yes('Featured', 'In pricing, the one card with the primary button.')),
      note: onlyIn(pricing, text('A line under the card', 240, 'In pricing, a small line inside the card. Optional.')),
    }, 'One to twelve services.'),
    after: text('A line after', 400, 'A paragraph after the services. Optional.'),
    // Relay entry 112: one more tile at the end of the grid, a line and its button.
    tileLine: onlyIn(['grid'] as const, text('Closing tile', 120, 'In a grid, a last tile with a line: Every project is quoted on a free call. Optional.')),
    tileAction: onlyIn(['grid'] as const, link('Closing tile’s button', 'In a grid, the last tile’s button and its words. Optional.')),
  },
  variants: [
    { id: 'grid', label: 'Grid' },
    { id: 'list', label: 'List' },
    { id: 'pricing', label: 'Pricing cards' },
    { id: 'facts', label: 'Facts, a name and a value each' },
  ],
  component: 'services/Services.astro',
  fixtures: [
    {
      type: 'services',
      variant: 'grid',
      fields: {
        items: [
          { title: 'Content Strategy and Search', forWhom: 'For publishers and newsletters', line: 'Search and answer-engine optimization, story-page systems, and the work you see on this site.' },
          { title: 'Fractional Operations Leadership', forWhom: 'For independent media companies that need an operator', line: 'The job I did as chief operating officer of Blue Amp Media.' },
          { title: 'AI-Assisted Editorial Operations', line: 'Skill-based workflows for small teams that want them, designed by someone who runs them every day.' },
          { title: 'Program Leadership for Complex Launches', line: 'Twenty-five years of it, including Microsoft-scale programs across three continents.' },
        ],
      },
    },
  ],
};
