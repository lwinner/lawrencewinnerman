// Quote: someone's words, used with their permission, which the part won't go live without.
import { text, yes } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const quote: PartDefinition = {
  type: 'quote',
  name: 'Quote',
  what: 'Someone’s words, with their permission.',
  schema: {
    quote: text('Quote', 600, 'Their words, exactly.', true),
    name: text('Name', 80, 'Who said it.', true),
    role: text('Role', 120, 'Their role or where it’s from. Optional.'),
    permission: yes('Permission', 'Tick to confirm they agreed to be quoted here.', true),
  },
  variants: [
    { id: 'plain', label: 'Plain' },
    { id: 'large', label: 'Large' },
  ],
  component: 'quote/Quote.astro',
  // No client has agreed to be quoted yet (the scope's open question), so the fixture quotes
  // Lawrence's own note on "World War Three Is Here."
  fixtures: [
    {
      type: 'quote',
      variant: 'plain',
      fields: {
        quote: 'Nobody in 1937 had a name for what they were living through, and the Second World War still has no agreed-upon birthday.',
        name: 'Lawrence Winnerman',
        role: 'The Hinge & The Near Field',
        permission: true,
      },
    },
  ],
};
