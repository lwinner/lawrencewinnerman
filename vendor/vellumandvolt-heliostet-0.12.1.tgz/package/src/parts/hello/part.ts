// Hello: who this is, at the top of a page. The mark, the name, a tagline, the roles, one sentence,
// and a headshot. Full is the home page's hero; compact is the Links page's.
import { group, image, link, list, text, yes } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const hello: PartDefinition = {
  type: 'hello',
  name: 'Hello',
  what: 'Who this is, at the top of a page.',
  schema: {
    mark: image('Mark', 'Your sigil or logo. Describe it for people who can’t see it.'),
    name: text('Name', 80, 'Your name as you want it to read, large.', true),
    // Relay entry 112: a phrase in the name or headline the look marks, as Vellum & Volt's volt band under "everything around it."
    highlight: text('Highlighted words', 60, 'Words from the name, exactly as written there, that the look marks. Optional.'),
    tagline: text('Tagline', 120, 'A short line under your name. Optional.'),
    roles: list('Roles', 0, 6, 40, 'What you do, a word or two each: Essayist, Novelist.'),
    // Relay entry 113: the roles as outlined pills above the name, as Vellum & Volt's For Writers and For Show Hosts.
    pills: yes('Roles as pills', 'On the full variant, the roles as outlined pills above the name.'),
    sentence: text('One sentence', 240, 'One sentence on who you are and what you’re for.'),
    headshot: image('Headshot', 'A photo of you. Describe it for people who can’t see it.'),
    // Relay entry 59: a person's page head, from site.json's people.
    person: text('Person', 40, 'On a person’s page, their id in site.json’s people: dana.'),
    buttons: group('Buttons', 'button', 0, 3, { link: link('Link', 'Where it goes, and its words.', true) }, 'The buttons under the sentence, or a person’s bio; the first is the main one. Optional.'),
    linksHeading: text('Accounts: heading', 60, 'The words over a person’s accounts: Dana elsewhere. Optional.'),
  },
  variants: [
    { id: 'full', label: 'Full' },
    { id: 'compact', label: 'Compact' },
    { id: 'person', label: 'Person: a photo, the role, the name, the bio, buttons, and accounts, to open a person’s page' },
  ],
  component: 'hello/Hello.astro',
  fixtures: [
    {
      type: 'hello',
      variant: 'full',
      fields: {
        mark: { src: '/gallery/sigil-master.svg', alt: 'Lawrence Winnerman’s sigil' },
        name: 'Lawrence Winnerman',
        tagline: 'Writing the hinge. Building the future.',
        roles: ['Essayist', 'Novelist', 'Strategist', 'Podcaster'],
        sentence: 'A Gen X writer and strategist working the seam where institutions break: what comes next, and how we build it.',
        headshot: { src: '/gallery/lawrence-winnerman-headshot-400.jpg', alt: 'Lawrence Winnerman, with a full white beard, in front of a turquoise wall' },
      },
    },
    // Relay entry 59: a person's page head, from the site's people.
    {
      type: 'hello',
      variant: 'person',
      fields: {
        name: 'Lawrence Winnerman',
        person: 'lawrence',
        buttons: [{ link: { to: 'https://lwinner.substack.com', label: 'Lawrence on Substack' } }, { link: { to: '/writing', label: 'All his writing' } }],
      },
    },
  ],
};
