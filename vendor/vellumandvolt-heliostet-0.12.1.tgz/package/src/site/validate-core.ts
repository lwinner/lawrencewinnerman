// validateSite (relay entry 54, CMP-5): the one check every page passes before it can publish, run by
// the build now and by the composer later. Errors stop publishing; warnings go ahead, into the build
// report and the composer. Each names the page, the row, the slot, the part, and the field, with a
// plain message. It reads nothing from disk, so the composer can run it on a draft as it stands.

import { runQuery, linkOf } from '../parts/data.js';
import type { QueryValue } from '../parts/fields.js';
import { PARTS, isPartType } from '../parts/registry.js';
import type { ContentItem, Part } from '../parts/types.js';
import { validatePart } from '../parts/validate-core.js';
import { layoutRows, type LayoutRow } from './layout.js';
import type { CollectionsFile, NavFile, PageFile, SharedFile, TemplateFile } from './schema.js';
import { withShared } from './shared.js';

export interface SiteIssue {
  /** The file: "site/pages/home.json". */
  page: string;
  /** "Row 3 (just-published)", when it's in a row. */
  row?: string;
  /** "main content", "left sidebar", or "right sidebar". */
  slot?: string;
  /** The part's id. */
  part?: string;
  field?: string;
  message: string;
}

export interface SiteToCheck {
  pages: PageFile[];
  templates: Map<string, TemplateFile>;
  shared: SharedFile;
  nav: NavFile | null;
  collections: CollectionsFile;
  locked: string[];
  /** Every other address the site will have: its collections' items, its Markdown pages, its reading pages. */
  addresses?: { address: string; owner: string }[];
  /** The site's content, for the warning that a list matches nothing yet. */
  items?: ContentItem[];
  /**
   * The site's own variants (decision 0019), as "type:variant", and those of them that draw the
   * page's main heading.
   */
  own?: { variants: ReadonlySet<string>; titles: ReadonlySet<string> };
  /**
   * The pages a form that takes an email address may be on: the record's `exceptions.emailForm`, a
   * Press-only exception to ONB-1 (relay entry 57, Lawrence's ruling 3). Empty for every other site.
   */
  emailForm?: ReadonlySet<string>;
  /** The record's exceptions.emailForm.band: the shared band may carry the form. */
  emailFormBand?: boolean;
}

/** True when a part's variant draws a form that takes an email address. */
const takesEmail = (part: { type: string; variant?: string | undefined }) => isPartType(part.type) && PARTS[part.type].variants.some((v) => v.id === part.variant && v.takesEmail === true);
const EMAIL = 'The site never collects an email address (ONB-1), so a form that takes one goes only on a page the record’s exceptions.emailForm names.';

/** One issue as a line: "site/pages/home.json, Row 3 (just-published), right sidebar, shop, products: …". */
export const issueLine = (i: SiteIssue) => [i.page, i.row, i.slot, i.part, i.field].filter(Boolean).join(', ') + `: ${i.message}`;

const BOUND: Record<string, string> = { stories: 'story-note', chapters: 'chapter-reader', videos: 'video' };
const SLOT = { main: 'main content', left: 'left sidebar', right: 'right sidebar' } as const;
const ORDINAL_ROWS = (from: number, to: number) => (from === to ? `Row ${from + 1}` : to === from + 1 ? `Rows ${from + 1} and ${to + 1}` : `Rows ${from + 1} to ${to + 1}`);

/** A page on the site, without its query or fragment; a file (it has an extension) isn't a page. */
const pagePath = (to: string) => {
  if (!/^\/(?!\/)/.test(to)) return null;
  const path = to.replace(/[?#].*$/, '').replace(/\/$/, '') || '/';
  return /\.[a-z0-9]{2,5}$/i.test(path) ? null : path;
};

/** Every internal link a part's fields hold, with the field it's in. */
function linksIn(part: Part): { field: string; to: string }[] {
  if (!isPartType(part.type)) return [];
  const out: { field: string; to: string }[] = [];
  for (const [key, field] of Object.entries(PARTS[part.type].schema)) {
    const value = part.fields[key];
    if (field.kind === 'link') {
      const l = linkOf(value);
      if (l) out.push({ field: key, to: l.to });
    } else if (field.kind === 'group' && Array.isArray(value)) {
      value.forEach((entry, i) => {
        for (const [inner, f] of Object.entries(field.fields)) {
          if (f.kind !== 'link') continue;
          const l = linkOf((entry as Record<string, unknown>)?.[inner]);
          if (l) out.push({ field: `${key}.${i}.${inner}`, to: l.to });
        }
      });
    }
  }
  return out;
}

/** Whether a part draws a page's main heading when it's asked to. */
const drawsTitle = (part: Part, own: ReadonlySet<string>) => part.type === 'hello' || TITLE_VARIANTS.has(`${part.type}:${part.variant ?? ''}`) || own.has(`${part.type}:${part.variant ?? ''}`);
/** The reading variants that draw a page's h1, for a page whose header is its first part (relay entry 54). */
export const TITLE_VARIANTS = new Set(['booking:hero', 'prose:header', 'prose:title-and-body', 'prose:not-found', 'prose:intro', 'prose:band', 'list:index', 'list:front', 'subscribe:page']);

export function validateSite(site: SiteToCheck): { errors: SiteIssue[]; warnings: SiteIssue[] } {
  const errors: SiteIssue[] = [];
  const warnings: SiteIssue[] = [];
  const sharedIds = new Set(site.shared.parts.map((s) => s.id));
  const ownVariants = site.own?.variants ?? new Set<string>();
  const ownTitles = site.own?.titles ?? new Set<string>();

  // Every address, once: page files, collection items, Markdown pages, reading pages.
  const owners = new Map<string, string[]>();
  for (const page of site.pages) owners.set(page.address, [...(owners.get(page.address) ?? []), `site/pages/${page.id}.json`]);
  for (const a of site.addresses ?? []) owners.set(a.address, [...(owners.get(a.address) ?? []), a.owner]);
  for (const [at, who] of owners) if (who.length > 1) errors.push({ page: who[0]!, message: `Two pages at ${at}: ${who.join(' and ')}.` });
  for (const at of site.locked) if (!owners.has(at)) errors.push({ page: 'site/site.json', message: `The locked page at ${at} is missing. A locked page can be edited, never moved or deleted.` });
  for (const page of site.pages) if (page.locked && !site.locked.includes(page.address)) errors.push({ page: `site/pages/${page.id}.json`, message: `The page is locked, and site/site.json doesn’t list ${page.address}.` });
  const exists = (to: string) => {
    const path = pagePath(to);
    return path === null || owners.has(path);
  };

  // The shared parts themselves.
  for (const s of site.shared.parts) {
    for (const e of validatePart(s.part, ownVariants)) errors.push({ page: 'site/shared.json', part: s.id, field: e.field, message: e.message });
    if (takesEmail(s.part) && !site.emailFormBand) errors.push({ page: 'site/shared.json', part: s.id, field: 'variant', message: EMAIL });
    for (const l of linksIn(s.part)) if (!exists(l.to)) errors.push({ page: 'site/shared.json', part: s.id, field: l.field, message: `${l.to} isn’t a page on the site.` });
  }

  const emailPages = site.emailForm ?? new Set<string>();
  const checkRows = (file: string, rows: TemplateFile['rows'], shared: Record<string, unknown>, address: string | null) => {
    rows.forEach((row, r) => {
      for (const slot of ['main', 'left', 'right'] as const) {
        const parts = slot === 'main' ? row.main : row[slot].parts;
        for (const part of parts) {
          const where = { page: file, row: `Row ${r + 1} (${row.id})`, slot: SLOT[slot] };
          if ('shared' in part) {
            if (!sharedIds.has(part.shared)) errors.push({ ...where, part: part.shared, message: `There’s no shared part called “${part.shared}.”` });
            continue;
          }
          if ('bind' in part) continue;
          for (const e of validatePart(part, ownVariants)) errors.push({ ...where, part: part.id, field: e.field, message: e.message });
          if (takesEmail(part) && (address === null || !emailPages.has(address))) errors.push({ ...where, part: part.id, field: 'variant', message: EMAIL });
          for (const l of linksIn(part)) if (!exists(l.to)) errors.push({ ...where, part: part.id, field: l.field, message: `${l.to} isn’t a page on the site.` });
          if (part.type === 'list' && site.items) {
            const q = part.fields.query as QueryValue | undefined;
            if (q?.filters && Object.values(q.filters).some(Boolean) && runQuery(q, { timeZone: 'UTC', items: site.items, stores: [] }).length === 0) {
              warnings.push({ ...where, part: part.id, field: 'query', message: `${(part.fields.heading as string) || 'This list'} matches no ${q.source} yet.` });
            }
          }
        }
      }
    });
    for (const key of Object.keys(shared)) if (!sharedIds.has(key)) errors.push({ page: file, message: `There’s no shared part called “${key}.”` });
    // A sidebar that's on has something in it: a run's column, its shared parts in place, holds a part.
    const placed = withShared(rows as LayoutRow<Part & { id: string }>[] as never, site.shared, shared as never) as LayoutRow<Part>[];
    for (const block of layoutRows(placed)) {
      if (block.kind !== 'run') continue;
      const first = rows.findIndex((x) => x.id === block.rows[0]!.id);
      for (const c of block.columns) {
        if (c.parts.length) continue;
        const span = ORDINAL_ROWS(first + c.from, first + c.to);
        errors.push({ page: file, row: span, slot: SLOT[c.side], message: `The ${c.side} sidebar beside ${span} is on but empty. Add a part, or turn it off.` });
      }
    }
  };

  for (const page of site.pages) {
    const file = `site/pages/${page.id}.json`;
    if (page.layout) continue;
    if (!page.rows.length) errors.push({ page: file, message: `${page.title || page.id} has no rows. Add one, or delete the page.` });
    // A page in a reading frame is a stack of bands, as the page it reproduces was (relay entry 54).
    if (page.frame !== 'parts') {
      page.rows.forEach((row, r) => {
        if (row.left.on || row.right.on) errors.push({ page: file, row: `Row ${r + 1} (${row.id})`, message: `A page in the ${page.frame} frame has no sidebars. Turn this row’s sidebars off, or draw the page in rows.` });
      });
    }
    checkRows(file, page.rows, page.shared, page.address);
    // Exactly one h1: the page's own title, its Hello's name, or its first part's heading.
    const all = page.rows.flatMap((r) => [...r.main, ...r.left.parts, ...r.right.parts]).flatMap((p) => ('type' in p ? [p] : []));
    const hellos = all.filter((p) => p.type === 'hello');
    if (page.header === 'page' && hellos.length) {
      errors.push({ page: file, part: hellos[0]!.id, message: `The ${page.id} page has two main headings: the page title and Hello’s name. Choose one: set "header" to "hello", or take out the Hello.` });
    } else if (page.header === 'hello' && hellos.length !== 1) {
      errors.push({ page: file, message: hellos.length ? `The ${page.id} page has ${hellos.length} Hello parts, so ${hellos.length} main headings. Keep one.` : `The ${page.id} page has no main heading: its header is its Hello, and it has no Hello.` });
    } else if (page.header === 'part') {
      const first = page.rows[0]?.main[0];
      if (!first || 'shared' in first || !drawsTitle(first as Part, ownTitles)) errors.push({ page: file, message: `The ${page.id} page has no main heading: its header is its first part, and that part doesn’t draw one.` });
    }
    // A list over numbered pages is a list on the page, with a query to count (relay entry 55).
    if (page.paginate) {
      const list = all.find((p) => p.id === page.paginate!.part);
      if (!list || list.type !== 'list') errors.push({ page: file, field: 'paginate', message: `The page runs over numbered pages by the list “${page.paginate.part},” and it has no list by that id.` });
    }
  }
  for (const [name, template] of site.templates) {
    const file = `site/templates/${name}.json`;
    checkRows(file, template.rows, template.shared, null);
    const bound = template.rows.flatMap((r) => [...r.main, ...r.left.parts, ...r.right.parts]).filter((p) => 'bind' in p);
    const want = BOUND[template.collection];
    if (bound.length !== 1) errors.push({ page: file, message: `A template has exactly one part bound to the item, and this one has ${bound.length}.` });
    else if ((bound[0] as { type: string }).type !== want) errors.push({ page: file, part: (bound[0] as { id: string }).id, message: `A ${template.collection} template binds a ${want} part, not a ${(bound[0] as { type: string }).type}.` });
  }
  for (const [collection, c] of Object.entries(site.collections)) {
    const template = site.templates.get(c!.template);
    if (!template) errors.push({ page: 'site/collections.json', message: `${collection} names the template “${c!.template},” and there’s no site/templates/${c!.template}.json.` });
    else if (template.collection !== collection) errors.push({ page: `site/templates/${c!.template}.json`, message: `The template is for ${template.collection}, not ${collection}.` });
  }
  // The menu and the footer point only at pages that exist.
  if (site.nav) {
    const check = (where: string, items: { label: string; to: string }[]) =>
      items.forEach((n) => {
        if (!exists(n.to)) errors.push({ page: 'site/nav.json', field: where, message: `“${n.label}” goes to ${n.to}, which isn’t a page on the site.` });
      });
    check('menu', site.nav.menu);
    check('footer', site.nav.footer);
    if (site.nav.subscribe) check('subscribe', [site.nav.subscribe]);
  }
  return { errors, warnings };
}
