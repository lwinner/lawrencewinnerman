// The colors a site's look.json may set (relay entry 91, section 5): each a token a look may already replace, named
// in plain words for the Page Builder's Look tab. The build lays them over the resolved look and holds the result to
// the contrast floors every look holds (PAGE-5); the Look tab checks the same pairs as they're chosen.

import { BUTTON_PAIRS, LOOK_PAIRS } from '../build/contrast-floors.js';
import { contrast } from '../build/color.js';

/** Each color, by its token, with the words the Look tab uses. */
export const LOOK_COLORS = [
  ['surface', 'Background'],
  ['surface-raised', 'Cards and panels'],
  ['ink', 'Text'],
  ['ink-muted', 'Quiet text'],
  ['volt', 'Accent and buttons'],
  ['on-volt', 'Text on buttons'],
  ['volt-text', 'Links'],
  ['surface-inverse', 'Bands'],
  ['on-inverse', 'Text on bands'],
  // Relay entry 112: the primary button's own colors, as Vellum & Volt's volt with ink type. Left out, a primary button
  // is the look's inverse color, as before.
  ['button', 'Primary buttons'],
  ['on-button', 'Text on primary buttons'],
] as const;
export type LookColorToken = (typeof LOOK_COLORS)[number][0];
export const LOOK_COLOR_TOKENS = LOOK_COLORS.map(([t]) => t) as unknown as readonly [LookColorToken, ...LookColorToken[]];
const WORDS = Object.fromEntries(LOOK_COLORS) as Record<string, string>;

/** Each floor the given colors fall below, in plain words: "Text on Background is 3.20 to 1; text needs 4.5 to 1."
 *  Only pairs whose two colors are both known are checked; a color left out stays the look's own. */
export function lookColorFailures(colors: Partial<Record<string, string>>): string[] {
  return [...LOOK_PAIRS, ...BUTTON_PAIRS].flatMap(({ fg, bg, floor }) => {
    const a = colors[fg];
    const b = colors[bg];
    if (!a || !b) return [];
    const ratio = contrast(a, b);
    if (ratio >= floor) return [];
    return [`${WORDS[fg] ?? fg} on ${(WORDS[bg] ?? bg).toLowerCase()} is ${ratio.toFixed(2)} to 1; ${floor === 4.5 ? 'text' : 'a mark'} needs ${floor} to 1.`];
  });
}
