// Pages as data (decision 0017, relay entry 53; CMP-1, CMP-3): the shape of every file in a site's
// site/ folder. One zod schema per file, and page.schema.json, which the package exports so an
// editor can check a page file by hand, is generated from the page schema here.
//
//   site/pages/<id>.json          one page: its address, header, search settings, and rows
//   site/templates/<name>.json    a collection's page, with one part bound to the item
//   site/shared.json              parts placed on every page
//   site/nav.json                 the menu, the Subscribe button, and the footer's links
//   site/look.json                the look, and the tokens a client may change
//   site/collections.json         each collection's address and template
//   site/site.json                the locked addresses

import { z } from 'zod';
import { NETWORKS } from '../parts/networks.js';
import { PART_TYPES } from '../parts/types.js';
import { LOOK_COLOR_TOKENS } from './look-colors.js';

const id = z.string().regex(/^[a-z0-9][a-z0-9-]{0,63}$/, 'An id is lowercase letters, digits, and hyphens.');
/** A page's address on the site: "/", "/work", "/fiction/light-shines-through". */
export const address = z.string().regex(/^\/(?:[a-z0-9][a-z0-9-]*(?:\/[a-z0-9][a-z0-9-]*)*)?$/, 'An address starts with a slash and is lowercase words with hyphens: /work.');

/** The frames a page's parts sit in (relay entries 54 and 55). */
export const FRAMES = ['parts', 'stack', 'article', 'article-prose', 'none'] as const;
/** Settings for the site's own frame: words, numbers, or yes and no. */
const frameOptions = z.record(z.string().regex(/^[a-z][a-zA-Z0-9]*$/), z.union([z.string().max(200), z.number(), z.boolean()]));

/** The reading templates a page can still be drawn by (decision 0006), until it moves onto parts. */
export const LEGACY_LAYOUTS = ['front', 'latest', 'watch-index', 'series-index', 'clips', 'about', 'subscribe', 'links', 'status', 'notes', 'show', 'merch', 'not-found'] as const;

/** A part placed in a slot: its own fields, or a shared part named by its id. */
const placed = z.strictObject({
  id,
  type: z.enum(PART_TYPES),
  variant: z.string().optional(),
  fields: z.record(z.string(), z.unknown()).default({}),
});
const sharedRef = z.strictObject({ shared: id });
/** In a collection's template: the part the item fills in. */
const bound = z.strictObject({
  id,
  type: z.enum(['story-note', 'chapter-reader', 'video']),
  variant: z.string().optional(),
  bind: z.literal('item'),
  fields: z.record(z.string(), z.unknown()).default({}),
});

const slotPart = z.union([placed, sharedRef]);
const templatePart = z.union([placed, sharedRef, bound]);

const side = <T extends z.ZodType>(part: T) => z.strictObject({ on: z.boolean(), parts: z.array(part).default([]) });

const rowOf = <T extends z.ZodType>(part: T) =>
  z.strictObject({
    id,
    main: z.array(part).default([]),
    left: side(part).default({ on: false, parts: [] }),
    right: side(part).default({ on: false, parts: [] }),
    /** False keeps this row's sidebars from joining the row above. */
    join: z.boolean().default(true),
    /** A background behind the row, the page's full width (relay entry 113): sunken, raised, inverse, or volt-soft. */
    band: z.enum(['sunken', 'raised', 'inverse', 'volt-soft']).optional(),
    /** A hidden row stays in the file but isn't drawn or checked, as if it weren't there (relay entry 91). */
    hidden: z.boolean().default(false),
  });

const sharedChoice = z.union([z.enum(['keep', 'hide']), z.strictObject({ replace: placed })]);

export const pageSchema = z.strictObject({
  $schema: z.string().optional(),
  id,
  address,
  title: z.string().trim().min(1).max(120),
  eyebrow: z.string().max(60).optional(),
  intro: z.string().max(400).optional(),
  /** Where the page's one h1 comes from: its own header, its Hello part's name, or its first part (a reading variant that draws one). */
  header: z.enum(['page', 'hello', 'part']).default('page'),
  /** The recipe it started from, for the record. */
  recipe: z.string().optional(),
  /** Editable, but never moved or deleted. */
  locked: z.boolean().default(false),
  seo: z
    .strictObject({
      title: z.string().max(120).optional(),
      description: z.string().max(300).optional(),
      shareImage: z.string().optional(),
      noindex: z.boolean().optional(),
      /** With noindex, links are still followed: "noindex, follow" (relay entry 69's landing pages). */
      follow: z.boolean().optional(),
      /** The structured data the page carries: the site's WebSite, the About page's graph, or a page's WebPage (ENT-1). */
      graph: z.enum(['website', 'about', 'page']).optional(),
      /** Open Graph's type: profile for an About page, article for a story. */
      type: z.enum(['website', 'profile', 'article']).optional(),
    })
    .optional(),
  /**
   * The frame the page's parts sit in. Parts (the default) is rows and runs. The others are a page
   * built before parts, drawn exactly (relay entry 54): its bands' parts directly in the reading
   * template's stack, a div, an article, or an article at the reading measure; or, with none, its
   * bands' parts directly inside the site's own frame (relay entry 55, decision 0019).
   */
  frame: z.enum(FRAMES).default('parts'),
  /** Settings the site's own frame reads (decision 0019): which masthead, whether the subscribe band shows. */
  frameOptions: frameOptions.optional(),
  /**
   * A list that runs over numbered pages (relay entry 55): the list part, by its id, shows its
   * query's count on each page, at the page's address, then /2, /3, and on.
   */
  paginate: z.strictObject({ part: id }).optional(),
  /** Drawn by a reading template rather than rows of parts (decision 0006), until it moves. */
  layout: z.enum(LEGACY_LAYOUTS).optional(),
  /** Each shared part on this page: kept (the default), hidden, or replaced. */
  shared: z.record(id, sharedChoice).default({}),
  rows: z.array(rowOf(slotPart)).default([]),
});

export const COLLECTIONS = ['stories', 'chapters', 'videos'] as const;

export type Collection = (typeof COLLECTIONS)[number];

export const templateSchema = z.strictObject({
  $schema: z.string().optional(),
  collection: z.enum(COLLECTIONS),
  /** As a page's frame; a template drawn in the site's own frame has none (decision 0019). */
  frame: z.enum(FRAMES).default('parts'),
  frameOptions: frameOptions.optional(),
  shared: z.record(id, sharedChoice).default({}),
  rows: z.array(rowOf(templatePart)).min(1),
});

export const sharedSchema = z.strictObject({
  parts: z
    .array(
      z.strictObject({
        id,
        /** The end of the page's first run with that side on, or a band after its last row. */
        place: z.enum(['left', 'right', 'band-end']),
        part: placed,
      }),
    )
    .default([]),
});

const navLink = z.strictObject({ label: z.string().trim().min(1).max(40), to: z.string().regex(/^(\/|https:\/\/)/, 'A link goes to a page on the site or an https address.'), /** Its words on a phone, where the masthead is narrow (relay entry 112): Book a call. */ short: z.string().trim().min(1).max(24).optional() });
export const navSchema = z.strictObject({
  /** The masthead's lockup, when it isn't the site's name and logo: Lawrence Winnerman with the sigil. */
  lockup: z.strictObject({ name: z.string().trim().min(1).max(80), mark: z.strictObject({ src: z.string().regex(/^\//), width: z.number().int().positive(), height: z.number().int().positive() }).optional() }).optional(),
  menu: z.array(navLink).max(12),
  subscribe: navLink.optional(),
  footer: z.array(navLink).max(12).default([]),
});

/** One role of a font kit: the family as the kit names it, its kind when the name doesn't say, and the weights and styles the look uses. */
const kitRole = z.strictObject({
  family: z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, 'A kit family is named as the kit names it: arno-pro.'),
  category: z.enum(['serif', 'sans', 'slab', 'mono']).optional(),
  weights: z.array(z.number().int().min(100).max(900).multipleOf(100)).min(1).default([400]),
  styles: z.array(z.enum(['normal', 'italic'])).min(1).default(['normal']),
});
/** A licensed web-font kit (decision 0018): Adobe Fonts first. */
export const fontsSchema = z.strictObject({
  kit: z.strictObject({ provider: z.literal('adobe'), id: z.string().regex(/^[a-z0-9]{5,12}$/, 'An Adobe Fonts kit ID is letters and digits: qbo5oht.') }),
  roles: z.strictObject({ display: kitRole, subhead: kitRole.optional(), body: kitRole, ui: kitRole, caption: kitRole.optional() }),
});
/** A color a look option names: a hex value, or one of the look's own color tokens by name. */
const lookColor = z.string().regex(/^(#[0-9a-fA-F]{6}|[a-z][a-z-]{1,30})$/, 'A color is a hex value (#b01647) or one of the look’s token names (volt).');
/** An image the Look sets: a file in /look/, with its size. */
const lookImage = z.strictObject({ src: z.string().regex(/^\/look\/[a-z0-9-]+\.(?:svg|png|jpg|webp)$/, 'A Look image is a file in /look/.'), width: z.number().int().positive(), height: z.number().int().positive(), alt: z.string().max(200).optional() });
const lookCommon = {
  choices: z.array(z.string()).default([]),
  fonts: fontsSchema.optional(),
  /** The Look's images (Lawrence's rulings, October 29): the share image for a page with no card of its own, the
   *  favicon, and the footer's logo, each a file the site serves at /look/. */
  shareImage: lookImage.optional(),
  favicon: z.strictObject({ src: z.string().regex(/^\/look\/[a-z0-9-]+\.(?:svg|png)$/, 'A favicon is an SVG or PNG in /look/.') }).optional(),
  footerLogo: lookImage.optional(),
  /** The colors the Page Builder's Look tab sets (relay entry 91), by token, laid over the look and held to its floors. */
  colors: z.partialRecord(z.enum(LOOK_COLOR_TOKENS), z.string().regex(/^#[0-9a-fA-F]{6}$/, 'A color is a six-digit hex value: #b01647.')).optional(),
  /**
   * The look's bands (relay entry 59): a row of color blocks the parts draw under a section, as the
   * Press draws its four-color rule. Each color is a hex value or a token name; the rule is its
   * height, and a card's and a bar's are the thinner and the thicker.
   */
  bands: z
    .strictObject({ colors: z.array(lookColor).min(2).max(6), rule: z.number().int().min(1).max(24).default(6), card: z.number().int().min(1).max(24).default(4), bar: z.number().int().min(1).max(48).default(18) })
    .optional(),
  /**
   * The site's own icon set (relay entry 59): a folder in the site's repository with one SVG per
   * network, <network>.svg, drawn inline in the text's color. Heliostet carries no network's glyph.
   */
  icons: z.string().regex(/^[A-Za-z0-9._/-]+$/, 'A folder in the site’s repository: src/look/icons.').optional(),
  /** The satire disclosure's colors (relay entry 59), when the look names its own. */
  disclosure: z.strictObject({ background: lookColor, ink: lookColor }).optional(),
  /**
   * The page's layout (relay entry 113), for any site that wants it: the column's width, the masthead in one row, the
   * booking and subscribe bands and the footer full width, hairline rules between sections, links underlined rather than
   * arrowed, cards three across, and an editorial type scale (a large, regular-weight display face). Left out, every site
   * draws as before.
   */
  layout: z
    .strictObject({
      width: z.number().int().min(960).max(1440).optional(),
      masthead: z.enum(['stacked', 'row']).default('stacked'),
      bands: z.enum(['boxed', 'full']).default('boxed'),
      rules: z.boolean().default(false),
      links: z.enum(['arrow', 'underline']).default('arrow'),
      cards: z.union([z.literal(2), z.literal(3)]).default(2),
      type: z.enum(['standard', 'editorial']).default('standard'),
    })
    .optional(),
  /** An input field's colors (relay entry 59), when the look names its own. */
  field: z.strictObject({ background: lookColor, ink: lookColor }).optional(),
};
export const lookSchema = z.union([
  z.strictObject({ kind: z.literal('brand'), ...lookCommon }),
  z.strictObject({ kind: z.literal('match'), substack: z.string().optional(), overlay: z.string().optional(), ...lookCommon }),
  z.strictObject({ kind: z.literal('house'), name: z.enum(['newsroom', 'broadcast', 'study']), ...lookCommon }),
  z.strictObject({ kind: z.literal('bespoke'), overlay: z.string(), ...lookCommon }),
]);

export const collectionsSchema = z.partialRecord(
  z.enum(COLLECTIONS),
  z.strictObject({
    /** The address pattern, with {slug} or {book} and {slug}: /writing/{slug}. */
    address: z.string().regex(/^\/[a-z0-9/{}-]*\{slug\}$/, 'A collection address ends in {slug}: /writing/{slug}.'),
    /** Its template, in site/templates/. */
    template: id,
    /** Where its items were before, with {slug}: the build writes a 301 from each old address (relay entry 54). */
    previously: z.string().regex(/^\/[a-z0-9/{}-]*\{slug\}$/, 'A previous address ends in {slug}: /story/{slug}.').optional(),
  }),
);

export const siteFileSchema = z.strictObject({
  /** Addresses that must always be present: editable, never moved or deleted. */
  locked: z.array(address).default([]),
  /**
   * Heliostet's own pages the site doesn't have (relay entry 55): a site moving onto Heliostet keeps
   * its list of addresses as it was, and may leave out the status page and the links page.
   */
  without: z.array(z.enum(['status', 'links'])).default([]),
  /**
   * The pages' share images: Heliostet draws one for each page at build, or the site's own frame
   * names them, and Heliostet draws none (relay entry 55).
   */
  shareImages: z.enum(['heliostet', 'own']).default('heliostet'),
  /**
   * How the parts draw a story's title (relay entry 59): as the source published it, or in Chicago
   * title case. `titleWords` holds the site's own exceptions: words it always capitalizes, and words it
   * always lowercases.
   */
  titles: z.enum(['as-published', 'chicago']).default('as-published'),
  /**
   * The footer's last lines (relay entry 112): the credit's wording, "Made with Heliostet by Vellum & Volt" on every client
   * site and "Runs on Heliostet" on Vellum & Volt's own, and a legal line that replaces the operator sentence drawn from
   * the client record: Operated by Cerulean Sky Buffalo LLC.
   */
  footer: z.strictObject({ credit: z.enum(['made-with', 'runs-on']).default('made-with'), legal: z.string().trim().min(1).max(160).optional() }).optional(),
  titleWords: z
    .strictObject({
      capitalize: z.array(z.string().regex(/^[a-z]+$/, 'A word in lowercase letters: up.')).max(40).default([]),
      lowercase: z.array(z.string().regex(/^[a-z]+$/, 'A word in lowercase letters: vs.')).max(40).default([]),
    })
    .default({ capitalize: [], lowercase: [] }),
  /**
   * The bylines on a story's card (relay entry 59). Each principal's name links to their page on the
   * site; principals come first, in the source's order, then anyone else. A story with no byline
   * carries the house name, linked where the site says.
   */
  bylines: z
    .strictObject({
      pages: z.record(id, address).default({}),
      principalsFirst: z.boolean().default(false),
      /** The principals take turns being first, from one half hour of build to the next (the Press's rule). */
      alternate: z.boolean().default(false),
      house: z.strictObject({ name: z.string().trim().min(1).max(80), to: address.optional() }).optional(),
    })
    .default({ pages: {}, principalsFirst: false, alternate: false }),
  /**
   * Tags a card shows (relay entry 59): each a label, and the titles or topics that carry it, as a
   * pattern. The Press's Friday tag: "Friday," for every Fucked-Up Friday episode.
   */
  cardTags: z
    .array(z.strictObject({ label: z.string().trim().min(1).max(40), pattern: z.string().min(1).max(200), flags: z.string().regex(/^[imsu]*$/).default('') }))
    .max(8)
    .default([]),
  /**
   * The site's people (relay entry 59), by principal id: the role line, the bio, the photo, and the
   * accounts a person card draws. A host page and the About page read the same person.
   */
  people: z
    .record(
      id,
      z.strictObject({
        role: z.string().trim().min(1).max(80),
        bio: z.string().trim().min(1).max(1200),
        photo: z.strictObject({ src: z.string().min(1), alt: z.string().trim().min(1).max(200), small: z.string().min(1).optional(), tiny: z.string().min(1).optional() }).optional(),
        links: z.array(z.strictObject({ network: z.enum(NETWORKS), to: z.string().min(1) })).max(14).default([]),
      }),
    )
    .default({}),
  /** What the satire disclosure says (relay entry 59), and the site's levels of it, as data. */
  satire: z
    .strictObject({
      label: z.string().trim().min(1).max(40).default('Contains satire'),
      levels: z.array(z.strictObject({ level: z.number().int().min(0).max(99), name: z.string().trim().min(1).max(80) })).max(20).default([]),
    })
    .default({ label: 'Contains satire', levels: [] }),
  /**
   * How a story's picture is sized for a card (relay entry 59): Substack's own image service at the
   * width a card needs, or Cloudflare's, or the picture as it is.
   */
  imageResizing: z.enum(['substack', 'cloudflare', 'none']).default('none'),
  /**
   * A Show client's shows (relay entry 125): the Cockpit's shows feed the site reads at build, for its next
   * show, its guests, and their pictures, copied onto the site's own domain.
   */
  /**
   * The channel whose newest videos a video band shows (relay entry 125), read at build from its RSS feed, or its
   * /videos page when YouTube's feed is down; no API key.
   */
  /**
   * The site's own reading of a story (relay entry 125): a module in the site's repository, by its path from the
   * site's root, whose `reading` export Heliostet's story page calls for the body, its sources, and what the
   * site knows of the story that Heliostet doesn't. A site without one has Heliostet's own reading.
   */
  reading: z.string().regex(/^(?!\/)(?!.*\.\.)[\w./-]+\.(?:ts|mjs|js)$/, 'The reading module is a .ts, .mjs, or .js file in the site, by its path from the site’s root: src/lib/reading.ts.').optional(),
  youtube: z.strictObject({ channelId: z.string().regex(/^UC[\w-]{22}$/, 'A channel ID starts UC and has 24 characters.'), handle: z.string().regex(/^@[\w.-]{3,40}$/, 'A handle starts with @.') }).optional(),
  shows: z.strictObject({
    feed: z.string().regex(/^https:\/\/\S+$/, 'The shows feed is an https address.'),
    /** Where the site keeps its copies of the feed's pictures, so its pages name its own domain: {id} and {date}. */
    headshots: z.string().regex(/^\/\S*\{id\}\S*$/, 'A headshot address names {id}.').optional(),
    thumbs: z.string().regex(/^\/\S*\{date\}\S*$/, 'A thumbnail address names {date}.').optional(),
  }).optional(),
});

export type PageFile = z.infer<typeof pageSchema>;
export type TemplateFile = z.infer<typeof templateSchema>;
export type SharedFile = z.infer<typeof sharedSchema>;
export type NavFile = z.infer<typeof navSchema>;
export type LookFile = z.infer<typeof lookSchema>;
export type CollectionsFile = z.infer<typeof collectionsSchema>;
export type Row = PageFile['rows'][number];
export type TemplateRow = TemplateFile['rows'][number];
export type SlotPart = Row['main'][number];
export type TemplatePart = TemplateRow['main'][number];
export type PlacedPart = z.infer<typeof placed>;

/** The page file's JSON Schema, as the package exports it. */
export function pageJsonSchema(): Record<string, unknown> {
  return {
    ...z.toJSONSchema(pageSchema, { io: 'input', target: 'draft-2020-12' }),
    $id: 'https://heliostet.com/schema/page.schema.json',
    title: 'A Heliostet page file',
    description: 'One page of a Heliostet site, as rows of parts (decision 0017). Generated from package/src/site/schema.ts; do not edit.',
  };
}
