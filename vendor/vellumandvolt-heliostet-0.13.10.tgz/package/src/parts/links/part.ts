// Links: a list of labeled links, such as a link-in-bio or "Elsewhere."
import { choice, group, link, text, yes } from '../fields.js';
import { groupOf } from '../data.js';
import type { PartDefinition } from '../types.js';

export const ICONS = [
  ['substack', 'Substack'],
  ['medium', 'Medium'],
  ['bluesky', 'Bluesky'],
  ['threads', 'Threads'],
  ['linkedin', 'LinkedIn'],
  ['youtube', 'YouTube'],
  ['instagram', 'Instagram'],
  ['email', 'Email'],
  ['link', 'A link'],
] as const;

export const links: PartDefinition = {
  type: 'links',
  name: 'Links',
  what: 'A list of labeled links.',
  schema: {
    heading: text('Heading', 60, 'The heading: Elsewhere. Optional.'),
    /** The client's channels list (relay entry 91: "your site is your link tree"), so adding a channel adds it here. */
    fromChannels: yes('From the channels list', 'Every subscribe destination, the Support link, and the social accounts, in the client’s order. Adding a channel adds it here.'),
    links: group('Links', 'link', 0, 20, {
      label: text('Label', 40, 'What the link is: Bluesky.', true),
      to: link('Goes to', 'The address.', true),
      icon: choice('Icon', ICONS, 'The mark shown beside it.'),
    }, 'Up to twenty links, after the channels when those are on.'),
  },
  check: (f) => (f.fromChannels === true || groupOf(f.links).length ? [] : [{ field: 'links', message: 'Add a link, or draw them from the channels list.' }]),
  variants: [
    { id: 'list', label: 'List' },
    { id: 'buttons', label: 'Buttons' },
    { id: 'icons', label: 'Icons' },
    // The kit fidelity entry (item 8): the names in one row, a dot between them, as lawrencewinnerman.com's Contact.
    { id: 'inline', label: 'Inline, in one row' },
  ],
  component: 'links/Links.astro',
  // The Threads link in the mockups has no address on file, so it's left out.
  fixtures: [
    {
      type: 'links',
      variant: 'list',
      fields: {
        heading: 'Elsewhere',
        links: [
          { label: 'The Hinge on Substack', to: { to: 'https://lwinner.substack.com' }, icon: 'substack' },
          { label: 'Medium', to: { to: 'https://medium.com/@lwinner' }, icon: 'medium' },
          { label: 'Bluesky', to: { to: 'https://bsky.app/profile/lwinner.bsky.social' }, icon: 'bluesky' },
          { label: 'LinkedIn', to: { to: 'https://www.linkedin.com/in/lawrencewinnerman/' }, icon: 'linkedin' },
        ],
      },
    },
  ],
};
