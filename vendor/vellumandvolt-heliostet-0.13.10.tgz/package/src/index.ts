import { copyFileSync, cpSync, createReadStream, existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { availableParallelism } from 'node:os';
import { resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import type { AstroIntegration } from 'astro';
import { checkVendored } from './build/vendor.js';
import { loadTokens, LookContrastError, resolveLook, withLookColors } from './build/look.js';
import { groundFailures, groundsCss } from './build/grounds.js';
import { resolvedColors, tokensCss } from './build/tokens.js';
import { loadClientRecord, RECORD_FILE } from './config/load.js';
import { loadPages, PAGES_DIR } from './config/pages.js';
import { CONTENT_DIRS, coversWithoutAlt, itemContext, loadItems } from './build/content.js';
import { readLiveFeed, toItem } from './adapters/substack.js';
import { resolve as resolvePages, type Resolved } from './build/resolve.js';
import { coverAltNotice, mediaNotice, REPORT_FILE, transcriptNotice, writeReport, type Notice } from './build/report.js';
import { failedMedia, readManifest } from './build/media-store.js';
import { localize, notLocal } from './build/localize.js';
import { lookOption, siteConfig, withNav, type SiteConfig } from './config/site.js';
import type { LookOption } from './build/look.js';
import { baseCss, bundleCss, designDir, layoutsDir } from './paths.js';
import { componentsCss, readingComponentsCss } from './build/components-css.js';
import { FONT_PATH, firstFamily, fontStacks, planFonts } from './build/fonts.js';
import { assembleRedirects, CanonicalError, canonicalFaults, feedXml, lastModified, llmsTxt, readRedirects, redirectsFile, robotsTxt, sitemapXml, type Redirect } from './build/files.js';
import { ogPath, renderCard } from './build/og.js';
import { HELIOSTET_MARKS_PATH, heliostetDir, heliostetStylesheet } from './build/heliostet.js';
import { Profile } from './build/profile.js';
import { renderMarkdown, renderPages, type RenderedPage } from './build/markdown.js';
import { parseOverlay } from './build/overlay.js';
import { partsCss, rowsCss, siteDir } from './paths.js';
import { loadSiteData, SiteDataError, type SiteData } from './site/load.js';
import { issueLine, validateSite } from './site/validate.js';
import { fallbackStacks, KIT_ORIGIN, kitCss, kitStylesheet, kitWarnings, readKit } from './build/fontkit.js';
import { collectionEntries, partItems, readChapters, readStores, type CollectionEntry } from './site/content.js';
import { withShared } from './site/shared.js';
import { ownModuleCode, ownVariantList, type OwnOptions } from './site/own.js';
import type { LookFile } from './site/schema.js';
import { OVERLAY_COLOR_TOKENS } from './build/tokens.js';
import { bandCount, bandHeadingCss, lookExtrasCss } from './build/look-extras.js';
import { typeScaleCss } from './build/type-scale.js';
import { buildTurn, peopleOf } from './site/drawing.js';
import { localPicture, readShowsFeed } from './build/shows.js';
import { storesForBuild } from './build/stores.js';
import { newestVideos } from './adapters/youtube-newest.js';
import { titler } from './build/titlecase.js';
import { readIcons } from './build/icons.js';
import type { PartContext } from './parts/types.js';

export type { LookOption } from './build/look.js';
export { match, fromHtml, matchFromHtml, type MatchResult, type MatchFlag } from './build/match.js';
export { tokensCss, type Overlay, type TokenFile } from './build/tokens.js';
export { contrast } from './build/color.js';
export { clientRecordSchema, type ClientRecord, type ClientRecordInput } from './config/schema.js';
export { loadClientRecord, parseClientRecord, ClientRecordError } from './config/load.js';
export { siteConfig, lookOption, type SiteConfig, type NavItem } from './config/site.js';
export { words, type Words } from './config/vocabulary.js';
export { sanitize, plainText, decodeEntities, type SafeHtml } from './build/sanitize.js';
export { renderMarkdown } from './build/markdown.js';
export { loadItems, ContentError } from './build/content.js';
export type { Item, ItemKind, ItemSource } from './build/item.js';
export { importArchive, toRecord, toItem, cleanBody, cleanupSchema, parseSubstackFeed, IMPORT_VERSION, SUBSTACK_DIR, type SubstackRecord, type SubstackPost, type CleanupOptions } from './adapters/substack.js';
export { importChannel, toYouTubeItem, type YouTubeRecord } from './adapters/youtube.js';
export { importFeed, parseFeed, toPodcastItem, type PodcastRecord } from './adapters/podcast.js';
export { importMediumFeed, parseMediumFeed, toMediumItem, type MediumRecord } from './adapters/medium.js';
export { resolve, automaticMatches, type Resolved, type SitePage, type ResolvedJoin } from './build/resolve.js';
export { recordMatches, unjoin } from './build/record-matches.js';
export { REPORT_FILE, type Report, type Notice } from './build/report.js';
export { loadPages, PageError, type Page } from './config/pages.js';
export { destinations, type Destination } from './config/subscribe.js';

export interface HeliostetOptions {
  /** The client record, if not client.json at the site root; for Heliostet’s tests. */
  record?: string;
  /** A token source other than Heliostet’s own tokens.json; for the design-system bench and Heliostet’s tests. */
  tokens?: string;
  /**
   * Design-system components the site's own pages use beyond the reading set, whose rules join the
   * stylesheet: the company site's PricingCard and LookPicker (relay entry 25). A client site needs none.
   */
  components?: string[];
  /**
   * The parts gallery (relay entry 52): a development-only page in the site that draws every part in
   * every variant. It is added only by the dev server or with HELIOSTET_GALLERY=1, never to a
   * production build. `looks` names extra looks to draw it in, by overlay file, beside the site's own;
   * `assets` is a folder of the fixtures' images, served at /gallery/ only while the gallery is on.
   */
  gallery?: { page: string; looks?: Record<string, string>; assets?: string };
  /**
   * The site's own drawing (decision 0019, relay entry 55): its frame around every page made of
   * parts, and its own variants of Heliostet's parts, by "type:variant", each an Astro component in
   * the site's repository. A variant given as { component, title: true } draws the page's main heading.
   */
  own?: OwnOptions;
}

/**
 * The routes the site defines itself under src/pages, as route patterns: index.astro is /, about.astro
 * is /about, and host/[id].astro is /host/[id]. Heliostet does not inject a route the site has its own
 * page for (relay entry 25).
 */
export function ownRoutes(root: URL): Set<string> {
  const dir = new URL('src/pages/', root);
  const found = new Set<string>();
  const walk = (at: URL, prefix: string) => {
    if (!existsSync(at)) return;
    for (const entry of readdirSync(at, { withFileTypes: true })) {
      if (entry.isDirectory()) walk(new URL(`${entry.name}/`, at), `${prefix}/${entry.name}`);
      else if (/\.(astro|md|mdx|ts|js)$/.test(entry.name)) {
        const name = entry.name.replace(/\.(astro|md|mdx|ts|js)$/, '');
        found.add(name === 'index' ? prefix || '/' : `${prefix}/${name}`);
      }
    }
  };
  walk(dir, '');
  return found;
}

export class OwnFrontPageError extends Error {
  override name = 'OwnFrontPageError';
}

/** The client's imported old-slug map (FMT-7): [{ "from": "/old/path", "to": "/story/slug" }]. */
export const REDIRECTS_FILE = 'src/content/redirects.json';
/** Cloudflare's limit on static redirects in one _redirects file. */
const CLOUDFLARE_STATIC_REDIRECTS = 2000;

/** The modules templates import the site config and the resolved pages from. */
export const SITE_MODULE = 'virtual:vellumandvolt/site';
export const PAGES_MODULE = 'virtual:vellumandvolt/pages';
export const GALLERY_MODULE = 'virtual:vellumandvolt/gallery';
/** Pages as data (relay entry 53): the pages made of parts, the collections' items, and what parts draw from. */
export const SITE_DATA_MODULE = 'virtual:vellumandvolt/site-data';
/** The site's own frame and variants (decision 0019). */
export const OWN_MODULE = 'virtual:vellumandvolt/own';
/** The site's own reading of a story (relay entry 125): its module's `reading`, or null. */
export const READING_MODULE = 'virtual:vellumandvolt/reading';

/** The address each reading template draws at, for a page file that still names one (decision 0006). */
const LEGACY_ADDRESS: Record<string, string> = { front: '/', latest: '/latest', 'watch-index': '/watch', 'series-index': '/series', clips: '/clips', about: '/about', subscribe: '/subscribe', links: '/links', status: '/status', notes: '/notes', show: '/show', merch: '/merch', 'not-found': '/404' };

/**
 * The look's tokens for Heliostet's parts inside a site's own frame (relay entry 57): only the blocks
 * of custom properties, each scoped to the parts (the light ones to .hp-part, a dark theme's to
 * .hp-part inside it), so neither the frame's own custom properties of the same names nor its classes
 * are touched.
 */
export function scopedTokens(css: string): string {
  const out: string[] = [];
  for (const m of css.replace(/\/\*[\s\S]*?\*\//g, '').matchAll(/([^{}]+)\{([^{}]*)\}/g)) {
    const selectors = (m[1] ?? '').split(',').map((x) => x.trim()).filter(Boolean);
    const decls = (m[2] ?? '').split(';').map((x) => x.trim()).filter(Boolean);
    if (!decls.length || decls.some((d) => !d.startsWith('--'))) continue;
    const scoped = new Set(selectors.map((sel) => (sel === ':root' || sel === '[data-theme="light"]' ? '.hp-part' : /^\[data-theme="[a-z]+"\]$/.test(sel) ? `${sel} .hp-part` : '')).filter(Boolean));
    if (scoped.size) out.push(`${[...scoped].join(',')}{${decls.join(';')}}`);
  }
  return out.join('\n');
}

/** The look site/look.json names, as the record's look option is (decision 0009). */
function lookFromSite(look: LookFile, substack: string | undefined): LookOption | undefined {
  const bad = look.choices.filter((c) => !(OVERLAY_COLOR_TOKENS as readonly string[]).includes(c));
  if (bad.length) throw new SiteDataError(`site/look.json offers choices a look can't change: ${bad.join(', ')}.`);
  if (look.kind === 'brand') return undefined;
  if (look.kind === 'house') return { kind: 'house', name: look.name };
  if (look.kind === 'bespoke') return { kind: 'bespoke', overlay: look.overlay };
  const from = look.substack ?? substack;
  return { kind: 'match', ...(from ? { substack: from } : {}), ...(look.overlay ? { overlay: look.overlay } : {}) };
}
/** Where the parts gallery is, when it's on: one page per look. */
export const GALLERY_ROUTE = '/parts-gallery/[look]';
/** Where the gallery's fixture images are served, while it's on. */
export const GALLERY_ASSETS = '/gallery';

/**
 * Heliostet’s Astro integration. A client site adds `heliostet()` to its `integrations`, keeps its
 * client record in client.json, and supplies only content.
 */
export default function heliostet(options: HeliostetOptions = {}): AstroIntegration {
  let resolved: Resolved | undefined;
  let notices: Notice[] = [];
  // Phase times, with HELIOSTET_PROFILE=1 (relay entry 13).
  const profile = new Profile();
  let root: URL | undefined;
  let heliostetVersion = '';
  let fonts = new Map<string, string>();
  // Heliostet's own stylesheet, for the tool pages only (the status page); reading pages never load it.
  let toolStylesheet = '';
  let unlisted = new Set<string>();
  let stylesheet = '';
  // The look's tokens for Heliostet's parts inside a site's own frame (relay entry 57): scoped to the
  // parts, so the frame's own custom properties of the same names keep their values around them.
  let ownTokens = '';
  let siteConfigBuilt: SiteConfig | undefined;
  let llmsWanted = false;
  let cardColors = { ground: '#f6f1e7', ink: '#1c1a17', inverse: '#1c1a17', onInverse: '#f6f1e7', accent: '#c8e600' };
  let displayFace = 'Fraunces';
  let displayWeight = 600;
  // The parts gallery's images, when the gallery is on (relay entry 52).
  let galleryAssets: URL | null = null;
  // Whose share images the pages carry (relay entry 55), and how Astro writes a page's file.
  let shareImages: 'heliostet' | 'own' = 'heliostet';
  // The satire disclosure's words, from site.json (relay entry 59).
  let siteDataLabel = 'Contains satire';
  let fileFormat = false;
  return {
    name: '@vellumandvolt/heliostet',
    hooks: {
      'astro:config:setup': async ({ config, command, updateConfig, injectRoute, addWatchFile, logger }) => {
        profile.start();
        const own = ownRoutes(config.root);
        // An address a page file in site/ draws with parts is that page's, not a reading template's (relay entry 53).
        const claimed = new Set<string>();
        // Every reading route injected, for the site check's list of addresses (relay entry 54).
        const injected: string[] = [];
        // A reading route that numbers its pages (/latest/[...page]) belongs to a page file at its address.
        const listAt = (pattern: string) => pattern.replace(/\/\[\.\.\.\w+\]$/, '') || '/';
        const route = (pattern: string, layout: string) => {
          if (!own.has(pattern) && !claimed.has(pattern) && !claimed.has(listAt(pattern))) {
            injectRoute({ pattern, entrypoint: fileURLToPath(new URL(layout, layoutsDir)) });
            injected.push(pattern);
          }
        };
        // The build refuses a record that fails the schema, naming each field (FND-1).
        const recordFile = options.record ? pathToFileURL(resolve(options.record)) : new URL(RECORD_FILE, config.root);
        const record = loadClientRecord(recordFile);
        // Heliostet this repository builds with is the one it names and vendors (Step 11).
        checkVendored(config.root, record.heliostet);
        profile.mark('record and version check');
        fileFormat = config.build.format === 'file';
        const pages = loadPages(config.root, (message) => logger.warn(message));
        const site = siteConfig(record, pages);
        // Imported items with their local images and home links (Step 7).
        const manifest = readManifest(config.root);
        const filed = loadItems(config.root, record);
        // The live feed (relay entry 55): posts the import hasn't written yet join from the feed; a
        // post on file wins, and an unreachable feed is a notice, not a failed build.
        const substack = record.sources.substack;
        const live: Notice[] = [];
        if (substack?.liveFeed) {
          const onFile = new Set(filed.filter((i) => i.source === 'substack').map((i) => i.slug));
          const feed = await readLiveFeed(substack.url, substack.cleanup);
          const ctx = itemContext(record);
          const added = feed.records.filter((r) => !onFile.has(r.slug)).map((r) => toItem(r, ctx));
          filed.push(...added);
          filed.sort((a, b) => b.date.localeCompare(a.date));
          if (feed.problem) live.push({ code: 'live-feed', message: `The Substack feed wasn't read at build (${feed.problem}); the site has the posts on file.`, items: [] });
          else if (added.length) live.push({ code: 'live-feed', message: `${added.length} ${added.length === 1 ? 'post' : 'posts'} from the Substack feed ${added.length === 1 ? 'is' : 'are'} not imported yet; the build added ${added.length === 1 ? 'it' : 'them'} from the feed.`, items: added.map((i) => i.slug) });
        }
        const items = localize(filed, manifest, site.writingSlug, substack?.url);
        profile.mark('content load and media manifest');
        // Notices go to the build report, one line each in the log (relay entry 6, ruling 2).
        notices = [coverAltNotice(coversWithoutAlt(items)), mediaNotice(failedMedia(manifest), notLocal(items)), ...live].flat().filter((n): n is Notice => n !== null);
        for (const notice of notices) logger.warn(notice.message);
        root = config.root;
        heliostetVersion = record.heliostet.version;
        addWatchFile(recordFile);
        for (const dir of CONTENT_DIRS) addWatchFile(new URL(dir, config.root));
        resolved = resolvePages(items, record, site);
        // Every video and episode page still waiting for its transcript (relay entry 8).
        const pending = transcriptNotice(resolved.pages.flatMap((p) => {
          const spoken = p.recording ?? (p.item.audio ? p.item : null);
          return spoken && !spoken.transcript ? [p.item.id] : [];
        }));
        if (pending) {
          notices.push(pending);
          logger.warn(pending.message);
        }
        for (const page of pages) addWatchFile(new URL(`${PAGES_DIR}${page.slug}.md`, config.root));
        // The series and clips the content has join the navigation, before About (FMT-3, FMT-4).
        const extra = [
          ...(resolved.series.length ? [{ label: 'Series', href: '/series' }] : []),
          ...(resolved.clips.length && site.vocabulary.basis === 'episode' ? [{ label: 'Clips', href: '/clips' }] : []),
        ];
        const aboutAt = site.nav.findIndex((n) => n.href === '/about');
        site.nav.splice(aboutAt < 0 ? site.nav.length : aboutAt, 0, ...extra);
        const rendered: RenderedPage[] = renderPages(pages);

        // Pages as data (decision 0017, relay entry 53). A site with a site/ folder has its pages,
        // collections, navigation, and look there; without one it builds exactly as before.
        const siteData: SiteData | null = loadSiteData(config.root);
        let sitePagesData: unknown[] = [];
        let entryData: { collection: string; address: string }[] = [];
        let partContext: PartContext = { timeZone: site.timeZone, items: [], stores: [] };
        let siteEntries: CollectionEntry[] = [];
        if (siteData) {
          for (const file of siteData.files) addWatchFile(file);
          if (siteData.nav) {
            Object.assign(site, withNav(site, siteData.nav));
          }
          // The Look's images (relay entry 91, Lawrence's rulings of October 29).
          site.shareImage = siteData.look?.shareImage ?? null;
          site.favicon = siteData.look?.favicon ?? null;
          site.footerLogo = siteData.look?.footerLogo ?? null;
          site.footerCredit = siteData.footer?.credit ?? 'made-with';
          site.footerLegal = siteData.footer?.legal ?? null;
          const entries = collectionEntries(resolved.pages, readChapters(config.root), siteData.collections, site.name);
          siteEntries = entries;
          // A story or video in a collection lives at its collection's address, in every list, feed, and sitemap.
          const moved = new Map(entries.map((e) => [e.item.id, e.address]));
          for (const p of resolved.pages) {
            const to = moved.get(p.item.id);
            if (to) p.path = to;
          }
          for (const page of siteData.pages) {
            if (page.layout && LEGACY_ADDRESS[page.layout] !== page.address) throw new SiteDataError(`site/pages/${page.id}.json is drawn by the ${page.layout} template, which is at ${LEGACY_ADDRESS[page.layout]}, not ${page.address}.`);
          }
          // A collection that moved its items says where they were; each old address answers with a 301 (relay entry 54).
          const movedFrom = entries.filter((e) => e.previously && e.previously !== e.address).map((e) => ({ from: e.previously as string, to: e.address }));
          if (movedFrom.length) {
            resolved.redirects.push(...movedFrom);
            const message = `${movedFrom.length} ${movedFrom.length === 1 ? 'item moved' : 'items moved'} to a collection's address; each old address redirects to the new one. See ${REPORT_FILE}.`;
            logger.info(message);
            notices.push({ code: 'collection-moved', message, items: movedFrom.map((r) => `${r.from} -> ${r.to}`) });
          }
          // What's on air as this build runs (relay entry 125): each show of the site's shows feed for an hour from its start.
          const feed = siteData?.shows ? await readShowsFeed(siteData.shows.feed, { log: (line) => logger.warn(line) }) : null;
          const builtAt = Date.now();
          const onAir = [...new Set((feed?.shows ?? []).filter((s) => { const t = Date.parse(s.air_at); return t <= builtAt && builtAt < t + 3600_000; }).map((s) => s.kind))];
          // The channel's newest videos (relay entry 125), when site.json names one, in the site's own title case.
          const videos = siteData?.youtube ? (await newestVideos({ ...siteData.youtube, timeZone: site.timeZone, title: titler(siteData.drawing.titles, siteData.drawing.titleWords), log: (line) => logger.warn(line) })).map((v) => ({ ...v, date: v.date ? v.date.toISOString() : null })) : undefined;
          const shows = (feed?.shows ?? []).map((x) => ({ date: x.date, kind: x.kind, title: x.show_title, time: x.time, timeLabel: x.time_label, airAt: x.air_at, thumb: localPicture(site.url, siteData?.shows?.thumbs, { date: x.date }, x.thumb_url), guests: x.guests.map((g) => ({ id: g.id, name: g.name, initials: g.initials, bio: g.bio, substack: g.substack_url, website: g.website, headshot: localPicture(site.url, siteData?.shows?.headshots, { id: g.id }, g.headshot_url) })) }));
          partContext = { onAir, shows, builtAt: new Date(builtAt).toISOString(), ...(videos ? { videos } : {}), channels: [...site.subscribe.map((d) => ({ label: d.label, to: d.url, kind: 'subscribe' as const })), ...(site.support ? [{ label: site.support.label, to: site.support.url, kind: 'support' as const }] : []), ...site.social.map((s) => ({ label: s.label, to: s.url, kind: 'social' as const, network: s.platform }))], timeZone: site.timeZone, items: partItems(resolved.pages, entries, site.name, siteData.drawing), people: peopleOf(record.principals, siteData.drawing, buildTurn()), bands: bandCount(siteData.look), satire: siteData.drawing.satire.label, icons: readIcons(config.root, siteData.look?.icons), stores: await storesForBuild(readStores(config.root, record.merch?.stores ?? []), [...siteData.pages, ...siteData.templates.values()] as { rows: unknown[] }[], (line) => logger.warn(line)) };
          shareImages = siteData.shareImages;
          siteDataLabel = siteData.drawing.satire.label;
          const drawn = siteData.pages.filter((p) => !p.layout);
          for (const page of drawn) claimed.add(page.address === '/' ? '/' : page.address);
          sitePagesData = drawn.map((page) => ({
            address: page.address,
            title: page.title,
            ...(page.eyebrow ? { eyebrow: page.eyebrow } : {}),
            ...(page.intro ? { intro: page.intro } : {}),
            header: page.header,
            frame: page.frame,
            ...(page.frameOptions ? { frameOptions: page.frameOptions } : {}),
            ...(page.paginate ? { paginate: page.paginate } : {}),
            ...(page.seo ? { seo: page.seo } : {}),
            rows: withShared(page.rows, siteData.shared, page.shared),
          }));
          entryData = entries.map((e) => {
            const template = siteData.templates.get(siteData.collections[e.collection]!.template)!;
            return { collection: e.collection, address: e.address, params: e.params, title: e.item.title, description: e.item.dek ?? '', fields: e.fields, frame: template.frame, ...(template.frameOptions ? { frameOptions: template.frameOptions } : {}), rows: withShared(template.rows, siteData.shared, template.shared) };
          });
        }
        // The About copy, mirrored from Substack's About page or written through a door (mockup 05).
        const aboutFile = new URL('src/content/about.md', config.root);
        const aboutHtml = existsSync(aboutFile) ? renderMarkdown(readFileSync(aboutFile, 'utf8')) : '';
        siteConfigBuilt = site;
        llmsWanted = record.crawlers.llmsTxt;
        unlisted = new Set([...resolved.pages.filter((p) => p.noindex).map((p) => p.path), ...pages.filter((p) => p.fields.noindex).map((p) => `/${p.slug}`)]);

        profile.mark('resolve pages, navigation, Markdown');
        const tokens = loadTokens(options.tokens);
        const look = withLookColors(await resolveLook(siteData?.look ? lookFromSite(siteData.look, record.sources.substack?.url) : lookOption(record), config.root, tokens), siteData?.look?.colors, tokens);
        for (const message of look.messages) logger.warn(message);
        // Each of the Look's grounds holds the contrast floors too, named by the ground (the kit fidelity entry, B2).
        const grounds = groundFailures(siteData?.look?.grounds, tokens);
        if (grounds.length) throw new LookContrastError(`The grounds in site/look.json fall below the contrast floors (PAGE-5):\n${grounds.map((f) => `  ${f.ground}: ${f.fg} on ${f.bg}: ${f.ratio.toFixed(2)}:1, needs ${f.floor}:1`).join('\n')}`);
        // The log is the operator's; a house look's name never reaches a public page (Step 9).
        logger.info(`Building ${site.name} in the ${look.look} look.`);
        profile.mark('look');

        // The parts gallery, in development only (relay entry 52): each extra look's token layer, set
        // after the site's own, and the parts' stylesheet.
        const gallery = options.gallery && (command === 'dev' || process.env.HELIOSTET_GALLERY === '1') ? options.gallery : null;
        const galleryLooks: Record<string, string> = { site: '' };
        for (const [name, file] of Object.entries(gallery?.looks ?? {})) {
          const at = new URL(file, config.root);
          galleryLooks[name] = minifyCss(tokensCss(tokens, parseOverlay(JSON.parse(readFileSync(at, 'utf8')) as unknown, `The gallery look at ${fileURLToPath(at)}`)));
          addWatchFile(at);
        }
        if (gallery) injectRoute({ pattern: GALLERY_ROUTE, entrypoint: fileURLToPath(new URL(gallery.page, config.root)) });
        galleryAssets = gallery?.assets ? new URL(gallery.assets.replace(/\/?$/, '/'), config.root) : null;

        updateConfig({
          ...(config.site ? {} : { site: site.url }),
          // Astro 5's lossless whitespace, which Heliostet's components and a site's own were written for. Astro 7's
          // default ('jsx') drops the space where markup breaks a line between two elements, so words run together
          // in what a screen reader and a search engine read (relay entry 127, Major 2).
          compressHTML: true,
          // The one stylesheet stays inline, so a reading page makes no second request (PAGE-6). A
          // site drawing its own frame keeps its own stylesheets as it had them (decision 0019).
          ...(options.own?.frame ? {} : { build: { inlineStylesheets: 'always' as const } }),
          vite: { plugins: [ownPlugin(config.root, options.own), readingPlugin(config.root, siteData?.reading), buildModule(SITE_MODULE, { site, css: () => stylesheet, toolCss: () => toolStylesheet }), buildModule(PAGES_MODULE, { resolved, pages: rendered, about: aboutHtml }), buildModule(GALLERY_MODULE, { looks: galleryLooks, partsCss: () => (gallery ? minifyCss(readFileSync(partsCss, 'utf8') + readFileSync(rowsCss, 'utf8')) : '') }), buildModule(SITE_DATA_MODULE, { sitePages: sitePagesData, entries: entryData, ctx: partContext, pageCss: () => (siteData ? ownTokens + minifyCss(readFileSync(partsCss, 'utf8') + readFileSync(rowsCss, 'utf8')) : '') })] },
        });
        // Every reading route the record and the content imply (Step 6). A route the site has its own
        // page for is the site's (relay entry 25).
        const videos = resolved.archive.some((p) => p.item.video || p.recording);
        if (site.vocabulary.hero === 'own') {
          if (!own.has('/') && !claimed.has('/')) throw new OwnFrontPageError('vocabulary.hero is own, so the site supplies its front page at src/pages/index.astro, and there is none.');
        } else route('/', 'Front.astro');
        // A site with no archive yet has no Latest and no item pages (relay entry 25).
        if (site.archive) {
          route('/latest/[...page]', 'Latest.astro');
          if (!siteData?.collections.stories) route(`/${site.writingSlug}/[slug]`, 'Story.astro');
          if (site.vocabulary.basis === 'writing') {
            if (videos) route('/watch', 'WatchIndex.astro');
            if (!siteData?.collections.videos) route('/watch/[id]', 'Watch.astro');
          }
          route('/episode/[slug]', 'Episode.astro');
        }
        if (resolved.clips.length) route('/clips', 'Clips.astro');
        if (resolved.series.length) {
          route('/series', 'SeriesIndex.astro');
          route('/series/[slug]', 'Series.astro');
        }
        route('/about', 'About.astro');
        if (site.principals.some((p) => !p.entityHome)) route('/host/[id]', 'Host.astro');
        if (site.subscribe.length > 0) route('/subscribe', 'Subscribe.astro');
        if ((site.subscribe.length > 0 || site.social.length > 0) && !siteData?.without.includes('links')) route('/links', 'Links.astro');
        if (!siteData?.without.includes('status')) route('/status', 'Status.astro');
        if (site.nav.some((n) => n.href === '/notes')) route('/notes', 'Notes.astro');
        if (site.show) route('/show', 'Show.astro');
        if (site.merch) route('/merch', 'Merch.astro');
        if (rendered.some((p) => p.template !== 'own')) route('/[page]', 'Page.astro');
        route('/404', 'NotFound.astro');
        // The pages made of parts, and each collection at its own address (relay entry 53).
        if (sitePagesData.length) injectRoute({ pattern: '/[...page]', entrypoint: fileURLToPath(new URL('SitePage.astro', siteDir)) });
        const SITE_ROUTES = { stories: 'SiteStories.astro', chapters: 'SiteChapters.astro', videos: 'SiteVideos.astro' } as const;
        for (const [collection, c] of Object.entries(siteData?.collections ?? {})) {
          if (entryData.some((e) => e.collection === collection)) injectRoute({ pattern: c.address.replace(/\{(\w+)\}/g, '[$1]'), entrypoint: fileURLToPath(new URL(SITE_ROUTES[collection as keyof typeof SITE_ROUTES], siteDir)) });
        }
        // The site check (relay entry 54, CMP-5), before anything is drawn: every error at once, and
        // the warnings into the build report.
        if (siteData) {
          const fileAddresses = new Set(siteData.pages.map((p) => p.address));
          const listed = new Set(siteEntries.map((e) => e.item.id));
          const addresses = [
            ...siteEntries.map((e) => ({ address: e.address, owner: `the ${e.collection} item ${e.slug}` })),
            ...rendered.filter((p) => p.template !== 'own').map((p) => ({ address: `/${p.slug}`, owner: `${PAGES_DIR}${p.slug}.md` })),
            ...[...own].filter((pattern) => !pattern.includes('[')).map((pattern) => ({ address: pattern, owner: `src/pages${pattern === '/' ? '/index' : pattern}.astro` })),
            // A page of the site's own that numbers its pages (latest/[...page].astro) makes its first at the list's address (relay entry 55).
            ...[...own].filter((pattern) => /\/\[\.\.\.\w+\]$/.test(pattern) && !listAt(pattern).includes('[')).map((pattern) => ({ address: listAt(pattern), owner: `src/pages${pattern}.astro` })),
            ...resolved.pages.filter((p) => !listed.has(p.item.id)).map((p) => ({ address: p.path, owner: `the item ${p.item.id}` })),
            ...resolved.series.map((s) => ({ address: `/series/${s.slug}`, owner: `the series ${s.slug}` })),
            ...injected.filter((pattern) => !pattern.includes('[') && !fileAddresses.has(pattern)).map((pattern) => ({ address: pattern, owner: 'a reading page' })),
            ...(injected.includes('/latest/[...page]') && !fileAddresses.has('/latest') ? [{ address: '/latest', owner: 'a reading page' }] : []),
          ];
          const ownList = ownVariantList(config.root, options.own);
          const checked = validateSite({ pages: siteData.pages, templates: siteData.templates, shared: siteData.shared, nav: siteData.nav, collections: siteData.collections, locked: siteData.locked, addresses, items: partContext.items, own: { variants: new Set(ownList.map((v) => v.key)), titles: new Set(ownList.filter((v) => v.title).map((v) => v.key)) }, emailForm: new Set(record.exceptions?.emailForm?.pages ?? []), emailFormBand: record.exceptions?.emailForm?.band === true });
          // A font kit (decision 0018): read its stylesheet once, warn about what it's missing, and
          // build anyway, with the fallback, when it can't be read.
          const fonts = siteData.look?.fonts;
          if (fonts) {
            site.fontKit = { origin: KIT_ORIGIN, stylesheet: kitStylesheet(fonts.kit) };
            try {
              for (const w of kitWarnings(fonts, await readKit(fonts.kit))) checked.warnings.push({ page: 'site/look.json', field: w.field, message: w.message });
            } catch (error) {
              const message = `The font kit ${fonts.kit.id} couldn’t be read at build (${(error as Error).message}). The pages keep its link, and their text shows in the nearest carried faces until it loads.`;
              logger.warn(message);
              notices.push({ code: 'font-kit', message, items: [kitStylesheet(fonts.kit)] });
            }
          }
          if (checked.errors.length) throw new SiteDataError(`The site’s pages don’t check out (${checked.errors.length} ${checked.errors.length === 1 ? 'problem' : 'problems'}):\n${checked.errors.map((i) => `  ${issueLine(i)}`).join('\n')}`);
          if (checked.warnings.length) {
            const message = `The site check has ${checked.warnings.length} ${checked.warnings.length === 1 ? 'warning' : 'warnings'}; see ${REPORT_FILE}.`;
            logger.warn(message);
            notices.push({ code: 'site-check', message, items: checked.warnings.map(issueLine) });
          }
        }

        // One stylesheet for every page, inline in its head: the token layer, the fonts, the design
        // system's component rules, then Heliostet’s own layer. No script reaches the browser (PAGE-6).
        // The look's own options (relay entry 59): its bands and its disclosure's colors.
        const tokenLayer = tokensCss(tokens, look.overlay) + lookExtrasCss(siteData?.look) + bandHeadingCss(siteData?.look, resolvedColors(tokens, look.overlay)) + (siteData?.look?.layout?.type === 'scale' ? typeScaleCss(tokens, look.overlay) : '') + groundsCss(siteData?.look?.grounds, tokens, siteData?.look?.bands?.colors);
        const colors = resolvedColors(tokens, look.overlay);
        cardColors = {
          ground: colors.surface ?? cardColors.ground,
          ink: colors.ink ?? cardColors.ink,
          inverse: colors['surface-inverse'] ?? cardColors.inverse,
          onInverse: colors['on-inverse'] ?? cardColors.onInverse,
          accent: colors.volt ?? cardColors.accent,
        };
        // Self-hosted fonts in the same stylesheet; a face Heliostet does not carry falls back to
        // the nearest one it does, and the build report names it (DS-5).
        // With a font kit, the carried faces are its fallbacks: the kit's families come first (decision 0018).
        const kitLook = siteData?.look?.fonts ?? null;
        const plan = planFonts(kitLook ? fallbackStacks(kitLook, fontStacks(tokenLayer)) : fontStacks(tokenLayer));
        // The preview cards are drawn at build, so a kit's family can't reach them; they use its carried fallback.
        displayFace = kitLook ? firstFamily(fallbackStacks(kitLook, fontStacks(tokenLayer)).display) : (plan.replaced.find((r) => r.slot === 'display')?.with ?? firstFamily(fontStacks(tokenLayer).display));
        // The preview cards' title weight is the page title's, the look's display-lg (ENT-5).
        displayWeight = Number([...tokenLayer.matchAll(/\.display-lg\s*\{[^}]*font-weight:\s*(\d+)/g)].pop()?.[1] ?? displayWeight);
        // The tool pages' faces are served beside the look's; no reading page names them.
        const tool = heliostetStylesheet();
        toolStylesheet = minifyCss(tool.css);
        fonts = new Map([...plan.files, ...tool.fontFiles]);
        for (const r of plan.replaced) {
          const message = `The ${r.slot} face ${r.family} is not one Heliostet carries; the site uses ${r.with}, the nearest licensed face. See .heliostet/report.json.`;
          logger.warn(message);
          notices.push({ code: 'font-fallback', message, items: [`${r.slot}:${r.family}:${r.with}`] });
        }
        const bundle = readFileSync(bundleCss, 'utf8');
        stylesheet = minifyCss(tokenLayer + plan.css + (kitLook ? kitCss(kitLook) : '') + readingComponentsCss(bundle) + componentsCss(bundle, options.components ?? []) + readFileSync(baseCss, 'utf8'));
        // The frame loads the site's own font kit and names its faces; the look's own stacks follow them.
        ownTokens = options.own?.frame ? minifyCss(scopedTokens(tokenLayer)) : '';

        addWatchFile(options.tokens ?? new URL('tokens.json', designDir));
        for (const watched of look.files) addWatchFile(watched);
        profile.mark('stylesheet and fonts');
      },
      // Joined items' old addresses, for Cloudflare's redirects file (ADM-7). Step 7 adds the
      // Substack /p/ map and imported old slugs to the same file (FMT-7).
      // The font files the stylesheet names, served at /_kit/fonts/ while developing.
      'astro:server:setup': ({ server }) => {
        server.middlewares.use(GALLERY_ASSETS, (req, res, next) => {
          const name = decodeURIComponent((req.url ?? '').replace(/^\//, '').split('?')[0] ?? '');
          const file = galleryAssets && /^[\w.-]+$/.test(name) ? new URL(name, galleryAssets) : null;
          if (!file || !existsSync(file)) return next();
          res.setHeader('content-type', name.endsWith('.svg') ? 'image/svg+xml' : name.endsWith('.png') ? 'image/png' : 'image/jpeg');
          createReadStream(file).pipe(res);
        });
        server.middlewares.use(FONT_PATH, (req, res, next) => {
          const source = fonts.get((req.url ?? '').replace(/^\//, '').split('?')[0] ?? '');
          if (!source) return next();
          res.setHeader('content-type', 'font/woff2');
          createReadStream(source).pipe(res);
        });
      },
      'astro:build:done': async ({ dir, pages, logger }) => {
        if (!resolved || !siteConfigBuilt || !root) return;
        profile.mark('Astro: bundle and render pages');
        const site = siteConfigBuilt;
        // A page's file: /x/index.html, or /x.html when the site builds pages as files (relay entry 55).
        const fileOf = (path: string) => new URL(`.${path === '/' ? '/index.html' : path === '/404' || fileFormat ? `${path}.html` : `${path}/index.html`}`, dir);
        // The pages Astro built, without its endpoints (a feed, a sitemap the site makes itself).
        const paths = pages.map((p) => `/${p.pathname}`.replace(/\/$/, '').replace(/\.html$/, '') || '/').filter((path) => existsSync(fileOf(path)));
        const noindexPage = /<meta name="robots" content="noindex[,"]/;
        const built = new Set(paths);
        const html = paths.map((path) => ({ path, html: readFileSync(fileOf(path), 'utf8') }));

        // The fonts, when a page Heliostet draws names them; a site drawing its own frame may have none.
        if (html.some((h) => h.html.includes(FONT_PATH))) {
          const fontDir = new URL(`.${FONT_PATH}`, dir);
          mkdirSync(fontDir, { recursive: true });
          for (const [name, source] of fonts) copyFileSync(source, new URL(name, fontDir));
        }
        if (galleryAssets && existsSync(galleryAssets)) cpSync(galleryAssets, new URL(`.${GALLERY_ASSETS}/`, dir), { recursive: true });
        // Heliostet's marks, for the tool pages' lockup and favicon, when a page names them; a file the
        // site has at the same place is the site's.
        if (html.some((h) => h.html.includes(HELIOSTET_MARKS_PATH))) cpSync(new URL('marks/', heliostetDir), new URL(`.${HELIOSTET_MARKS_PATH}`, dir), { recursive: true, force: false });

        // Redirects (FMT-7): joins, merged series, Substack's /p/<slug>, and the imported old-slug map.
        const importedFile = new URL(REDIRECTS_FILE, root);
        const imported: Redirect[] = existsSync(importedFile) ? readRedirects(readFileSync(importedFile, 'utf8'), REDIRECTS_FILE) : [];
        // A file the site serves (public/files/, relay entry 91) is built too: an old address of a moved PDF redirects to it.
        for (const r of imported) if (/\.[a-z0-9]{2,5}$/i.test(r.to) && existsSync(new URL(`.${r.to}`, dir))) built.add(r.to);
        const { redirects, missing } = assembleRedirects(resolved, built, imported);
        if (missing.length) {
          const message = `${missing.length} ${missing.length === 1 ? 'redirect points' : 'redirects point'} at no page and ${missing.length === 1 ? 'was' : 'were'} left out; see ${REPORT_FILE}`;
          logger.warn(message);
          notices.push({ code: 'redirect-target-missing', message, items: missing.map((r) => `${r.from} -> ${r.to}`) });
        }
        if (redirects.length > CLOUDFLARE_STATIC_REDIRECTS) {
          notices.push({ code: 'redirects-over-limit', message: `${redirects.length} redirects; Cloudflare serves ${CLOUDFLARE_STATIC_REDIRECTS} static ones.`, items: [] });
        }
        // The site's own redirects file (public/_redirects) comes first, and a rule of Heliostet's that
        // one of the site's already covers is left out (relay entry 55).
        const redirectsAt = new URL('_redirects', dir);
        const ownRules = existsSync(redirectsAt) ? readFileSync(redirectsAt, 'utf8') : '';
        const covered = ownRedirectSources(ownRules);
        const added = redirects.filter((r) => !covered.some((test) => test(r.from)));
        if (added.length) writeFileSync(redirectsAt, `${ownRules ? `${ownRules.replace(/\n*$/, '\n')}` : ''}${redirectsFile(added)}`);
        profile.mark('fonts copied, redirects');

        // ENT-3: every canonical is the page's own clean address, built and not redirected.
        const faults = canonicalFaults(html, site.url, built, new Set(added.map((r) => r.from)));
        profile.mark('canonical check (ENT-3)');
        if (faults.length) throw new CanonicalError(`A canonical must be the page's own address and must not redirect (ENT-3):\n${faults.map((f) => `  ${f}`).join('\n')}`);

        // The sitemap with lastmod (ENT-4), the full-text feed (ENT-4), and robots.txt (ENT-6).
        // A page marked noindex, the site's own included, stays out of the sitemap (relay entry 25).
        // A file the site makes itself, or keeps in public/, is the site's (relay entry 55).
        const kept = new Set([...unlisted, ...html.filter((h) => noindexPage.test(h.html)).map((h) => h.path)]);
        const write = (name: string, body: () => string) => {
          if (!existsSync(new URL(name, dir))) writeFileSync(new URL(name, dir), body());
        };
        const all = resolved;
        write('sitemap.xml', () => sitemapXml(site, paths, kept, lastModified(all)));
        write('feed.xml', () => feedXml(site, all));
        write('robots.txt', () => robotsTxt(site));
        // No llms.txt unless the client asked for one (ENT-7).
        if (llmsWanted) write('llms.txt', () => llmsTxt(site, all));
        if (site.indexNowKey) writeFileSync(new URL(`${site.indexNowKey}.txt`, dir), site.indexNowKey);
        profile.mark('sitemap, feed, robots');

        // One 1280 by 720 preview per page, from the page's local image (ENT-5, FMT-8).
        const images = new Map<string, string>();
        // A story that carries the satire disclosure says so on its card (relay entry 59).
        const disclosed = new Set(resolved.pages.filter((p) => p.item.disclosure === 'satire').map((p) => p.path));
        const satireLabel = siteDataLabel;
        for (const page of resolved.pages) {
          const src = (page.recording ?? page.item).video?.poster || page.item.cover?.src || '';
          if (src.startsWith('/')) images.set(page.path, fileURLToPath(new URL(`public${src}`, root)));
        }
        const face = { family: displayFace, weight: displayWeight };
        const logo = site.logo ? fileURLToPath(new URL(`public${site.logo.src}`, root)) : null;
        let previews = 0;
        const decode = (t: string) => t.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
        // As many cards at once as the machine has cores: on a 600-post site the cards are most of
        // the build (NFR-2).
        // A site whose frame names its own share images gets none drawn (relay entry 55).
        const queue = shareImages === 'own' ? [] : html.filter(({ path }) => path !== '/404');
        const worker = async () => {
          for (let next = queue.shift(); next; next = queue.shift()) {
            const title = decode(/<meta property="og:title" content="([^"]*)"/.exec(next.html)?.[1] ?? site.name);
            await renderCard({ title, site: title === site.name ? new URL(site.url).hostname : site.name, image: images.get(next.path) ?? null, logo, colors: cardColors, face, ...(disclosed.has(next.path) ? { label: satireLabel } : {}) }, new URL(`.${ogPath(next.path)}`, dir));
            previews += 1;
          }
        };
        await Promise.all(Array.from({ length: Math.max(1, availableParallelism()) }, worker));
        profile.mark(`preview cards (${previews})`);

        writeReport(root, { built: new Date().toISOString(), heliostet: heliostetVersion, notices, previews: { count: previews, ...face } });
        profile.mark('report');
        for (const line of profile.write(root)) logger.info(line);
      },
    },
  };
}

/** Serves build data to the templates as a module; it is read at build and never reaches the browser. */
function buildModule(id: string, exports: Record<string, unknown>) {
  const resolved = `\0${id}`;
  // A function value is read when the module loads, after the whole setup hook has run.
  const value = (v: unknown) => JSON.stringify(typeof v === 'function' ? (v as () => unknown)() : v);
  return {
    name: `heliostet:${id.split('/').pop()}`,
    resolveId: (source: string) => (source === id ? resolved : undefined),
    load: (source: string) => (source === resolved ? Object.entries(exports).map(([name, v]) => `export const ${name} = ${value(v)};`).join('\n') : undefined),
  };
}

/** Comments and the whitespace around punctuation out of a stylesheet; values are untouched. */
export function minifyCss(css: string): string {
  return css
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/\s+/g, ' ')
    // Not the space before a colon: in a selector it's a descendant combinator, and .x :hover isn't .x:hover (Cowork's
    // call, November 4, 7:05 pm). The space after a colon goes, as before.
    .replace(/\s*([{};,>])\s*/g, '$1')
    .replace(/:\s+/g, ':')
    .replace(/;}/g, '}')
    .trim();
}

/**
 * The site's own redirect rules' sources, as tests on a path: a :name or * matches one or more
 * segments, as Cloudflare reads them.
 */
function ownRedirectSources(rules: string): ((path: string) => boolean)[] {
  return rules
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith('#'))
    .map((line) => line.split(/\s+/)[0] ?? '')
    .filter(Boolean)
    .map((from) => {
      const test = new RegExp(`^${from.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/:[A-Za-z]+/g, '[^/]+').replace(/\*/g, '.*')}$`);
      return (path: string) => test.test(path);
    });
}

/**
 * The site's own reading of a story (relay entry 125), as a module the story page imports: the module site.json
 * names, re-exported, or a reading of null. Heliostet holds no site's code; the site's module is its own.
 */
export function readingPlugin(root: URL, path: string | undefined) {
  const resolved = `\0${READING_MODULE}`;
  const file = path ? fileURLToPath(new URL(path, root)) : null;
  if (file && !existsSync(file)) throw new Error(`site/site.json names the reading module ${path}, and there is no such file.`);
  return {
    name: 'heliostet:reading',
    resolveId: (source: string) => (source === READING_MODULE ? resolved : undefined),
    load: (source: string) => (source === resolved ? (file ? `export { reading } from ${JSON.stringify(file.replace(/\\/g, '/'))};` : 'export const reading = null;') : undefined),
  };
}

/** The site's own frame and variants, as a module the page templates import (decision 0019). */
function ownPlugin(root: URL, own: OwnOptions | undefined) {
  const resolved = `\0${OWN_MODULE}`;
  return {
    name: 'heliostet:own',
    resolveId: (source: string) => (source === OWN_MODULE ? resolved : undefined),
    load: (source: string) => (source === resolved ? ownModuleCode(root, own) : undefined),
  };
}
