// How a site draws its stories in parts (relay entry 59): titles in title case or as published, the
// bylines on a card with each principal's page, the tags a card shows, the satire disclosure, and the
// picture at the width a card needs. All of it is the site's settings in site.json, applied once to
// every item the parts list from, so each part draws the same story the same way.

import { titler, type TitleWords } from '../build/titlecase.js';
import type { Item } from '../build/item.js';
import type { ContentItem } from '../parts/types.js';

export interface Drawing {
  titles: 'as-published' | 'chicago';
  titleWords: TitleWords;
  bylines: { pages: Record<string, string>; principalsFirst: boolean; alternate: boolean; house?: { name: string; to?: string | undefined } | undefined };
  cardTags: { label: string; pattern: string; flags: string }[];
  satire: { label: string; levels: { level: number; name: string }[] };
  imageResizing: 'substack' | 'cloudflare' | 'none';
  people: Record<string, PersonData>;
}

/** A person card's words, photo, and accounts (relay entry 59). */
export interface PersonData { role: string; bio: string; photo?: { src: string; alt: string; small?: string | undefined } | undefined; links: { network: string; to: string }[] }

export const DEFAULT_DRAWING: Drawing = {
  titles: 'as-published',
  titleWords: {},
  bylines: { pages: {}, principalsFirst: false, alternate: false },
  cardTags: [],
  satire: { label: 'Contains satire', levels: [] },
  imageResizing: 'none',
  people: {},
};

/** A picture at a width: Substack's image service rewritten to the width, or Cloudflare's, or as it is. */
export function sizedImage(url: string, width: number, resizing: Drawing['imageResizing']): string {
  if (resizing === 'cloudflare') return `/cdn-cgi/image/width=${width},format=auto,quality=80/${url}`;
  if (resizing === 'substack') {
    const m = /^(https:\/\/substackcdn\.com\/image\/fetch\/)(\$s_![^,/]+!,)?([^/]*)\/(https?%3A.*)$/.exec(url);
    if (m) {
      const [, base, sig = '', params = '', src] = m;
      const kept = params.split(',').filter((p) => p && !p.startsWith('w_'));
      return `${base}${sig}w_${width},${kept.join(',')}/${src}`;
    }
  }
  return url;
}

/**
 * The build's turn (relay entry 59): 0 or 1, by the half hour the build runs in. HELIOSTET_BUILD_TIME
 * pins it, so two builds compared side by side take the same turn.
 */
export function buildTurn(env: string | undefined = process.env.HELIOSTET_BUILD_TIME, now = Date.now()): 0 | 1 {
  const at = env ? Date.parse(env) : now;
  return (Math.floor((Number.isNaN(at) ? now : at) / 1_800_000) % 2) as 0 | 1;
}

export interface Person { id: string; name: string; first: string; href: string; card?: PersonData }

/** The site's people: each principal with a page, by first name too, in the order this build takes. */
export function peopleOf(principals: { id: string; name: string }[], d: Drawing, turn: 0 | 1): Person[] {
  const people = principals.flatMap((p) => (d.bylines.pages[p.id] ? [{ id: p.id, name: p.name, first: p.name.split(/\s+/)[0] ?? p.name, href: d.bylines.pages[p.id] as string, ...(d.people[p.id] ? { card: d.people[p.id] } : {}) }] : []));
  return d.bylines.alternate && turn === 1 ? people.reverse() : people;
}

/** Strips pictographs (emoji) from a name, as a byline should read. */
const plainName = (name: string) => name.replace(/[\p{Extended_Pictographic}\u{FE0F}]/gu, '').trim();

/** The item as the site draws it: its title, its credits, its tags, its disclosure, and its picture's sizes. */
export function drawItem(item: ContentItem, source: Pick<Item, 'bylines' | 'tags' | 'disclosure'> | undefined, d: Drawing, siteName: string): ContentItem {
  const title = titler(d.titles, d.titleWords)(item.title);
  const out: ContentItem = { ...item, title };
  if (source) {
    // Bylines. A byline that is the site's own name is no one's. With principals first (the Press's
    // rule): the principals, in the source's order, then everyone else but the house; with no
    // principal, a story that is the house's (no byline, the house's name first, or no one else)
    // leads with the house's name.
    const house = d.bylines.house;
    const isHouse = (n: string) => !!house && n === house.name;
    const named = source.bylines.filter((b) => b.name !== siteName);
    const others = named.filter((b) => !b.principal && !isHouse(b.name)).map((b) => ({ name: plainName(b.name) }));
    const principals = [...new Map(named.filter((b) => b.principal).map((b) => [b.principal as string, b])).values()].map((b) => {
      const href = d.bylines.pages[b.principal as string];
      return { name: b.name, ...(href ? { href } : {}) };
    });
    let credits: { name: string; href?: string }[];
    if (!d.bylines.principalsFirst) credits = named.filter((b) => !isHouse(b.name)).map((b) => (b.principal ? principals.find((p) => p.name === b.name) ?? { name: b.name } : { name: plainName(b.name) }));
    else credits = [...principals, ...others];
    const houseLeads = !!house && !principals.length && (named.length === 0 || isHouse(named[0]!.name) || others.length === 0);
    if (houseLeads) credits = [{ name: house.name, ...(house.to ? { href: house.to } : {}) }, ...credits];
    out.credits = credits;
    const tags = d.cardTags.filter((t) => {
      const re = new RegExp(t.pattern, t.flags);
      return re.test(item.title) || source.tags.some((x) => re.test(x));
    });
    if (tags.length) out.tags = tags.map((t) => t.label);
    if (source.disclosure === 'satire') out.disclosure = { kind: 'satire', label: d.satire.label };
  }
  if (item.image && d.imageResizing !== 'none') {
    out.image = { ...item.image, src: sizedImage(item.image.src, 640, d.imageResizing), srcset: `${sizedImage(item.image.src, 640, d.imageResizing)} 640w, ${sizedImage(item.image.src, 1280, d.imageResizing)} 1280w` };
  }
  return out;
}
