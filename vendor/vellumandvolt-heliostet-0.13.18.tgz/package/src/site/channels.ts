// A client's channels, in its order (relay entry 91): each subscribe destination, the Support link, then each social
// account, from the client record. The Links part's "From the channels list" draws them; the Page Builder's preview
// and its check read them the same way (relay entry 99, fix 6).

import type { PartContext } from '../parts/types.js';
import { destinations } from '../config/subscribe.js';
import { SOCIAL_LABELS } from '../config/social-labels.js';
import type { ClientRecord } from '../config/schema.js';

export function channelsOf(raw: unknown): NonNullable<PartContext['channels']> {
  const record = raw as Partial<ClientRecord> | null;
  if (!record || typeof record !== 'object') return [];
  const subscribe = (() => { try { return destinations(record as ClientRecord); } catch { return []; } })();
  const social = Array.isArray(record.social) ? record.social : [];
  const word = (p: string) => p.charAt(0).toUpperCase() + p.slice(1);
  return [
    ...subscribe.map((d) => ({ label: d.label, to: d.url, kind: 'subscribe' as const })),
    ...(record.support ? [{ label: record.support.label, to: record.support.url, kind: 'support' as const }] : []),
    ...social.map((s) => ({ label: s.label ?? SOCIAL_LABELS[s.platform] ?? word(s.platform), to: s.url, kind: 'social' as const, network: s.platform })),
  ];
}
