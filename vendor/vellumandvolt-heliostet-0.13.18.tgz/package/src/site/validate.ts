// validateSite (relay entries 53 and 54), as the site's build runs it: the core (validate-core.ts), with the build's
// test for an empty rich-text field set by importing the parts' validator (relay entry 91).

import '../parts/validate.js';

export * from './validate-core.js';
