// The layout (decision 0017; Lawrence's model of October 20, relay entry 53): a page is a stack of
// rows. A row with both sidebars off is a band, the full width. Consecutive rows with the same sides
// on form a run: each side's sidebar is one column, as tall as the run. Each run is a twelve-column
// grid: one sidebar on gives the main content eight columns (two-thirds) and the sidebar four (a
// third); both on give the main content six (a half) and each sidebar three (a quarter). Rows join
// only when they have the same sides on (relay entry 54), so every row keeps the model's widths.

export type Side = 'left' | 'right';

export interface LayoutRow<P> {
  id: string;
  main: P[];
  left: { on: boolean; parts: P[] };
  right: { on: boolean; parts: P[] };
  join: boolean;
  /** A background behind the row, the page's full width (relay entry 113). */
  band?: string | undefined;
}

/** One sidebar column in a run: the rows it spans (by their place in the run) and its parts. */
export interface Column<P> {
  side: Side;
  /** First and last row it spans, 0-based within the run. */
  from: number;
  to: number;
  /** Twelfths: 4 for a third, 3 for a quarter. */
  width: 3 | 4;
  parts: P[];
}

export type Block<P> =
  | { kind: 'band'; row: LayoutRow<P> }
  | {
      kind: 'run';
      rows: LayoutRow<P>[];
      /** Each row's main content, by grid column: [start, end) in twelfths, 1-based as CSS has it. */
      mains: { start: number; end: number }[];
      columns: Column<P>[];
    };

const isBand = <P>(row: LayoutRow<P>) => !row.left.on && !row.right.on;

/** Whether `next` continues the run `prev` is in: it joins, and has the same sides on (relay entry 54). */
const continues = <P>(prev: LayoutRow<P>, next: LayoutRow<P>) => next.join && prev.left.on === next.left.on && prev.right.on === next.right.on;

/** The rows as bands and runs, with each run's columns and each row's main width. */
export function layoutRows<P>(rows: LayoutRow<P>[]): Block<P>[] {
  const blocks: Block<P>[] = [];
  let run: LayoutRow<P>[] = [];
  const close = () => {
    if (run.length) blocks.push(runBlock(run));
    run = [];
  };
  for (const row of rows) {
    if (isBand(row)) {
      close();
      blocks.push({ kind: 'band', row });
      continue;
    }
    const prev = run[run.length - 1];
    if (prev && !continues(prev, row)) close();
    run.push(row);
  }
  close();
  return blocks;
}

function runBlock<P>(rows: LayoutRow<P>[]): Block<P> {
  const columns: Column<P>[] = [];
  for (const side of ['left', 'right'] as const) {
    let open: Column<P> | null = null;
    rows.forEach((row, i) => {
      if (!row[side].on) {
        open = null;
        return;
      }
      if (!open) {
        open = { side, from: i, to: i, width: 4, parts: [] };
        columns.push(open);
      }
      open.to = i;
      open.parts.push(...row[side].parts);
      if (row.left.on && row.right.on) open.width = 3;
    });
  }
  const widthAt = (side: Side, i: number) => columns.find((c) => c.side === side && c.from <= i && i <= c.to)?.width ?? 0;
  const mains = rows.map((_, i) => ({ start: 1 + widthAt('left', i), end: 13 - widthAt('right', i) }));
  return { kind: 'run', rows, mains, columns };
}
