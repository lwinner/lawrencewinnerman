// The stock recipes (CMP-4, relay entry 53): sixteen starting pages (the scope's site map, the Article Desk's Story Landing, relay entry 69, and
// the Page Builder's Blank, Speaking, and Press Kit, relay entry 91), each a
// page file with stand-in fields in package/src/recipes/. "Add a page" copies one into the site's
// site/pages/ (or, for a collection's page, site/templates/) under its own id and address, and the
// page can then change freely. The reading templates stay as they are until a site moves onto these.

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { pageSchema, templateSchema } from './schema.js';

export const RECIPES = ['home', 'index', 'story', 'series', 'chapter', 'work', 'about', 'press', 'project', 'links', 'guide', 'videos', 'story-landing', 'blank', 'speaking', 'press-kit'] as const;
export type Recipe = (typeof RECIPES)[number];

export const recipesDir = new URL('../../src/recipes/', import.meta.url);

/** A recipe as its JSON, unchanged. */
export function readRecipe(name: Recipe): Record<string, unknown> {
  return JSON.parse(readFileSync(new URL(`${name}.json`, recipesDir), 'utf8')) as Record<string, unknown>;
}

export class NewPageError extends Error {
  override name = 'NewPageError';
}

/**
 * Copies a recipe into the site at `root`: a page at site/pages/<id>.json with the address and title
 * given, or for the Story and Chapter recipes, a template at site/templates/<id>.json. Refuses an
 * unknown recipe and a file that already exists.
 */
export function newPage(root: URL, recipe: string, id: string, options: { address?: string; title?: string } = {}): string {
  if (!(RECIPES as readonly string[]).includes(recipe)) throw new NewPageError(`There’s no recipe called “${recipe}.” The recipes are ${RECIPES.join(', ')}.`);
  const data = readRecipe(recipe as Recipe);
  const isTemplate = 'collection' in data;
  const path = `site/${isTemplate ? 'templates' : 'pages'}/${id}.json`;
  const file = new URL(path, root);
  if (existsSync(file)) throw new NewPageError(`${path} already exists.`);
  const page = isTemplate
    ? data
    : { ...data, $schema: '../../node_modules/@vellumandvolt/heliostet/schema/page.schema.json', id, ...(options.address ? { address: options.address } : {}), ...(options.title ? { title: options.title } : {}), recipe };
  const parsed = (isTemplate ? templateSchema : pageSchema).safeParse(page);
  if (!parsed.success) throw new NewPageError(`The ${recipe} recipe with those settings doesn’t make a page: ${parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ')}`);
  mkdirSync(new URL('.', file), { recursive: true });
  writeFileSync(file, `${JSON.stringify(page, null, 2)}\n`);
  return path;
}
