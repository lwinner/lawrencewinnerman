// The Substack check's command, run by the client repository's substack.yml (SITE-6, decision 0014).
// The workflow unpacks dist/watch/ from the vendored tarball and runs run-substack-check.js with
// Node alone, with no install: these files import only each other and Node's own modules.
//
// It reads Substack (the feed, then the archive), reads its previous record back from GitHub, and
// writes three step outputs: `record` (the line the next step takes as its name), `rebuild`, and
// `fail`. It always exits 0, so a 429 is a soft miss and not a red run; the workflow's next step
// fails the run when `fail` is true, after MISS_LIMIT misses in a row.
import { appendFileSync, existsSync, readFileSync } from 'node:fs';
import { decide, fingerprintOf, formatRecord, lastRun, MISS_LIMIT, readSubstack, SubstackMiss } from './substack.js';

export interface CheckEnv {
  /** owner/name, from Actions. */
  GITHUB_REPOSITORY?: string;
  /** The job's token, with Actions: read. */
  GITHUB_TOKEN?: string;
  /** Where step outputs go, from Actions. */
  GITHUB_OUTPUT?: string;
  /** The Substack's address; read from client.json when not set. */
  SUBSTACK_URL?: string;
}

export interface CheckOutcome {
  outputs: { record: string; rebuild: boolean; fail: boolean };
  /** Lines for the log, as Actions workflow commands. */
  log: string[];
}

/** The Substack address from client.json, or null when the site has none. */
export function substackFromRecord(path = 'client.json'): string | null {
  const record = JSON.parse(readFileSync(path, 'utf8')) as { sources?: { substack?: { url?: string } } };
  return record.sources?.substack?.url ?? null;
}

type Fetch = (url: string, init?: RequestInit) => Promise<Response>;

/** Where the import writes a Substack post; the same folder as SUBSTACK_DIR, kept here so these files import only each other. */
const CONTENT = 'src/content/substack/';

/** Whether the repository's content holds a post, from the workflow's checkout (relay entry 124). */
export const heldInCheckout = (slug: string): boolean => existsSync(`${CONTENT}${slug}.json`);

/**
 * One check, start to finish, with no side effects but the requests. `holds` says whether the
 * repository's content already holds a post: a first run (no record yet) compares against the site,
 * not nothing, so Substack's newest posts that the site doesn't hold count as a change (relay entry 124).
 */
export async function runCheck(env: CheckEnv, substackUrl: string | null, fetchImpl: Fetch = fetch, sleep?: (ms: number) => Promise<void>, holds: (slug: string) => boolean = heldInCheckout): Promise<CheckOutcome> {
  const log: string[] = [];
  if (!substackUrl) {
    return { outputs: { record: 'No Substack in client.json', rebuild: false, fail: false }, log: ['::notice title=Substack::This site has no Substack, so there is nothing to check.'] };
  }
  if (!env.GITHUB_REPOSITORY || !env.GITHUB_TOKEN) throw new Error('GITHUB_REPOSITORY and GITHUB_TOKEN must be set; the workflow sets both.');

  let previous;
  try {
    previous = await lastRun(env.GITHUB_REPOSITORY, env.GITHUB_TOKEN, { fetchImpl, scan: 5 });
  } catch (error) {
    // Without the last record there is nothing to compare against; skip this run, softly. The next
    // run looks back past this one.
    log.push(`::warning title=Substack::GitHub could not be read, so this check was skipped: ${(error as Error).message}`);
    return { outputs: { record: 'Skipped: GitHub could not be read', rebuild: false, fail: false }, log };
  }

  let seen: { fingerprint: string } | { miss: string };
  let slugs: string[] = [];
  try {
    const read = await readSubstack(substackUrl, fetchImpl, sleep);
    slugs = read.slugs;
    seen = { fingerprint: await fingerprintOf(slugs) };
    log.push(`Read the newest posts from the ${read.from}: ${slugs.join(', ')}.`);
  } catch (error) {
    if (!(error instanceof SubstackMiss)) throw error;
    seen = { miss: error.message };
  }

  const decided = decide(previous?.record ? { record: previous.record, rebuilt: previous.rebuilt } : null, seen);
  // With nothing to compare against (no record yet, or a first run's rebuild that didn't finish),
  // the site's own content is the baseline: newest posts it doesn't hold are a change. The record
  // says `changed` from no fingerprint, so a rebuild that fails is tried again on the next run.
  const first = decided.record.result === 'first';
  const missing = first ? slugs.filter((slug) => !holds(slug)) : [];
  const { record, rebuild, fail } = missing.length ? { record: { ...decided.record, result: 'changed' as const }, rebuild: true, fail: false } : decided;
  if ('miss' in seen) {
    const line = `Substack did not answer (${seen.miss}); ${record.misses} ${record.misses === 1 ? 'miss' : 'misses'} in a row.`;
    log.push(fail ? `::error title=Substack::${line} At ${MISS_LIMIT}, the check fails until Substack answers again.` : `::warning title=Substack::${line} The daily rebuild still runs.`);
  } else if (record.result === 'first') {
    log.push('::notice title=Substack::First check: the site holds the newest posts, and they are recorded; the next check compares against them.');
  } else if (missing.length) {
    log.push(`::notice title=Substack::First check: the site doesn't hold ${missing.length === 1 ? 'one of the newest posts' : `${missing.length} of the newest posts`} yet (${missing.join(', ')}), so the site rebuilds.`);
  } else if (rebuild) {
    log.push('::notice title=Substack::New posts on Substack: rebuilding the site.');
  } else {
    log.push('Nothing new on Substack.');
  }
  return { outputs: { record: formatRecord(record), rebuild, fail }, log };
}

/** The command: one check, its log, and its outputs for the workflow. */
export async function main(env = process.env as CheckEnv): Promise<void> {
  const outcome = await runCheck(env, env.SUBSTACK_URL || substackFromRecord());
  for (const line of outcome.log) console.log(line);
  const out = [`record=${outcome.outputs.record}`, `rebuild=${outcome.outputs.rebuild}`, `fail=${outcome.outputs.fail}`, ''].join('\n');
  if (env.GITHUB_OUTPUT) appendFileSync(env.GITHUB_OUTPUT, out);
  else process.stdout.write(out);
}
