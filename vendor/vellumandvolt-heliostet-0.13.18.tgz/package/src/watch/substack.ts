// The Substack check, run from GitHub Actions rather than the watcher Worker (SITE-6, decision 0014).
// Substack refuses requests from Cloudflare's egress with 429, so the Worker no longer polls it; the
// client repository's substack.yml runs this on GitHub's runners instead: every 30 minutes by day and
// hourly overnight, in the client's time zone (build/substack-schedule.ts).
//
// The check keeps no state of its own. Each run writes one line, its record, as the name of a step
// in its job; the next run, and the watcher's /_heliostet/status, read the newest record back
// through GitHub's Actions API, with the token each already holds (Actions: read). Nothing is
// committed and no new secret or permission is needed.
//
// No Node built-ins: the watcher Worker imports this file too, and the workflow runs it straight
// from the vendored tarball, with no install.

/** The workflow file in the client repository. */
export const SUBSTACK_WORKFLOW = 'substack.yml';
/** The job that runs the check, and whose step carries the record. */
export const CHECK_JOB = 'check';
/** A miss this many times in a row is a real failure: three hours by day, six overnight. */
export const MISS_LIMIT = 6;
/** No finished run for this long means the schedule has stopped. */
export const STALE_MS = 3 * 60 * 60 * 1000;

export type CheckResult = 'first' | 'same' | 'changed' | 'miss';

/** One run's outcome: what it saw, against what, and the misses in a row. */
export interface CheckRecord {
  result: CheckResult;
  /** The fingerprint this run saw, or the one it kept on a miss. */
  fingerprint: string | null;
  /** The fingerprint it compared against. */
  previous: string | null;
  misses: number;
}

const PREFIX = 'heliostet-substack v1';
const FP = /^[0-9a-f]{12}$|^-$/;

/** The record as a step name: one line, no spaces inside a field. */
export function formatRecord(r: CheckRecord): string {
  return `${PREFIX} result=${r.result} misses=${r.misses} from=${r.previous ?? '-'} to=${r.fingerprint ?? '-'}`;
}

/** The record from a step name, or null when the name is not one. */
export function parseRecord(name: string): CheckRecord | null {
  const m = /^heliostet-substack v1 result=(first|same|changed|miss) misses=(\d+) from=(\S+) to=(\S+)$/.exec(name.trim());
  if (!m || !FP.test(m[3] as string) || !FP.test(m[4] as string)) return null;
  const fp = (s: string) => (s === '-' ? null : s);
  return { result: m[1] as CheckResult, misses: Number(m[2]), previous: fp(m[3] as string), fingerprint: fp(m[4] as string) };
}

/* Reading Substack ------------------------------------------------------------------------------ */

export class SubstackMiss extends Error {
  override name = 'SubstackMiss';
}

const BROWSER = {
  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
  'accept-language': 'en-US,en;q=0.9',
};
const TIMEOUT = 15_000;
/** Waits before the second and third tries. */
export const BACKOFF_MS = [5_000, 15_000];

/** The slug of a post address (…/p/<slug>), or null for anything else (a thread, a note). */
function slugOf(link: string): string | null {
  return /\/p\/([^/?#\s]+)/.exec(link)?.[1] ?? null;
}

/** The newest three posts' slugs from the RSS feed. */
export function slugsFromFeed(xml: string): string[] {
  const slugs: string[] = [];
  for (const item of xml.matchAll(/<item\b[\s\S]*?<\/item>/g)) {
    const link = /<link>\s*(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?\s*<\/link>/.exec(item[0])?.[1] ?? '';
    const slug = slugOf(link.trim());
    if (slug && !slugs.includes(slug)) slugs.push(slug);
    if (slugs.length >= 3) break;
  }
  return slugs;
}

/** The newest three posts' slugs from the archive API; threads are skipped, as the import does. */
export function slugsFromArchive(json: unknown): string[] {
  if (!Array.isArray(json)) return [];
  return (json as { slug?: string; type?: string }[]).filter((p) => p.slug && p.type !== 'thread').slice(0, 3).map((p) => p.slug as string);
}

/**
 * The fingerprint: a short hash of the newest three slugs. Slugs alone, so the feed and the
 * archive, which date posts differently, give the same fingerprint for the same posts.
 */
export async function fingerprintOf(slugs: string[]): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(slugs.join('|')));
  return [...new Uint8Array(digest).slice(0, 6)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

type Fetch = (url: string, init?: RequestInit) => Promise<Response>;

/**
 * The newest slugs, from the feed and then the archive, up to three tries with backoff. Throws a
 * SubstackMiss when every try fails: a 429, a timeout, or an answer with no posts.
 */
export async function readSubstack(base: string, fetchImpl: Fetch = fetch, sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms))): Promise<{ slugs: string[]; from: 'feed' | 'archive' }> {
  const root = base.replace(/\/$/, '');
  const reasons: string[] = [];
  const attempt = async <T>(url: string, accept: string, read: (res: Response) => Promise<T>): Promise<T | null> => {
    try {
      const res = await fetchImpl(url, { headers: { ...BROWSER, accept }, signal: AbortSignal.timeout(TIMEOUT) });
      if (!res.ok) {
        reasons.push(`HTTP ${res.status}`);
        return null;
      }
      return await read(res);
    } catch (error) {
      reasons.push((error as Error).name === 'TimeoutError' ? 'timeout' : (error as Error).message);
      return null;
    }
  };
  for (let i = 0; i <= BACKOFF_MS.length; i++) {
    if (i > 0) await sleep(BACKOFF_MS[i - 1] as number);
    const fromFeed = await attempt(`${root}/feed`, 'application/rss+xml, application/xml, text/xml', async (res) => slugsFromFeed(await res.text()));
    if (fromFeed?.length) return { slugs: fromFeed, from: 'feed' };
    const fromArchive = await attempt(`${root}/api/v1/archive?sort=new&offset=0&limit=6`, 'application/json', async (res) => slugsFromArchive(await res.json()));
    if (fromArchive?.length) return { slugs: fromArchive, from: 'archive' };
  }
  throw new SubstackMiss(reasons.length ? [...new Set(reasons)].join(', ') : 'no posts in the feed or the archive');
}

/* Deciding ------------------------------------------------------------------------------------ */

/** The previous run, as the check reads it back. */
export interface Previous {
  record: CheckRecord;
  /** Whether that run's rebuild finished well; only matters when it saw a change. */
  rebuilt: boolean;
}

/**
 * This run's record, and whether to rebuild or fail. A change is compared against the last
 * fingerprint that was built: when the previous run saw a change and its rebuild did not finish
 * well, the change is still pending and this run rebuilds again. A miss keeps the fingerprint and
 * never rebuilds; MISS_LIMIT in a row fails the run.
 */
export function decide(previous: Previous | null, seen: { fingerprint: string } | { miss: string }): { record: CheckRecord; rebuild: boolean; fail: boolean } {
  const p = previous?.record;
  const baseline = !p ? null : p.result === 'changed' && !previous?.rebuilt ? p.previous : p.fingerprint;
  if ('miss' in seen) {
    const misses = (p?.misses ?? 0) + 1;
    return { record: { result: 'miss', fingerprint: baseline, previous: baseline, misses }, rebuild: false, fail: misses >= MISS_LIMIT };
  }
  if (baseline === null) return { record: { result: 'first', fingerprint: seen.fingerprint, previous: null, misses: 0 }, rebuild: false, fail: false };
  const changed = seen.fingerprint !== baseline;
  return { record: { result: changed ? 'changed' : 'same', fingerprint: seen.fingerprint, previous: baseline, misses: 0 }, rebuild: changed, fail: false };
}

/* Reading the record back from GitHub ----------------------------------------------------------- */

export interface LastRun {
  /** When the run finished. */
  at: string;
  conclusion: string | null;
  /** The record, or null when the run carries none (it failed before writing one). */
  record: CheckRecord | null;
  rebuilt: boolean;
}

/**
 * The newest finished run of substack.yml on the branch, with its record: the runs, then that run's
 * jobs. Null when the workflow has never finished a run. With `scan`, it looks back through that
 * many runs for the newest one that carries a record, so one run that failed before writing its
 * record does not break the chain (the check uses this; /_heliostet/status does not, and shows it).
 */
export async function lastRun(repo: string, token: string, options: { branch?: string; fetchImpl?: Fetch; userAgent?: string; scan?: number } = {}): Promise<LastRun | null> {
  const fetchImpl = options.fetchImpl ?? fetch;
  const headers = { authorization: `Bearer ${token}`, accept: 'application/vnd.github+json', 'x-github-api-version': '2022-11-28', 'user-agent': options.userAgent ?? 'heliostet-substack-check' };
  const api = async <T>(path: string): Promise<T> => {
    const res = await fetchImpl(`https://api.github.com/repos/${repo}${path}`, { headers, signal: AbortSignal.timeout(TIMEOUT) });
    if (!res.ok) throw new Error(`GitHub answered ${res.status} for ${path.split('?')[0]}`);
    return (await res.json()) as T;
  };
  const { workflow_runs: runs } = await api<{ workflow_runs?: { id: number; updated_at: string; conclusion: string | null }[] }>(
    `/actions/workflows/${SUBSTACK_WORKFLOW}/runs?branch=${encodeURIComponent(options.branch ?? 'main')}&status=completed&per_page=${options.scan ?? 1}`,
  );
  let newest: LastRun | null = null;
  for (const run of runs ?? []) {
    const { jobs } = await api<{ jobs?: { name: string; conclusion: string | null; steps?: { name: string }[] }[] }>(`/actions/runs/${run.id}/jobs?per_page=50`);
    const check = jobs?.find((j) => j.name === CHECK_JOB);
    const record = check?.steps?.map((s) => parseRecord(s.name)).find((r): r is CheckRecord => r !== null) ?? null;
    // The called rebuild's jobs are named "rebuild / …"; it finished well only if each did.
    const rebuildJobs = (jobs ?? []).filter((j) => j.name !== CHECK_JOB);
    const rebuilt = rebuildJobs.length > 0 && rebuildJobs.every((j) => j.conclusion === 'success' || j.conclusion === 'skipped');
    const found: LastRun = { at: run.updated_at, conclusion: run.conclusion, record, rebuilt };
    newest ??= found;
    if (record) return found;
  }
  return options.scan ? null : newest;
}

export type CheckState = 'ok' | 'warning' | 'problem' | 'pending';

/**
 * The Substack row's state for /_heliostet/status, in Heliostet's words: Pending before the first
 * run; OK after a run that read Substack; Warning after a soft miss or a skipped run; Problem at
 * MISS_LIMIT misses in a row, after a run that failed with no record, or when no run has finished
 * for STALE_MS.
 */
export function checkState(last: LastRun | null, now: number): CheckState {
  if (!last) return 'pending';
  if (now - Date.parse(last.at) > STALE_MS) return 'problem';
  // A run with no record skipped its check (GitHub could not be read) or failed outright.
  if (!last.record) return last.conclusion === 'success' ? 'warning' : 'problem';
  if (last.record.misses === 0) return 'ok';
  return last.record.misses >= MISS_LIMIT ? 'problem' : 'warning';
}
