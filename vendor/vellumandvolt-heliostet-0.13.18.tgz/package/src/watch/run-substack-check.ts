// The entry substack.yml runs: `node package/dist/watch/run-substack-check.js` (SITE-6).
import { main } from './substack-check.js';

main().catch((error: unknown) => {
  // A fault in the check itself, not Substack's: one red run, with the reason.
  console.log(`::error title=Substack check::${(error as Error).message}`);
  process.exitCode = 1;
});
