// A menu other than the site's (relay entry 54): the lockup, the menu, the Subscribe button, and the
// footer's links, for a development page drawn in another site's menu, such as /parts-gallery/home.

import type { NavItem } from '../config/site.js';

export interface MenuOverride {
  lockup?: { name: string; logo: { src: string; width: number; height: number } | null };
  nav: NavItem[];
  subscribe?: NavItem | null;
  footer?: NavItem[];
}
