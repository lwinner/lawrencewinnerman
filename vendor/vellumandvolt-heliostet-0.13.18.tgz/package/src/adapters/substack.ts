// The Substack adapter (SITE-1, SITE-4, SITE-5), generalized from the Press's archive script and
// body cleaner. The import pages through the publication's whole archive (not the RSS window),
// fetches each post, cleans Substack's markup, cuts a paid post to its public preview, passes
// the body through the one sanitizer, and writes one JSON file per post into the client
// repository, so a build never depends on Substack. The build reads those files back as Items.

import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import * as cheerio from 'cheerio';
import { XMLParser } from 'fast-xml-parser';
import { z } from 'zod';
import { readMinutes, type Byline, type Item, type Visibility } from '../build/item.js';
import { decodeEntities, limitDepth, plainText, sanitize } from '../build/sanitize.js';

export const SUBSTACK_DIR = 'src/content/substack/';
/** Bumped when the cleanup or the sanitizer changes, so a stale import can be found. */
export const IMPORT_VERSION = 2;
const USER_AGENT = 'Mozilla/5.0 (compatible; VellumAndVoltKit/0; +https://vellumandvolt.com)';
const PAGE_SIZE = 50;

/** The fields of Substack's post API the adapter reads. */
export interface SubstackPost {
  id: number;
  slug: string;
  title: string;
  subtitle?: string | null;
  canonical_url?: string | null;
  post_date: string;
  updated_at?: string | null;
  audience?: string | null;
  type?: string | null;
  cover_image?: string | null;
  wordcount?: number | null;
  section_id?: number | null;
  body_html?: string | null;
  truncated_body_text?: string | null;
  postTags?: { name?: string | null }[] | null;
  publishedBylines?: { name?: string | null }[] | null;
}

interface ListedPost {
  id?: number;
  slug?: string;
  type?: string;
  post_date?: string;
}

/** One post as the import stores it in the client repository. */
export const substackRecordSchema = z.strictObject({
  /** Substack's own number for the post; null for a post imported from somewhere that didn't give it (relay entry 55). */
  id: z.int().positive().nullable(),
  slug: z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  title: z.string(),
  subtitle: z.string(),
  url: z.url({ protocol: /^https$/ }),
  date: z.iso.datetime(),
  updated: z.iso.datetime().nullable(),
  type: z.string(),
  paid: z.boolean(),
  bylines: z.array(z.string()),
  tags: z.array(z.string()),
  /** The cover; credit is the caption of the leading image it came from, when it had one. */
  cover: z.strictObject({ src: z.url({ protocol: /^https$/ }), alt: z.string(), credit: z.string().optional() }).nullable(),
  wordcount: z.int().min(0).nullable(),
  sectionId: z.int().nullable(),
  /** Sanitized HTML; for a paid post, the public preview only. */
  body: z.string(),
  imported: z.int(),
});
export type SubstackRecord = z.infer<typeof substackRecordSchema>;

export class SubstackError extends Error {
  override name = 'SubstackError';
}

export interface FetchOptions {
  fetch?: typeof fetch;
  /** Waits between requests and before a retry; tests pass a no-op. */
  sleep?: (ms: number) => Promise<void>;
}

const wait = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

async function getJson<T>(url: string, { fetch: get = fetch, sleep = wait }: FetchOptions, tries = 3): Promise<T> {
  for (let attempt = 1; ; attempt++) {
    let response: Response;
    try {
      response = await get(url, { headers: { 'user-agent': USER_AGENT, accept: 'application/json' } });
    } catch (error) {
      if (attempt >= tries) throw new SubstackError(`${url} could not be reached: ${(error as Error).message}`);
      await sleep(2000 * attempt);
      continue;
    }
    if (response.ok) return (await response.json()) as T;
    // A 429 or a server error is retried; anything else is final.
    if (attempt >= tries || (response.status < 500 && response.status !== 429)) throw new SubstackError(`${url} returned HTTP ${response.status}.`);
    await sleep(2000 * attempt);
  }
}

function origin(publication: string): string {
  const url = new URL(publication);
  if (url.protocol !== 'https:') throw new SubstackError(`The Substack address must be https: ${publication}`);
  return url.origin;
}

/** Every post in the archive, newest first, paging until Substack returns an empty page. */
export async function listArchive(publication: string, options: FetchOptions = {}): Promise<ListedPost[]> {
  const base = origin(publication);
  const posts: ListedPost[] = [];
  for (let offset = 0; ; ) {
    const page = await getJson<ListedPost[]>(`${base}/api/v1/archive?sort=new&offset=${offset}&limit=${PAGE_SIZE}`, options);
    if (!Array.isArray(page) || page.length === 0) break;
    posts.push(...page);
    offset += page.length;
    await (options.sleep ?? wait)(400);
  }
  return posts;
}

export function fetchPost(publication: string, slug: string, options: FetchOptions = {}): Promise<SubstackPost> {
  return getJson<SubstackPost>(`${origin(publication)}/api/v1/posts/${encodeURIComponent(slug)}`, options);
}

/* Cleaning Substack's markup -------------------------------------------------------- */

const REMOVED = ['ButtonCreateButton', 'SubscribeWidgetToDOM', 'InstallSubstackAppToDOM', 'CommentPlaceholder', 'PaywallToDOM'];
const CHROME = '.button-wrapper, .subscription-widget-wrap-editor, .subscription-widget-wrap, .captioned-button-wrap, .share-dialog, .image-link-expand, .restack-image, .pencraft';
const PAYWALL = '.paywall-jump, [data-component-name="PaywallToDOM"]';

const escape = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function attrsOf(el: cheerio.Cheerio<never>): Record<string, unknown> {
  try {
    return JSON.parse(el.attr('data-attrs') ?? '{}') as Record<string, unknown>;
  } catch {
    return {};
  }
}

const str = (v: unknown) => (typeof v === 'string' ? v : '');

/** Substack serves one image at many sizes; the upload's own key names it. */
function imageKey(src: string): string {
  const decoded = decodeURIComponent(src);
  return /\/images\/([0-9a-f-]{36})/.exec(decoded)?.[1] ?? decoded;
}

/** Everything after the paywall marker goes, at every level, and the marker with it (SITE-4). */
function cutAtPaywall(root: cheerio.Cheerio<never>): boolean {
  const marker = root.find(PAYWALL).first();
  if (marker.length === 0) return false;
  for (let el = marker; el.length && !el.is(root); el = el.parent() as cheerio.Cheerio<never>) el.nextAll().remove();
  marker.remove();
  return true;
}

export interface CleanedBody {
  html: string;
  cover: { src: string; alt: string; credit?: string } | null;
}

/**
 * How a site's Substack posts are cleaned (relay entry 55), from client.json's
 * sources.substack.cleanup. The defaults are Heliostet's; the others are the Press's rules, which
 * any site may choose.
 */
export const cleanupSchema = z.strictObject({
  /** A YouTube embed: a link to the video, or a linked thumbnail (marked kit-video). */
  youtube: z.enum(['link', 'thumbnail']).default('link'),
  /** The link another embed becomes: named by the embed's own title, or "View the original" always. */
  embedLabel: z.enum(['title', 'fixed']).default('title'),
  /** The post's leading image: the cover only when it is the cover, or always (with its caption as the credit). */
  leadImage: z.enum(['cover', 'always']).default('cover'),
  /**
   * Headings: from h2 down in steps, or two levels, titles and subheads: h1 and h2 as h2, the rest
   * as h3, and in a post with no titles, its subheads as h2s marked kit-subhead, so they keep the subhead's size.
   */
  headings: z.enum(['steps', 'two-levels']).default('steps'),
});
export type CleanupOptions = z.input<typeof cleanupSchema>;
type Cleanup = z.output<typeof cleanupSchema>;

const YOUTUBE_ID = /^[\w-]{6,20}$/;

/** Turns a post's HTML into reading HTML, before the sanitizer sees it. */
export function cleanBody(raw: string, paid: boolean, preview: string, cover: string | null, options: CleanupOptions = {}): CleanedBody {
  const o: Cleanup = cleanupSchema.parse(options);
  // A body nested thousands deep would overflow the parser's stack; it is flattened first (SEC-2).
  const $ = cheerio.load(`<div id="kit-root">${limitDepth(raw)}</div>`, null, false);
  const root = $('#kit-root') as cheerio.Cheerio<never>;

  if (paid && !cutAtPaywall(root)) {
    // A paid post without the marker keeps only Substack's own public excerpt, never the body.
    return { html: preview ? `<p>${escape(preview)}</p>` : '', cover: cover ? { src: cover, alt: '' } : null };
  }

  // The leading image is the cover when the post names none, or a copy of it when it does; with
  // leadImage "always", it leaves the body either way, and its caption is the cover's credit.
  let found: CleanedBody['cover'] = cover ? { src: cover, alt: '' } : null;
  const first = root.children().first();
  if (first.is('.captioned-image-container')) {
    const img = first.find('img').first();
    const src = img.attr('src') ?? '';
    const same = !cover || (src !== '' && imageKey(src) === imageKey(cover));
    if (o.leadImage === 'always' || (src && same)) {
      const credit = first.find('figcaption').text().trim();
      if (cover || src) found = { src: cover ?? src, alt: same ? (img.attr('alt') ?? '').trim() : '', ...(credit ? { credit } : {}) };
      first.remove();
    }
  }

  root.find(CHROME).remove();
  root.find('script, style, form, input, button, svg').remove();

  // A mention renders empty; its name comes back.
  root.find('.mention-wrap, [data-component-name="MentionToDOM"]').each((_, node) => {
    const name = str(attrsOf($(node) as cheerio.Cheerio<never>).name);
    $(node).replaceWith(name ? `<span>${escape(name)}</span>` : '');
  });
  // A YouTube embed is never a player on the page: a link to the video, or its thumbnail linked.
  root.find('.youtube-wrap, [data-component-name="Youtube2ToDOM"]').each((_, node) => {
    const id = str(attrsOf($(node) as cheerio.Cheerio<never>).videoId);
    if (!YOUTUBE_ID.test(id)) return void $(node).remove();
    const watch = `https://www.youtube.com/watch?v=${id}`;
    $(node).replaceWith(
      o.youtube === 'thumbnail'
        ? `<p class="kit-video"><a href="${watch}"><img src="https://i.ytimg.com/vi/${id}/hqdefault.jpg" alt="" width="480" height="360">Watch on YouTube</a></p>`
        : `<p><a href="${watch}">Watch on YouTube</a></p>`,
    );
  });

  // Images keep their captions, at the size Substack serves for reading.
  root.find('.captioned-image-container, .image-gallery-embed').each((_, node) => {
    const el = $(node);
    const imgs = el
      .find('img')
      .toArray()
      .filter((img) => $(img).attr('src'))
      .map((img) => {
        const i = $(img);
        const size = i.attr('width') && i.attr('height') ? ` width="${escape(i.attr('width') ?? '')}" height="${escape(i.attr('height') ?? '')}"` : '';
        return `<img src="${escape(i.attr('src') ?? '')}" alt="${escape(i.attr('alt') ?? '')}"${size}>`;
      });
    const caption = el.find('figcaption').first().html();
    el.replaceWith(imgs.length ? `<figure>${imgs.join('')}${caption ? `<figcaption>${caption}</figcaption>` : ''}</figure>` : '');
  });

  // Any other embed (posts, tweets, audio, files, polls) becomes a plain link to the original.
  root.find('[data-component-name]').each((_, node) => {
    const el = $(node) as cheerio.Cheerio<never>;
    const name = el.attr('data-component-name') ?? '';
    if (name === 'Image2ToDOM') return;
    if (REMOVED.includes(name)) return void el.remove();
    const attrs = attrsOf(el);
    const href = str(attrs.url) || str(attrs.canonical_url) || str(attrs.post_url) || str(attrs.href) || el.find('a[href]').first().attr('href') || '';
    const label = (o.embedLabel === 'title' && str(attrs.title)) || 'View the original';
    el.replaceWith(/^https?:\/\//.test(href) ? `<p class="kit-embed"><a href="${escape(href)}">${escape(label)}</a></p>` : '');
  });
  root.find('iframe').each((_, node) => {
    const src = $(node).attr('src') ?? '';
    $(node).replaceWith(/^https?:\/\//.test(src) ? `<p class="kit-embed"><a href="${escape(src)}">View the original</a></p>` : '');
  });

  // Substack's separators are a div around an hr.
  root.find('div').each((_, node) => {
    const el = $(node);
    if (el.children().length === 1 && el.children('hr').length === 1 && el.text().trim() === '') el.replaceWith('<hr>');
  });
  root.find('.pullquote').each((_, node) => {
    const el = $(node);
    el.replaceWith(`<blockquote class="kit-pullquote">${el.find('p').toArray().map((p) => `<p>${$(p).html() ?? ''}</p>`).join('')}</blockquote>`);
  });

  const headings = root.find('h1, h2, h3, h4, h5, h6').toArray();
  if (o.headings === 'two-levels') {
    for (const h of headings) h.tagName = h.tagName === 'h1' ? 'h2' : h.tagName === 'h2' ? 'h2' : 'h3';
    if (!headings.some((h) => h.tagName === 'h2')) {
      for (const h of headings) {
        h.tagName = 'h2';
        $(h).attr('class', 'kit-subhead');
      }
    }
  } else {
    // The page's h1 is the title, so the body's outline starts at h2 whatever level Substack used,
    // and keeps its steps (PAGE-5); the sanitizer allows h2 to h4.
    const top = Math.min(...headings.map((h) => Number(h.tagName.slice(1))));
    for (const h of headings) h.tagName = `h${Math.min(4, Number(h.tagName.slice(1)) - top + 2)}`;
  }

  // No rule opens or closes a body, and none follows another.
  for (let edge = root.children().first(); edge.is('hr'); edge = root.children().first()) edge.remove();
  for (let edge = root.children().last(); edge.is('hr'); edge = root.children().last()) edge.remove();
  root.find('hr + hr').remove();

  return { html: root.html() ?? '', cover: found };
}

/* Records ------------------------------------------------------------------------------- */

export function toRecord(post: SubstackPost, publication: string, cleanup: CleanupOptions = {}): SubstackRecord {
  const paid = !!post.audience && post.audience !== 'everyone';
  const cleaned = cleanBody(post.body_html ?? '', paid, post.truncated_body_text ?? '', post.cover_image ?? null, cleanup);
  const canonical = post.canonical_url || `${origin(publication)}/p/${post.slug}`;
  return {
    id: post.id,
    slug: post.slug,
    title: decodeEntities(post.title).trim(),
    subtitle: decodeEntities(post.subtitle ?? '').trim(),
    url: canonical,
    date: new Date(post.post_date).toISOString(),
    updated: post.updated_at ? new Date(post.updated_at).toISOString() : null,
    type: post.type ?? 'newsletter',
    paid,
    bylines: (post.publishedBylines ?? []).map((b) => (b.name ?? '').trim()).filter(Boolean),
    tags: (post.postTags ?? []).map((t) => (t.name ?? '').trim()).filter(Boolean),
    cover: cleaned.cover,
    wordcount: post.wordcount ?? null,
    sectionId: post.section_id ?? null,
    body: sanitize(cleaned.html),
    imported: IMPORT_VERSION,
  };
}

export interface ImportResult {
  listed: number;
  fetched: number;
  written: number;
  skipped: string[];
}

/** Posts newer than this are fetched again on every run, to pick up edits. */
const REFRESH_DAYS = 21;

/**
 * Imports the whole archive into `dir` (SITE-1). A post already on file is fetched again only
 * when it is recent, or when `all` is set. A file is written only when its content changes,
 * so an unchanged run leaves the repository clean. Nothing is ever deleted: a post that
 * leaves Substack stays on the site.
 */
/** `ids` (relay entry 126): a post already on file whose record has no Substack number takes it from the archive's
 *  listing, with nothing else in the record changed and no refetch. */
export async function importArchive(publication: string, dir: URL, options: FetchOptions & { all?: boolean; limit?: number; now?: number; cleanup?: CleanupOptions; ids?: boolean } = {}): Promise<ImportResult & { ids?: number; missing?: string[] }> {
  mkdirSync(dir, { recursive: true });
  const listed = (await listArchive(publication, options)).filter((p) => p.slug && p.type !== 'thread');
  const cutoff = (options.now ?? Date.now()) - REFRESH_DAYS * 86_400_000;
  const result: ImportResult & { ids?: number; missing?: string[] } = { listed: listed.length, fetched: 0, written: 0, skipped: [] };
  for (const listedPost of listed.slice(0, options.limit ?? listed.length)) {
    const slug = listedPost.slug ?? '';
    const file = new URL(`${slug}.json`, dir);
    const recent = new Date(listedPost.post_date ?? 0).getTime() >= cutoff;
    if (existsSync(file) && !recent && !options.all) {
      if (options.ids && typeof listedPost.id === 'number') {
        const text = readFileSync(file, 'utf8');
        const record = JSON.parse(text) as { id: number | null };
        if (record.id === null) {
          writeFileSync(file, text.replace(/^  "id": null,$/m, `  "id": ${listedPost.id},`));
          result.ids = (result.ids ?? 0) + 1;
        }
      }
      continue;
    }
    let post: SubstackPost;
    try {
      post = await fetchPost(publication, slug, options);
    } catch (error) {
      result.skipped.push(`${slug}: ${(error as Error).message}`);
      continue;
    }
    result.fetched++;
    const json = `${JSON.stringify(toRecord(post, publication, options.cleanup), null, 2)}\n`;
    if (!existsSync(file) || readFileSync(file, 'utf8') !== json) {
      writeFileSync(file, json);
      result.written++;
    }
    await (options.sleep ?? wait)(400);
  }
  // Every record still without a number whose post the listing no longer has: Substack doesn't have it any more.
  if (options.ids) {
    const onList = new Set(listed.map((p) => p.slug));
    result.missing = readdirSync(dir).filter((f) => f.endsWith('.json')).map((f) => f.slice(0, -5))
      .filter((slug) => !onList.has(slug) && (JSON.parse(readFileSync(new URL(`${slug}.json`, dir), 'utf8')) as { id: number | null }).id === null);
  }
  return result;
}

/* The live feed ------------------------------------------------------------------------- */

type FeedNode = Record<string, unknown>;
const feedParser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@_', parseTagValue: false, processEntities: true, htmlEntities: true });
const feedText = (v: unknown): string => (v == null ? '' : typeof v === 'object' && '#text' in (v as FeedNode) ? String((v as FeedNode)['#text']) : String(v));
const feedList = (v: unknown): FeedNode[] => (v === undefined ? [] : Array.isArray(v) ? (v as FeedNode[]) : [v as FeedNode]);

/**
 * The posts in a publication's RSS feed as records (relay entry 55), for the build to add any the
 * import hasn't written yet. The feed carries less than the post API: no number, tags, or word
 * count, one byline, and every post as free; the import fills those in when it next runs.
 */
export function parseSubstackFeed(xml: string, cleanup: CleanupOptions = {}): SubstackRecord[] {
  const channel = ((feedParser.parse(xml) as FeedNode)?.rss as FeedNode | undefined)?.channel as FeedNode | undefined;
  return feedList(channel?.item).flatMap((item) => {
    const url = feedText(item.link).trim();
    const slug = /\/p\/([a-z0-9]+(?:-[a-z0-9]+)*)(?:[/?#]|$)/.exec(url)?.[1];
    const date = new Date(feedText(item.pubDate));
    if (!slug || !/^https:\/\//.test(url) || Number.isNaN(date.getTime())) return [];
    const enclosure = item.enclosure as FeedNode | undefined;
    const cover = String(enclosure?.['@_type'] ?? '').startsWith('image/') && /^https:\/\//.test(String(enclosure?.['@_url'] ?? '')) ? String(enclosure?.['@_url']) : null;
    const cleaned = cleanBody(feedText(item['content:encoded']), false, '', cover, cleanup);
    const creator = feedText(item['dc:creator']).trim();
    return [
      {
        id: null,
        slug,
        title: decodeEntities(feedText(item.title)).trim(),
        subtitle: decodeEntities(feedText(item.description)).trim(),
        url,
        date: date.toISOString(),
        updated: null,
        type: 'newsletter',
        paid: false,
        bylines: creator ? [creator] : [],
        tags: [],
        cover: cleaned.cover,
        wordcount: null,
        sectionId: null,
        body: sanitize(cleaned.html),
        imported: IMPORT_VERSION,
      },
    ];
  });
}

/** The publication's feed, read at build; an unreachable feed is no records and a reason. */
export async function readLiveFeed(publication: string, cleanup: CleanupOptions = {}, get: typeof fetch = fetch): Promise<{ records: SubstackRecord[]; problem: string | null }> {
  const feed = `${origin(publication)}/feed`;
  try {
    const response = await get(feed, { headers: { 'user-agent': USER_AGENT } });
    if (!response.ok) return { records: [], problem: `${feed} returned HTTP ${response.status}` };
    return { records: parseSubstackFeed(await response.text(), cleanup), problem: null };
  } catch (error) {
    return { records: [], problem: `${feed} could not be read: ${(error as Error).message}` };
  }
}

/* Items --------------------------------------------------------------------------------- */

export interface ItemContext {
  /** Principals' ids with their names and aliases, for byline reconciliation (PRIN-1). */
  principals: { id: string; names: string[] }[];
  /** The name a post with no byline carries. */
  house: string;
  visibility: Record<string, Visibility>;
  /** Cover alt text from the record, for covers the source gives none (PAGE-5). */
  alt: Record<string, string>;
  /** The record's per-item clip override (FMT-4). */
  clips?: Record<string, 'clip' | 'long-form'>;
}

const SATIRE_PREFIX = /^\s*contains satire:\s*/i;

function byline(name: string, ctx: ItemContext): Byline {
  const lower = name.toLowerCase();
  return { name, principal: ctx.principals.find((p) => p.names.some((n) => n.toLowerCase() === lower))?.id ?? null };
}

export function toItem(record: SubstackRecord, ctx: ItemContext): Item {
  // A post with no number from Substack is known by its slug, which is also its file's name.
  const id = `substack:${record.id ?? record.slug}`;
  const html = sanitize(record.body);
  const text = plainText(html);
  let dek = record.subtitle;
  // SITE-5: the disclosure the source carries, a Satire tag or the "Contains satire:" prefix.
  let disclosure: Item['disclosure'] = record.tags.some((t) => t.toLowerCase() === 'satire') ? 'satire' : null;
  if (SATIRE_PREFIX.test(dek)) {
    disclosure = 'satire';
    dek = dek.replace(SATIRE_PREFIX, '');
  }
  const bylines = (record.bylines.length ? record.bylines : [ctx.house]).map((name) => byline(name, ctx));
  return {
    id,
    source: 'substack',
    kind: 'story',
    slug: record.slug,
    title: record.title,
    dek,
    date: record.date,
    updated: record.updated,
    author: bylines[0] ?? byline(ctx.house, ctx),
    bylines,
    tags: record.tags,
    body: { html, source: 'substack' },
    text,
    readMinutes: readMinutes(record.wordcount ?? text.split(' ').length),
    // The record's alt wins; then the alt of the body's leading image, which the import kept.
    cover: record.cover ? { src: record.cover.src, alt: ctx.alt[id] ?? record.cover.alt, ...(record.cover.credit ? { credit: record.cover.credit } : {}) } : null,
    duration: null,
    aspect: null,
    video: null,
    audio: null,
    chapters: [],
    transcript: null,
    episode: null,
    clip: false,
    sourceUrl: record.url,
    paid: record.paid,
    disclosure,
    visibility: ctx.visibility[id] ?? 'shown',
    joins: [],
    series: [],
  };
}
