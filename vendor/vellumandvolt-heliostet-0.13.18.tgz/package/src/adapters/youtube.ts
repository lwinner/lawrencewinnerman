// The YouTube adapter (SITE-2, FMT-4), from the Press's src/lib/youtube.ts. The Press reads the
// channel's RSS feed, which holds only the newest fifteen videos and carries no duration,
// aspect, or captions; a full mirror needs the YouTube Data API, so the import uses it: the
// channel's uploads playlist paged to the end, each video's snippet, duration, and player
// size (which gives the aspect), the channel's playlists in order (FMT-3), and the caption
// track as WebVTT. One JSON file per video goes into the client repository, and the build
// reads those files back as Items. The API key is the client's, read from the environment
// at import and never written, logged, or put in an error message.

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { z } from 'zod';
import type { Item } from '../build/item.js';
import { isoDuration, parseChapters, slugify } from '../build/media.js';
import { cueSchema, parseVtt } from '../build/transcript.js';
import { plainText, sanitize } from '../build/sanitize.js';
import type { ItemContext } from './substack.js';

export const YOUTUBE_DIR = 'src/content/youtube/';
export const IMPORT_VERSION = 1;
export const API = 'https://www.googleapis.com/youtube/v3';

/** One video as the import stores it. */
export const youtubeRecordSchema = z.strictObject({
  id: z.string().regex(/^[\w-]{6,20}$/),
  title: z.string(),
  /** YouTube's description, as plain text; it is escaped and linked at build. */
  description: z.string(),
  date: z.iso.datetime(),
  duration: z.int().min(0),
  aspect: z.enum(['wide', 'vertical']),
  thumbnail: z.url({ protocol: /^https$/ }),
  /** null: the video has no caption track, so its transcript is pending (SITE-2). */
  captions: z.array(cueSchema).nullable(),
  playlists: z.array(z.strictObject({ id: z.string(), title: z.string(), position: z.int().min(0) })),
  imported: z.int(),
});
export type YouTubeRecord = z.infer<typeof youtubeRecordSchema>;

export class YouTubeError extends Error {
  override name = 'YouTubeError';
}

/** The fields of the Data API's video resource the adapter reads. */
export interface ApiVideo {
  id: string;
  snippet: {
    title: string;
    description?: string;
    publishedAt: string;
    thumbnails?: Record<string, { url: string; width?: number; height?: number }>;
    liveBroadcastContent?: string;
  };
  contentDetails: { duration: string; caption?: string };
  player?: { embedWidth?: string | number; embedHeight?: string | number };
}

export interface YouTubeOptions {
  /** The client's Data API key; required for a live import. */
  apiKey?: string;
  fetch?: typeof fetch;
  /** The caption track for a video as WebVTT, or null when it has none. */
  captions?: (videoId: string) => Promise<string | null>;
}

/** Errors never carry the request URL, because it holds the key. */
async function api<T>(path: string, params: Record<string, string>, options: YouTubeOptions): Promise<T> {
  if (!options.apiKey && !options.fetch) throw new YouTubeError('The YouTube import needs the client’s Data API key in the YOUTUBE_API_KEY environment variable.');
  const url = new URL(`${API}/${path}`);
  for (const [k, v] of Object.entries({ ...params, ...(options.apiKey ? { key: options.apiKey } : {}) })) url.searchParams.set(k, v);
  const get = options.fetch ?? fetch;
  for (let attempt = 1; ; attempt++) {
    const response = await get(url, { headers: { accept: 'application/json' } }).catch(() => null);
    if (response?.ok) return (await response.json()) as T;
    const status = response?.status ?? 0;
    if (attempt >= 3 || (status && status < 500 && status !== 429)) throw new YouTubeError(`YouTube's ${path} request ${status ? `returned HTTP ${status}` : 'could not be reached'}.`);
  }
}

/** The handle in a channel address: https://www.youtube.com/@name → @name. */
export function channelHandle(channel: string): string {
  const handle = /\/(@[\w.-]+)/.exec(new URL(channel).pathname)?.[1];
  if (!handle) throw new YouTubeError(`The YouTube address names no @handle: ${channel}`);
  return handle;
}

/** How to look a channel up: by its id (/channel/UC…) or by its @handle. */
export function channelLookup(channel: string): Record<string, string> {
  const id = /\/channel\/(UC[\w-]{22})/.exec(new URL(channel).pathname)?.[1];
  return id ? { id } : { forHandle: channelHandle(channel) };
}

async function pagedIds(playlistId: string, options: YouTubeOptions): Promise<string[]> {
  const ids: string[] = [];
  let pageToken = '';
  do {
    const page = await api<{ items?: { contentDetails: { videoId: string } }[]; nextPageToken?: string }>(
      'playlistItems',
      { part: 'contentDetails', playlistId, maxResults: '50', ...(pageToken ? { pageToken } : {}) },
      options,
    );
    ids.push(...(page.items ?? []).map((i) => i.contentDetails.videoId));
    pageToken = page.nextPageToken ?? '';
  } while (pageToken);
  return ids;
}

/** Every upload on the channel, and the channel's playlists with their videos in order. */
export async function readChannel(channel: string, options: YouTubeOptions): Promise<{ videos: ApiVideo[]; playlists: Map<string, { title: string; ids: string[] }> }> {
  const found = await api<{ items?: { id: string; contentDetails: { relatedPlaylists: { uploads: string } } }[] }>(
    'channels',
    { part: 'id,contentDetails', ...channelLookup(channel) },
    options,
  );
  const chan = found.items?.[0];
  if (!chan) throw new YouTubeError(`YouTube has no channel at ${channel}.`);
  const uploads = await pagedIds(chan.contentDetails.relatedPlaylists.uploads, options);

  const videos: ApiVideo[] = [];
  for (let i = 0; i < uploads.length; i += 50) {
    const page = await api<{ items?: ApiVideo[] }>('videos', { part: 'snippet,contentDetails,player', id: uploads.slice(i, i + 50).join(','), maxHeight: '720' }, options);
    videos.push(...(page.items ?? []));
  }

  const playlists = new Map<string, { title: string; ids: string[] }>();
  let pageToken = '';
  do {
    const page = await api<{ items?: { id: string; snippet: { title: string } }[]; nextPageToken?: string }>(
      'playlists',
      { part: 'snippet', channelId: chan.id, maxResults: '50', ...(pageToken ? { pageToken } : {}) },
      options,
    );
    for (const p of page.items ?? []) playlists.set(p.id, { title: p.snippet.title, ids: await pagedIds(p.id, options) });
    pageToken = page.nextPageToken ?? '';
  } while (pageToken);
  return { videos, playlists };
}

/** Wide or vertical, from the player's size at a fixed height. */
function aspectOf(video: ApiVideo): 'wide' | 'vertical' {
  const w = Number(video.player?.embedWidth ?? 16);
  const h = Number(video.player?.embedHeight ?? 9);
  return w < h ? 'vertical' : 'wide';
}

function thumbnailOf(video: ApiVideo): string {
  const t = video.snippet.thumbnails ?? {};
  return (t.maxres ?? t.standard ?? t.high ?? t.medium ?? t.default)?.url ?? `https://i.ytimg.com/vi/${video.id}/hqdefault.jpg`;
}

export function toYouTubeRecord(video: ApiVideo, playlists: Map<string, { title: string; ids: string[] }>, vtt: string | null): YouTubeRecord {
  const cues = vtt ? parseVtt(vtt) : [];
  return {
    id: video.id,
    title: video.snippet.title.trim(),
    description: (video.snippet.description ?? '').trim(),
    date: new Date(video.snippet.publishedAt).toISOString(),
    duration: isoDuration(video.contentDetails.duration) ?? 0,
    aspect: aspectOf(video),
    thumbnail: thumbnailOf(video),
    captions: cues.length ? cues : null,
    playlists: [...playlists].flatMap(([id, p]) => {
      const position = p.ids.indexOf(video.id);
      return position < 0 ? [] : [{ id, title: p.title, position }];
    }),
    imported: IMPORT_VERSION,
  };
}

/** The public caption track, when no other source is given; unverified against live YouTube. */
async function timedText(videoId: string, get: typeof fetch): Promise<string | null> {
  const response = await get(`https://www.youtube.com/api/timedtext?v=${encodeURIComponent(videoId)}&lang=en&fmt=vtt`).catch(() => null);
  const text = response?.ok ? await response.text() : '';
  return text.includes('-->') ? text : null;
}

/** Imports every video on the channel into `dir`; a file is written only when it changes. */
export async function importChannel(channel: string, dir: URL, options: YouTubeOptions): Promise<{ listed: number; written: number }> {
  mkdirSync(dir, { recursive: true });
  const { videos, playlists } = await readChannel(channel, options);
  let written = 0;
  for (const video of videos) {
    // A scheduled or running broadcast has no recording yet.
    if (video.snippet.liveBroadcastContent && video.snippet.liveBroadcastContent !== 'none') continue;
    const hasTrack = video.contentDetails.caption === 'true';
    const vtt = hasTrack ? await (options.captions ?? ((id: string) => timedText(id, options.fetch ?? fetch)))(video.id) : null;
    const file = new URL(`${video.id}.json`, dir);
    const json = `${JSON.stringify(toYouTubeRecord(video, playlists, vtt), null, 2)}\n`;
    if (!existsSync(file) || readFileSync(file, 'utf8') !== json) {
      writeFileSync(file, json);
      written++;
    }
  }
  return { listed: videos.length, written };
}

/* Items --------------------------------------------------------------------------------- */

const escape = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** An https address in plain text: up to a space, a quote, or a bracket, and not its closing punctuation. */
const ADDRESS = /https:\/\/[^\s<>"'`]+[^\s<>"'`.,;:!?)\]]/g;

/**
 * A line of plain text with its https addresses as links (SEC-2, Step 10). Addresses are found in
 * the text before it is escaped, so a quote or a bracket ends one rather than becoming part of it,
 * and each link shows the address it goes to as the browser will read it: a look-alike domain in
 * another script shows its punycode, never a familiar name.
 */
function linkify(text: string): string {
  let out = '';
  let last = 0;
  for (const m of text.matchAll(ADDRESS)) {
    out += escape(text.slice(last, m.index));
    last = (m.index ?? 0) + m[0].length;
    let href: string;
    try {
      href = new URL(m[0]).href;
    } catch {
      out += escape(m[0]);
      continue;
    }
    out += `<a href="${escape(href)}">${escape(href)}</a>`;
  }
  return out + escape(text.slice(last));
}

/** A plain-text description as paragraphs, with its https addresses as links, then sanitized. */
export function descriptionHtml(text: string) {
  const paragraphs = text
    .split(/\n{2,}/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map((p) => `<p>${p.split('\n').map(linkify).join('<br>')}</p>`);
  return sanitize(paragraphs.join(''));
}

/** Under three minutes or vertical (FMT-4). */
export const CLIP_SECONDS = 180;

export function toYouTubeItem(record: YouTubeRecord, ctx: ItemContext): Item {
  const id = `youtube:${record.id}`;
  const html = descriptionHtml(record.description);
  const override = ctx.clips?.[id];
  return {
    id,
    source: 'youtube',
    kind: 'video',
    slug: slugify(record.title),
    title: record.title,
    dek: plainText(html).split(/(?<=[.!?])\s/)[0] ?? '',
    date: record.date,
    updated: null,
    author: { name: ctx.house, principal: null },
    bylines: [{ name: ctx.house, principal: null }],
    tags: [],
    body: { html, source: 'youtube' },
    text: plainText(html),
    readMinutes: Math.max(1, Math.round(record.duration / 60)),
    cover: { src: record.thumbnail, alt: ctx.alt[id] ?? '' },
    duration: record.duration,
    aspect: record.aspect,
    video: {
      id: record.id,
      watchUrl: `https://www.youtube.com/watch?v=${record.id}`,
      embedUrl: `https://www.youtube.com/embed/${record.id}`,
      poster: record.thumbnail,
    },
    audio: null,
    chapters: parseChapters(record.description),
    transcript: record.captions,
    episode: null,
    clip: override ? override === 'clip' : record.duration < CLIP_SECONDS || record.aspect === 'vertical',
    sourceUrl: `https://www.youtube.com/watch?v=${record.id}`,
    paid: false,
    disclosure: null,
    visibility: ctx.visibility[id] ?? 'shown',
    joins: [],
    series: record.playlists.map((p) => ({ kind: 'playlist' as const, slug: slugify(p.title), title: p.title, part: p.position + 1, url: `https://www.youtube.com/playlist?list=${encodeURIComponent(p.id)}` })),
  };
}
