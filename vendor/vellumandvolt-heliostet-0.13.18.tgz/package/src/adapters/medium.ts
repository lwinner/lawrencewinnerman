// A Medium adapter (SITE-3), small: Medium's RSS feed, one story per item, rendered on the same
// story template with its source named. It arrives in Step 5 because ADM-7's acceptance joins
// a Substack story with its Medium copy. Medium's feed holds only the newest posts; a full
// Medium mirror (an export import) is later work.

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { XMLParser } from 'fast-xml-parser';
import { z } from 'zod';
import { readMinutes, type Item } from '../build/item.js';
import { slugify } from '../build/media.js';
import { decodeEntities, plainText, sanitize } from '../build/sanitize.js';
import type { ItemContext } from './substack.js';

export const MEDIUM_DIR = 'src/content/medium/';
export const IMPORT_VERSION = 1;

export const mediumRecordSchema = z.strictObject({
  guid: z.string().min(1),
  slug: z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  title: z.string(),
  url: z.url({ protocol: /^https$/ }),
  date: z.iso.datetime(),
  bylines: z.array(z.string()),
  tags: z.array(z.string()),
  body: z.string(),
  imported: z.int(),
});
export type MediumRecord = z.infer<typeof mediumRecordSchema>;

const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@_', parseTagValue: false, processEntities: true, htmlEntities: true });
type Node = Record<string, unknown>;
const list = <T>(v: T | T[] | undefined): T[] => (v === undefined ? [] : Array.isArray(v) ? v : [v]);
const text = (v: unknown): string => (v == null ? '' : typeof v === 'object' ? String((v as Node)['#text'] ?? '') : String(v)).trim();

/** Medium's slugs end in a hash ("a-title-1a2b3c4d5e6f"); the page keeps the words. */
export function mediumSlug(url: string): string {
  const last = new URL(url).pathname.split('/').filter(Boolean).pop() ?? '';
  return slugify(last.replace(/-[0-9a-f]{8,16}$/, ''));
}

export function parseMediumFeed(xml: string): MediumRecord[] {
  const items = list((((parser.parse(xml) as Node)?.rss as Node | undefined)?.channel as Node | undefined)?.item as Node | Node[] | undefined);
  return items.flatMap((item) => {
    const url = text(item.link).replace(/\?source=rss[^#]*$/, '');
    if (!/^https:\/\//.test(url)) return [];
    return [
      {
        guid: text(item.guid) || url,
        slug: mediumSlug(url),
        title: decodeEntities(text(item.title)),
        url,
        date: new Date(text(item.pubDate)).toISOString(),
        bylines: [text(item['dc:creator'])].filter(Boolean),
        tags: list(item.category as unknown).map(text).filter(Boolean),
        body: sanitize(text(item['content:encoded'])),
        imported: IMPORT_VERSION,
      },
    ];
  });
}

export async function importMediumFeed(feed: string, dir: URL, options: { fetch?: typeof fetch } = {}): Promise<{ listed: number; written: number }> {
  const response = await (options.fetch ?? fetch)(feed).catch(() => null);
  if (!response?.ok) throw new Error(`The Medium feed ${response ? `returned HTTP ${response.status}` : 'could not be reached'}: ${feed}`);
  mkdirSync(dir, { recursive: true });
  const records = parseMediumFeed(await response.text());
  let written = 0;
  for (const record of records) {
    const file = new URL(`${record.slug}.json`, dir);
    const json = `${JSON.stringify(record, null, 2)}\n`;
    if (!existsSync(file) || readFileSync(file, 'utf8') !== json) {
      writeFileSync(file, json);
      written++;
    }
  }
  return { listed: records.length, written };
}

export function toMediumItem(record: MediumRecord, ctx: ItemContext): Item {
  // Medium's guid is https://medium.com/p/<hash>; the hash is the post's id.
  const id = `medium:${/\/p\/([0-9a-f]+)$/.exec(record.guid)?.[1] ?? record.guid}`;
  const html = sanitize(record.body);
  const words = plainText(html);
  const bylines = (record.bylines.length ? record.bylines : [ctx.house]).map((name) => ({
    name,
    principal: ctx.principals.find((p) => p.names.some((n) => n.toLowerCase() === name.toLowerCase()))?.id ?? null,
  }));
  return {
    id,
    source: 'medium',
    kind: 'story',
    slug: record.slug,
    title: record.title,
    dek: '',
    date: record.date,
    updated: null,
    author: bylines[0] ?? { name: ctx.house, principal: null },
    bylines,
    tags: record.tags,
    body: { html, source: 'medium' },
    text: words,
    readMinutes: readMinutes(words.split(' ').length),
    cover: null,
    duration: null,
    aspect: null,
    video: null,
    audio: null,
    chapters: [],
    transcript: null,
    episode: null,
    clip: false,
    sourceUrl: record.url,
    paid: false,
    disclosure: null,
    visibility: ctx.visibility[id] ?? 'shown',
    joins: [],
    series: [],
  };
}
