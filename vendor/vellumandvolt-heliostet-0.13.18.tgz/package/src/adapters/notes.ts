// A writer's own notes on their pieces (relay entry 127): one JSON file each in src/content/notes/, written by hand or
// by the Cockpit, for a site whose stories are short notes that link to where each piece is published (Medium, a
// Substack, another outlet), not the pieces themselves. Read into the stories collection as `source: 'notes'`, the way
// chapters are read from their folder. Each note passes the sanitizer like any import (SEC-1).

import { z } from 'zod';
import { readMinutes, type Item } from '../build/item.js';
import { plainText, sanitize } from '../build/sanitize.js';
import type { ItemContext } from './substack.js';

export const NOTES_DIR = 'src/content/notes/';

const https = z.url({ protocol: /^https$/ });

export const noteRecordSchema = z.strictObject({
  slug: z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  title: z.string().trim().min(1),
  dek: z.string().default(''),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  /** The writer's note, in paragraphs, each its own string. */
  note: z.array(z.string().trim().min(1)).min(1),
  tags: z.array(z.string()).default([]),
  /** Where the piece is published, the first where readers go next. */
  links: z.array(z.strictObject({ label: z.string().trim().min(1), platform: z.string().optional(), url: https })).min(1),
  /** The note's picture, from the site's own files. */
  image: z.strictObject({ src: z.string().min(1), alt: z.string().default(''), width: z.int().optional(), height: z.int().optional() }).optional(),
});
export type NoteRecord = z.infer<typeof noteRecordSchema>;

const escape = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export function toNoteItem(record: NoteRecord, ctx: ItemContext): Item {
  const id = `notes:${record.slug}`;
  const html = sanitize(record.note.map((p) => `<p>${escape(p)}</p>`).join(''));
  const words = plainText(html);
  const first = record.links[0]!;
  const author = ctx.principals[0] ? { name: ctx.principals[0].names[0] ?? ctx.house, principal: ctx.principals[0].id } : { name: ctx.house, principal: null };
  return {
    id,
    source: 'notes',
    kind: 'story',
    slug: record.slug,
    title: record.title,
    dek: record.dek,
    // Noon, so the day holds in every zone the site is read from.
    date: `${record.date}T12:00:00.000Z`,
    updated: null,
    author,
    bylines: [author],
    tags: record.tags,
    body: { html, source: 'notes' },
    text: words,
    readMinutes: readMinutes(words.split(' ').length),
    cover: record.image ? { src: record.image.src, alt: record.image.alt, ...(record.image.width ? { width: record.image.width } : {}), ...(record.image.height ? { height: record.image.height } : {}) } : null,
    duration: null,
    aspect: null,
    video: null,
    audio: null,
    chapters: [],
    transcript: null,
    episode: null,
    clip: false,
    sourceUrl: first.url,
    outlet: first.label,
    paid: false,
    disclosure: null,
    visibility: ctx.visibility[id] ?? 'shown',
    joins: [],
    series: [],
  };
}
