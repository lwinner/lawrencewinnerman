// The podcast adapter (FMT-2): a podcast's RSS feed, one episode per item, with its title,
// show notes, season and episode numbers, art, and audio enclosure. The audio file is never
// copied; the page plays it from the host with a plain audio element. The Press has no podcast
// feed, so this is new; it reads RSS with the same parser the Press uses for Substack's feed.
// One JSON file per episode goes into the client repository. A feed's <podcast:transcript> is
// fetched at import and stored with the episode as sanitized cues (relay entry 8, captions ruling);
// a joined video takes it when it has no captions of its own.

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { XMLParser } from 'fast-xml-parser';
import { z } from 'zod';
import type { Item } from '../build/item.js';
import { clockSeconds, parseChapters, slugify } from '../build/media.js';
import { decodeEntities, plainText, sanitize } from '../build/sanitize.js';
import { cueSchema, FORMAT_PREFERENCE, parseTranscript, TRANSCRIPT_MAX_BYTES, type TranscriptFormat, transcriptFormat } from '../build/transcript.js';
import type { ItemContext } from './substack.js';

export const PODCAST_DIR = 'src/content/podcast/';
export const IMPORT_VERSION = 1;

export const podcastRecordSchema = z.strictObject({
  guid: z.string().min(1),
  slug: z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  title: z.string(),
  /** The show notes, sanitized. */
  notes: z.string(),
  date: z.iso.datetime(),
  season: z.int().positive().nullable(),
  episode: z.int().positive().nullable(),
  image: z.url({ protocol: /^https$/ }).nullable(),
  enclosure: z.strictObject({ url: z.url({ protocol: /^https$/ }), type: z.string(), length: z.int().min(0).nullable() }),
  duration: z.int().min(0).nullable(),
  link: z.url({ protocol: /^https$/ }).nullable(),
  /** The feed's transcript in the format Heliostet prefers, and its cues once fetched. */
  transcriptSource: z.strictObject({ url: z.url({ protocol: /^https$/ }), format: z.enum(['vtt', 'srt', 'json', 'html']) }).nullable().optional(),
  transcript: z.array(cueSchema).nullable().optional(),
  imported: z.int(),
});
export type PodcastRecord = z.infer<typeof podcastRecordSchema>;

export class PodcastError extends Error {
  override name = 'PodcastError';
}

const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@_', parseTagValue: false, processEntities: true, htmlEntities: true });

type Node = Record<string, unknown>;
const list = <T>(v: T | T[] | undefined): T[] => (v === undefined ? [] : Array.isArray(v) ? v : [v]);
const text = (v: unknown): string => (v == null ? '' : typeof v === 'object' ? String((v as Node)['#text'] ?? '') : String(v)).trim();
const https = (v: string) => (/^https:\/\//.test(v) ? v : null);
const positive = (v: string) => (/^\d+$/.test(v) && Number(v) > 0 ? Number(v) : null);

/** The item's <podcast:transcript> Heliostet reads best: https only, timed formats first. */
function feedTranscript(item: Node): { url: string; format: TranscriptFormat } | null {
  const offered = list(item['podcast:transcript'] as Node | Node[] | undefined).flatMap((t) => {
    const url = https(String(t['@_url'] ?? ''));
    const format = transcriptFormat(String(t['@_type'] ?? '')) ?? transcriptFormat(url ?? '');
    return url && format ? [{ url, format }] : [];
  });
  return offered.sort((a, b) => FORMAT_PREFERENCE.indexOf(a.format) - FORMAT_PREFERENCE.indexOf(b.format))[0] ?? null;
}

/** Fetches and parses one transcript; null when it cannot be read, is too large, or is empty. */
async function fetchTranscript(source: { url: string; format: TranscriptFormat }, get: typeof fetch): Promise<PodcastRecord['transcript']> {
  const response = await get(source.url, { headers: { accept: 'text/vtt, application/x-subrip, application/json, text/html' } }).catch(() => null);
  if (!response?.ok) return null;
  const length = Number(response.headers.get('content-length') ?? 0);
  if (length > TRANSCRIPT_MAX_BYTES) return null;
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.byteLength > TRANSCRIPT_MAX_BYTES) return null;
  const cues = parseTranscript(new TextDecoder().decode(bytes), source.format);
  return cues.length ? cues : null;
}

/** The episodes in a podcast feed, newest first, with slugs made unique within the feed. */
export function parseFeed(xml: string): PodcastRecord[] {
  const channel = (parser.parse(xml) as Node)?.rss as Node | undefined;
  const items = list((channel?.channel as Node | undefined)?.item as Node | Node[] | undefined);
  const showImage = https(String(((channel?.channel as Node)?.['itunes:image'] as Node | undefined)?.['@_href'] ?? ''));
  const used = new Set<string>();
  const records: PodcastRecord[] = [];
  for (const item of items) {
    const enclosure = item.enclosure as Node | undefined;
    const audio = https(String(enclosure?.['@_url'] ?? ''));
    if (!audio) continue; // an item without audio is not an episode
    const title = decodeEntities(text(item.title));
    let slug = slugify(title);
    for (let n = 2; used.has(slug); n++) slug = `${slugify(title)}-${n}`;
    used.add(slug);
    const notes = text(item['content:encoded']) || text(item.description);
    const date = new Date(text(item.pubDate));
    records.push({
      guid: text(item.guid) || audio,
      slug,
      title,
      notes: sanitize(notes),
      date: Number.isNaN(date.getTime()) ? new Date(0).toISOString() : date.toISOString(),
      season: positive(text(item['itunes:season'])),
      episode: positive(text(item['itunes:episode'])),
      image: https(String((item['itunes:image'] as Node | undefined)?.['@_href'] ?? '')) ?? showImage,
      enclosure: { url: audio, type: String(enclosure?.['@_type'] ?? 'audio/mpeg'), length: positive(String(enclosure?.['@_length'] ?? '')) },
      duration: clockSeconds(text(item['itunes:duration'])),
      link: https(text(item.link)),
      transcriptSource: feedTranscript(item),
      transcript: null,
      imported: IMPORT_VERSION,
    });
  }
  return records.sort((a, b) => b.date.localeCompare(a.date));
}

/** Imports every episode in the feed into `dir`; a file is written only when it changes. */
export async function importFeed(feed: string, dir: URL, options: { fetch?: typeof fetch } = {}): Promise<{ listed: number; written: number }> {
  if (!/^https:\/\//.test(feed)) throw new PodcastError(`The podcast feed must be https: ${feed}`);
  const response = await (options.fetch ?? fetch)(feed, { headers: { accept: 'application/rss+xml, application/xml' } }).catch(() => null);
  if (!response?.ok) throw new PodcastError(`The podcast feed ${response ? `returned HTTP ${response.status}` : 'could not be reached'}: ${feed}`);
  const records = parseFeed(await response.text());
  mkdirSync(dir, { recursive: true });
  let written = 0;
  for (const record of records) {
    const file = new URL(`${record.slug}.json`, dir);
    if (record.transcriptSource) {
      // A transcript already fetched from the same address is kept rather than fetched again.
      const before = existsSync(file) ? (JSON.parse(readFileSync(file, 'utf8')) as Partial<PodcastRecord>) : null;
      record.transcript =
        before?.transcriptSource?.url === record.transcriptSource.url && before.transcript?.length
          ? before.transcript
          : await fetchTranscript(record.transcriptSource, options.fetch ?? fetch);
    }
    const json = `${JSON.stringify(record, null, 2)}\n`;
    if (!existsSync(file) || readFileSync(file, 'utf8') !== json) {
      writeFileSync(file, json);
      written++;
    }
  }
  return { listed: records.length, written };
}

export function toPodcastItem(record: PodcastRecord, ctx: ItemContext): Item {
  const id = `podcast:${record.guid}`;
  const html = sanitize(record.notes);
  const words = plainText(html);
  return {
    id,
    source: 'podcast',
    kind: 'episode',
    slug: record.slug,
    title: record.title,
    dek: words.split(/(?<=[.!?])\s/)[0] ?? '',
    date: record.date,
    updated: null,
    author: { name: ctx.house, principal: null },
    bylines: [{ name: ctx.house, principal: null }],
    tags: [],
    body: { html, source: 'podcast' },
    text: words,
    readMinutes: Math.max(1, Math.round((record.duration ?? 0) / 60)),
    cover: record.image ? { src: record.image, alt: ctx.alt[id] ?? '' } : null,
    duration: record.duration,
    aspect: null,
    video: null,
    audio: { url: record.enclosure.url, type: record.enclosure.type, length: record.enclosure.length },
    // Show notes often carry the same timestamp block a video description does.
    chapters: parseChapters(words.replace(/\s(?=(?:\d{1,2}:)?\d{1,2}:\d{2}\s)/g, '\n')),
    transcript: record.transcript ?? null,
    episode: { season: record.season, number: record.episode },
    clip: false,
    sourceUrl: record.link ?? record.enclosure.url,
    paid: false,
    disclosure: null,
    visibility: ctx.visibility[id] ?? 'shown',
    joins: [],
    series: record.season ? [{ kind: 'season' as const, slug: `season-${record.season}`, title: `Season ${record.season}`, part: record.episode ?? 0, url: null }] : [],
  };
}
