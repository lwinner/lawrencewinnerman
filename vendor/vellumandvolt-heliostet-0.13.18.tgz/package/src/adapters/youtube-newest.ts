// A channel's newest videos at build, with no API key (relay entry 125, C3; the map's item 16): the channel's RSS
// feed first, and, when YouTube's feed is down (it has answered 404 for weeks at a time), the channel's own
// /videos page, whose embedded data lists the same videos with relative dates. Beside the full import
// (importChannel), for a site that shows only its newest few. If neither can be read, it returns none and the
// build log says so; the part that shows them hides.

import { XMLParser } from 'fast-xml-parser';

export interface NewestVideo {
  id: string;
  title: string;
  url: string;
  thumb: string;
  /** Its publish date from the feed, or null when only the page's relative label is known. */
  date: Date | null;
  /** "October 9, 2026" from the feed, or "2 days ago" from the channel page. */
  when: string;
}

export interface NewestOptions {
  /** The channel's ID (UC…), for its RSS feed. */
  channelId: string;
  /** The channel's handle (@…), for its /videos page. */
  handle: string;
  count?: number;
  timeZone?: string;
  /** Applied to each title (a site's own title case). */
  title?: (t: string) => string;
  log?: (line: string) => void;
  fetch?: typeof fetch;
}

const UA = { 'user-agent': 'Mozilla/5.0 (compatible; Heliostet build)', 'accept-language': 'en-US,en' };
const video = (id: string, title: string, date: Date | null, when: string, fix: (t: string) => string): NewestVideo => ({ id, title: fix(title), url: `https://www.youtube.com/watch?v=${id}`, thumb: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`, date, when });

async function fromFeed(o: Required<Omit<NewestOptions, 'log'>>): Promise<NewestVideo[]> {
  const res = await o.fetch(`https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(o.channelId)}`, { headers: UA });
  if (!res.ok) throw new Error(`feed ${res.status}`);
  const xml = new XMLParser({ ignoreAttributes: false, parseTagValue: false }).parse(await res.text());
  const entries = [xml?.feed?.entry ?? []].flat() as Record<string, string>[];
  const fmt = new Intl.DateTimeFormat('en-US', { timeZone: o.timeZone, month: 'long', day: 'numeric', year: 'numeric' });
  return entries.slice(0, o.count).map((e) => {
    const d = new Date(e.published as string);
    return video(e['yt:videoId'] as string, String(e.title), d, fmt.format(d), o.title);
  });
}

async function fromChannelPage(o: Required<Omit<NewestOptions, 'log'>>): Promise<NewestVideo[]> {
  const res = await o.fetch(`https://www.youtube.com/${o.handle.startsWith('@') ? o.handle : `@${o.handle}`}/videos`, { headers: UA });
  if (!res.ok) throw new Error(`channel page ${res.status}`);
  const m = (await res.text()).match(/var ytInitialData = (\{.*?\});<\/script>/s);
  if (!m) throw new Error('channel page had no video data');
  const out: NewestVideo[] = [];
  // YouTube's page data, read loosely: any field may be missing.
  const at = (x: unknown, ...path: (string | number)[]): unknown => path.reduce<unknown>((v, k) => (v && typeof v === 'object' ? (v as Record<string | number, unknown>)[k] : undefined), x);
  const text = (x: unknown) => (typeof x === 'string' ? x : '');
  (function walk(x: unknown) {
    if (out.length >= o.count || !x || typeof x !== 'object') return;
    const id = text(at(x, 'lockupViewModel', 'contentId'));
    if (id && at(x, 'lockupViewModel', 'contentType') !== 'LOCKUP_CONTENT_TYPE_PLAYLIST') {
      const md = at(x, 'lockupViewModel', 'metadata', 'lockupMetadataViewModel');
      const rows = at(md, 'metadata', 'contentMetadataViewModel', 'metadataRows');
      const parts = (Array.isArray(rows) ? rows : []).flatMap((r) => { const p = at(r, 'metadataParts'); return Array.isArray(p) ? p : []; });
      const when = parts.map((p) => text(at(p, 'accessibilityLabel')) || text(at(p, 'text', 'content'))).find((t) => /\bago\b/.test(t)) ?? '';
      out.push(video(id, text(at(md, 'title', 'content')), null, when, o.title));
      return;
    }
    const vid = text(at(x, 'videoRenderer', 'videoId'));
    if (vid) {
      out.push(video(vid, text(at(x, 'videoRenderer', 'title', 'runs', 0, 'text')), null, text(at(x, 'videoRenderer', 'publishedTimeText', 'simpleText')), o.title));
      return;
    }
    for (const k in x) walk((x as Record<string, unknown>)[k]);
  })(JSON.parse(m[1] as string));
  return out;
}

/** The newest videos (six by default), from the feed or, when it's down, the channel page; none if neither answers. */
export async function newestVideos(options: NewestOptions): Promise<NewestVideo[]> {
  const log = options.log ?? ((line: string) => console.warn(line));
  const o = { count: 6, timeZone: 'America/New_York', title: (t: string) => t, fetch: globalThis.fetch, ...options } as Required<Omit<NewestOptions, 'log'>>;
  try {
    const v = await fromFeed(o);
    if (v.length) return v;
  } catch (err) {
    log(`[youtube] feed unavailable (${(err as Error).message}); reading the channel page`);
  }
  try {
    return await fromChannelPage(o);
  } catch (err) {
    log(`[youtube] channel page unavailable (${(err as Error).message}); the videos are left out of this build`);
    return [];
  }
}
