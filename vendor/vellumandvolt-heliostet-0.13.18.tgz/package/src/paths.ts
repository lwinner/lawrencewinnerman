// Where Heliostet’s own files live, whether it runs from src/ (tests) or dist/ (installed).
// Both directories sit beside design/ and src/styles/ in the package root.

export const designDir = new URL('../design/', import.meta.url);
export const baseCss = new URL('../src/styles/base.css', import.meta.url);
export const layoutsDir = new URL('../src/layouts/', import.meta.url);
export const bundleCss = new URL('../design/bundle.css', import.meta.url);
export const componentsDir = new URL('../src/components/', import.meta.url);
export const partsDir = new URL('../src/parts/', import.meta.url);
export const partsCss = new URL('../src/parts/parts.css', import.meta.url);
export const siteDir = new URL('../src/site/', import.meta.url);
export const rowsCss = new URL('../src/site/rows.css', import.meta.url);
export const packageJson = new URL('../package.json', import.meta.url);
