// validatePart (relay entry 52, CMP-5), as the site's build runs it: the core (validate-core.ts) with the build's own
// test for an empty rich-text field, its Markdown through the one sanitizer (decision 0004). Importing this sets it.

import { renderMarkdown } from '../build/markdown.js';
import { plainText } from '../build/sanitize.js';
import { setRichEmpty } from './validate-core.js';

setRichEmpty((v) => !plainText(renderMarkdown(v)).trim());

export { goodAddress, validatePart } from './validate-core.js';
