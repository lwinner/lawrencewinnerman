// The parts registry (decision 0017, CMP-2): every part type a page can be built from, each with its
// fields, its variants, its component, and a fixture from real content. A new type of part is code
// here, through the relay; a new page made of parts is data in the client's repository.

export { PARTS, isPartType, variantOf } from './registry.js';
export { validatePart, goodAddress } from './validate.js';
export { validateSite, issueLine, type SiteIssue, type SiteToCheck } from '../site/validate.js';
// For a site's own variants (decision 0019): the same query, and the same numbered pages, as Heliostet's.
export { runQuery, queryMatches, pagesOf, pageAddress } from './data.js';
export type { OwnFrameProps, OwnPage, OwnOptions } from '../site/own.js';
export { PART_TYPES } from './types.js';
// A site's own icon set (relay entry 59): the networks, and an SVG's inside as a glyph.
export { NETWORKS, NETWORK_NAMES, glyphOf } from './networks.js';
export type { Part, PartContext, PartDefinition, PartError, PartType, ContentItem, LinkValue, Pager, ShopifyProduct, Store, StoryReading, ReadStory } from './types.js';
export type { Field, Schema, ImageValue, FileValue, QueryValue } from './fields.js';
