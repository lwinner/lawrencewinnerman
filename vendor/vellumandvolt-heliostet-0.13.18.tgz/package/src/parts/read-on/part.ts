// Read On (relay entry 69): the way from a story's landing page to the whole story, on the platform the
// reader prefers. Read it on Substack, in the look's accent; Read it on Medium, in outline; each names
// its publication. A button shows only for a place the story is live.
import { link, text } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const readOn: PartDefinition = {
  type: 'read-on',
  name: 'Read On',
  what: 'Buttons to the whole story, where it’s published.',
  schema: {
    heading: text('Heading', 60, 'The heading over the buttons: Read the Whole Story.', true),
    line: text('One line', 300, 'Where it lives, and for whom: It’s free on Substack. Optional.'),
    substack: link('Substack', 'The story on Substack, and its publication’s name as the button’s second line. Optional.'),
    medium: link('Medium', 'The story on Medium, and its publication’s name. Optional.'),
  },
  variants: [{ id: 'band', label: 'Band' }],
  component: 'read-on/ReadOn.astro',
  fixtures: [
    {
      type: 'read-on',
      variant: 'band',
      fields: {
        heading: 'Read the Whole Story',
        line: 'It’s free on Substack, where The Daily Whatever lives, and on Medium for members.',
        substack: { to: 'https://thedailywhatever.press/p/a-fake-pollster-tanked-a-real-senate-campaign', label: 'The Daily Whatever' },
        medium: { to: 'https://medium.com/the-daily-whatever/a-fake-pollster-tanked-a-real-senate-campaign', label: 'The Daily Whatever on Medium' },
      },
    },
  ],
  check(fields) {
    const has = (k: string) => !!fields[k] && typeof (fields[k] as { to?: unknown }).to === 'string';
    return has('substack') || has('medium') ? [] : [{ field: 'substack', message: 'Read On needs at least one place the story is live.' }];
  },
};
