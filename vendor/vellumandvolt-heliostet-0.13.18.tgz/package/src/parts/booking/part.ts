// Booking: a way to set a call, out to the person's own booking page. The site never takes a form.
import { link, text } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const booking: PartDefinition = {
  type: 'booking',
  name: 'Booking',
  what: 'A way to set a call.',
  schema: {
    heading: text('Heading', 120, 'The heading: Let’s Talk.', true),
    line: text('One line', 400, 'What the call is for, in a sentence or two.'),
    bookingLink: link('Booking page', 'Your booking page’s address, and the words on its button.', true),
    email: text('Email address', 120, 'An address people can write to instead. Optional.'),
    note: text('A line under the button', 240, 'A line under the button, in the small style. Optional.'),
  },
  variants: [
    { id: 'band', label: 'Band' },
    { id: 'plain', label: 'Plain' },
    { id: 'hero', label: 'Hero: large, to open a page' },
    // The kit fidelity entry (item 4): the button and a short line beside it, no panel, as lawrencewinnerman.com's
    // Consulting ends: Book a call, then Let's talk.
    { id: 'inline', label: 'Inline: the button and a short line, no panel' },
  ],
  component: 'booking/Booking.astro',
  fixtures: [
    {
      type: 'booking',
      variant: 'band',
      fields: {
        heading: 'Let’s Talk',
        line: 'A thirty-minute call to see whether I’m the right fit. No pitch deck required.',
        bookingLink: { to: '/work', label: 'Book a call' },
        email: 'hello@lawrencewinnerman.com',
      },
    },
  ],
  check: (f, variant) => [
    ...(typeof f.email === 'string' && f.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email) ? [{ field: 'email', message: 'That email address doesn’t look right.' }] : []),
    // Inline draws only its button and its heading (QA's notes on 0.13.3 to 0.13.11): say so rather than drop a field.
    ...(variant === 'inline' ? (['line', 'email', 'note'] as const).filter((k) => typeof f[k] === 'string' && (f[k] as string).trim()).map((k) => ({ field: k, message: `Inline shows only the button and the heading, so ${k === 'line' ? 'the line' : k === 'email' ? 'the email address' : 'the line under the button'} won’t appear. Choose another form, or take it out.` })) : []),
  ],
};
