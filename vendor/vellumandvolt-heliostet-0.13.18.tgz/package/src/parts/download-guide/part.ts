// Download guide: a long guide on its page, with its PDF and the day it was last updated.
import { date, file, rich } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const downloadGuide: PartDefinition = {
  type: 'download-guide',
  name: 'Download Guide',
  what: 'A long guide with a PDF.',
  schema: {
    body: rich('Guide', 60000, 'The guide itself.', true),
    pdf: file('PDF', ['pdf'], 'The guide as a PDF, and what to call it.', true),
    updated: date('Updated', 'The day you last changed it. Optional.'),
  },
  variants: [],
  component: 'download-guide/DownloadGuide.astro',
  // The guide's own text and PDF are in Lawrence's site repository, which this entry doesn't read;
  // the fixture has the story's own description of it and the PDF's place at /keys/.
  fixtures: [
    {
      type: 'download-guide',
      fields: {
        body: '## The Hardware Key Guide\n\nPlain-language, tap-by-tap instructions for locking down your accounts, your phone, and your privacy.',
        pdf: { src: '/keys/hardware-key-guide.pdf', label: 'The Hardware Key Guide, PDF' },
        updated: '2026-10-23',
      },
    },
  ],
};
