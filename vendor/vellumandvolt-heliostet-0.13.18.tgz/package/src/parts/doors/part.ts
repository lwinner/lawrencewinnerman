// Doors: two to four routes to the site's main pages, one per hat. Four and no fifth, so the
// composer enforces it (the scope's "junk drawer" rule).
import { group, image, link, text } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const doors: PartDefinition = {
  type: 'doors',
  name: 'Doors',
  what: 'Two to four routes to the main pages.',
  schema: {
    // Relay entry 112: a heading over the doors, and up to six, as How We Work's five steps.
    heading: text('Heading', 80, 'A heading above the doors: Two Ways to Work. Optional.'),
    doors: group('Doors', 'door', 2, 6, {
      label: text('Label', 30, 'A word or two above the title: Read, Fiction. Optional in numbered steps.'),
      title: text('Title', 60, 'What the door opens onto.', true),
      line: text('One line', 160, 'One line on what a visitor finds there.'),
      to: link('Goes to', 'The page or address the door opens, and the words on its link. Optional in numbered steps.'),
      image: image('Image', 'A picture for the door. Optional; describe it.'),
    }, 'Two to six doors, one for each kind of visitor, or each step.'),
  },
  variants: [
    { id: 'cards', label: 'Cards' },
    { id: 'numbered', label: 'Numbered list' },
  ],
  component: 'doors/Doors.astro',
  fixtures: [
    {
      type: 'doors',
      variant: 'cards',
      fields: {
        doors: [
          { label: 'Read', title: 'Essays on AI, work, and power', line: 'The Hinge & The Near Field, plus my pieces for the Daily Whatever and Medium.', to: { to: '/writing', label: 'All my writing' } },
          { label: 'Fiction', title: 'The Shattered World', line: 'Book One, *Light Shines Through*, serialized chapter by chapter. Book Two is in development.', to: { to: '/fiction', label: 'Start with the prologue' } },
          { label: 'The show', title: 'The Daily Whatever', line: 'Satire and news commentary, live weekday mornings with Dana DuBois.', to: { to: '/show', label: 'Watch and read' } },
          { label: 'Hire me', title: 'Work With Me', line: 'Content strategy, operations, AI-assisted editorial work, speaking, and roles.', to: { to: '/work', label: 'See how I work' } },
        ],
      },
    },
  ],
};
