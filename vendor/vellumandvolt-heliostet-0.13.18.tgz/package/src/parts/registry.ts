// The registry itself, kept apart from index.ts so the validator can read it without a cycle.

import { booking } from './booking/part.js';
import { chapterReader } from './chapter-reader/part.js';
import { doors } from './doors/part.js';
import { downloadGuide } from './download-guide/part.js';
import { hello } from './hello/part.js';
import { imagePart } from './image/part.js';
import { links } from './links/part.js';
import { listPart } from './list/part.js';
import { merch } from './merch/part.js';
import { pressKit } from './press-kit/part.js';
import { projectCards } from './project-cards/part.js';
import { prose } from './prose/part.js';
import { quote } from './quote/part.js';
import { readOn } from './read-on/part.js';
import { services } from './services/part.js';
import { storyNote } from './story-note/part.js';
import { subscribe } from './subscribe/part.js';
import { video } from './video/part.js';
import { PART_TYPES, type PartDefinition, type PartType } from './types.js';

export const PARTS: Readonly<Record<PartType, PartDefinition>> = {
  hello,
  doors,
  list: listPart,
  prose,
  'story-note': storyNote,
  'chapter-reader': chapterReader,
  services,
  booking,
  'project-cards': projectCards,
  quote,
  video,
  merch,
  image: imagePart,
  subscribe,
  'press-kit': pressKit,
  'download-guide': downloadGuide,
  links,
  'read-on': readOn,
};

export const isPartType = (type: string): type is PartType => (PART_TYPES as readonly string[]).includes(type);

/** The part's variant, or its first when it names none. */
export function variantOf(def: PartDefinition, variant: string | undefined): string {
  return variant ?? def.variants[0]?.id ?? 'default';
}
