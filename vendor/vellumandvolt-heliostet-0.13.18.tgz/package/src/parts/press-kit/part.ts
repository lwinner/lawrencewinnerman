// Press kit: what a journalist needs, ready to download.
import { file, group, image, rich, text } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const pressKit: PartDefinition = {
  type: 'press-kit',
  name: 'Press Kit',
  what: 'What a journalist needs, ready to download.',
  schema: {
    shortBio: text('Short bio', 300, 'A bio of a sentence or two.', true),
    longBio: rich('Long bio', 4000, 'The longer bio, a few paragraphs.', true),
    headshots: group('Headshots', 'headshot', 1, 6, {
      image: image('Headshot', 'A photo to download. Describe it.', true),
    }, 'One to six photos.'),
    markFiles: group('Mark files', 'file', 0, 6, {
      file: file('File', ['svg', 'png', 'pdf', 'zip'], 'Your sigil or logo as a file, and what to call it.', true),
    }, 'Your sigil or logo files. Optional.'),
    factLine: text('Fact line', 200, 'One line of facts for a byline or an introduction. Optional.'),
  },
  variants: [],
  component: 'press-kit/PressKit.astro',
  fixtures: [
    {
      type: 'press-kit',
      fields: {
        shortBio: 'Gen X writer and strategist. Essays on AI, work, and power, and a serialized novel.',
        longBio: 'Lawrence Winnerman is a Gen X writer and strategist working the seam where institutions break: what comes next, and how we build it.\n\nHe writes *The Hinge & The Near Field*, essays on AI, work, and power; serializes *The Shattered World*, a novel; and appears on *The Daily Whatever*, satire and news commentary live weekday mornings with Dana DuBois.',
        headshots: [{ image: { src: '/gallery/lawrence-winnerman-headshot-800.jpg', alt: 'Lawrence Winnerman, with a full white beard, in front of a turquoise wall' } }],
        markFiles: [{ file: { src: '/gallery/sigil-master.svg', label: 'The sigil, SVG' } }, { file: { src: '/gallery/sigil-on-cream.svg', label: 'The sigil on cream, SVG' } }],
        factLine: 'Essayist · Novelist · Strategist · Podcaster',
      },
    },
  ],
};
