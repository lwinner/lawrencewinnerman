// What a part is, as data and as a type in the registry (decision 0017, relay entry 52).

import type { ImageValue, QueryValue, Schema } from './fields.js';

export const PART_TYPES = [
  'hello',
  'doors',
  'list',
  'prose',
  'story-note',
  'chapter-reader',
  'services',
  'booking',
  'project-cards',
  'quote',
  'video',
  'merch',
  'image',
  'subscribe',
  'press-kit',
  'download-guide',
  'links',
  // Relay entry 69: the Article Desk's landing pages.
  'read-on',
] as const;
export type PartType = (typeof PART_TYPES)[number];

/** One part on a page, as it sits in the client's repository: its type, its variant, its fields. */
export interface Part {
  id?: string;
  type: string;
  variant?: string | undefined;
  fields: Record<string, unknown>;
}

/** An error the composer shows beside the field: "The third door needs somewhere to go." */
export interface PartError {
  /** The part, by its id when it has one, else its type. */
  part: string;
  /** The field, as a path: "doors.2.to". */
  field: string;
  message: string;
}

/** A part type in the registry. */
export interface PartDefinition {
  type: PartType;
  /** Its name in the composer, in title case: "Project Cards." */
  name: string;
  /** One line on what it's for. */
  what: string;
  schema: Schema;
  /** Its variants, first the default; empty when it has one form only. */
  /**
   * Its variants. A variant that draws a form taking an email address says so (`takesEmail`): the site
   * never collects one (ONB-1) except on the pages the record's `exceptions.emailForm` names.
   */
  variants: readonly { id: string; label: string; takesEmail?: boolean }[];
  /** Its Astro component, relative to package/src/parts/. */
  component: string;
  /** The part as filled in for the gallery, from real content; the first is the one the gallery draws in every variant. */
  fixtures: readonly Part[];
  /** Rules across fields that the schema can't say, such as "a picked video needs its address." */
  /** A rule across fields, with the variant it's drawn as (the part's first when it names none). */
  check?: (fields: Record<string, unknown>, variant: string) => { field: string; message: string }[];
}

/** Somewhere to go, with the words to say it: a page ("/work") or an address. */
export interface LinkValue {
  to: string;
  label?: string;
}

/** One item a part can show from the site's own content: a story, a chapter, an episode, a video. */
export interface ContentItem {
  id: string;
  kind: 'story' | 'chapter' | 'episode' | 'video';
  title: string;
  dek?: string;
  /** ISO date. */
  date: string;
  /** Minutes to read it (relay entry 125: the front page's lead). */
  readMinutes?: number;
  /** Its address where it was first published: the Substack post (relay entry 125: Watch on Substack). */
  sourceUrl?: string;
  /** Where it was published: "The Hinge & The Near Field." */
  outlet: string;
  /** Its page on the site. */
  href: string;
  /** Its ID where it lives: a Substack post's slug, a YouTube ID. A video part picks a video by it. */
  sourceId?: string;
  /** Its picture; with the site's image sizing, at a card's width with a srcset (relay entry 59). */
  image?: ImageValue & { srcset?: string };
  topics?: string[];
  /** The bylines a card draws, each principal with their page on the site (relay entry 59). */
  credits?: { name: string; href?: string }[];
  /** The tags a card shows, from the site's card tags (relay entry 59): "Friday." */
  tags?: string[];
  /** A disclosure the story carries, with the site's words for it (relay entry 59): satire. */
  disclosure?: { kind: 'satire'; label: string };
  byline?: string;
  /** Every byline, in order, and the principals they are (relay entry 55): a list by one host has her co-bylined stories too. */
  bylines?: string[];
  people?: string[];
  /** A chapter's series and book, for grouping. */
  series?: string;
  book?: string;
  /** A video: where it plays. A YouTube video plays in place; one uploaded to Substack plays on Substack. */
  video?: { host: 'youtube'; id: string } | { host: 'substack'; url: string };
  /** "Live," for a live conversation. */
  live?: boolean;
}

/**
 * A site's own reading of one story (relay entry 125), from the module site.json names: what Heliostet's story page
 * draws that only the site knows. Everything is optional but the body.
 */
export interface StoryReading {
  /** The body as the site reads it, as HTML the site has made safe. */
  html: string;
  /** The lead picture's description, and its credit. */
  imageAlt?: string | undefined;
  imageCredit?: string | null | undefined;
  /** The story's sources, numbered beside it: each link, its words, and where it is from. */
  sources?: { href: string; text: string; where: string }[] | undefined;
  /** Where to read it, in order (Read on Substack, Read on Medium); given, it replaces Heliostet's own Read on its platform. */
  readOn?: LinkValue[] | undefined;
  /** Only part of it is here; the rest is where it was first published. */
  paywalled?: boolean | undefined;
  /** Its episode, when it has one: the video, its chapters, and its transcript, plain or timed. */
  episode?: { youtubeId: string; chapters: { start: number; title: string }[]; transcript: string | { start: number | null; text: string }[] } | null | undefined;
  /** Its authors, by person, when they aren't its bylines: a story by the house is by every principal. */
  people?: string[] | undefined;
}

/** The site's reading module's export: a story's reading, or null to draw it as Heliostet reads it. */
export type ReadStory = (item: ContentItem) => StoryReading | null | Promise<StoryReading | null>;

/** A product as Shopify's public product list gives it (MER-1): /products.json. */
export interface ShopifyProduct {
  id: number;
  title: string;
  handle: string;
  vendor?: string;
  variants: { id: number; title: string; price: string; available: boolean }[];
  images: { id: number; src: string; alt: string | null; width?: number; height?: number }[];
}

/** A store on the client record. */
export interface Store {
  name: string;
  url: string;
  products: ShopifyProduct[];
}

/**
 * Where a list that runs over numbered pages is (relay entry 55): this page's number, the last, and
 * the addresses either side, as Astro's own pagination gives them.
 */
export interface Pager {
  current: number;
  last: number;
  prev: string | null;
  next: string | null;
}

/** What a part draws from beyond its own fields: the site's content and its store. */
export interface PartContext {
  timeZone: string;
  items: ContentItem[];
  stores: Store[];
  /** The site's people (relay entry 59): each principal with a page on the site, in this build's order. */
  people?: { id: string; name: string; first: string; href: string; card?: { role: string; bio: string; photo?: { src: string; alt: string; small?: string | undefined; tiny?: string | undefined } | undefined; links: { network: string; to: string }[] } }[];
  /** The kinds of show on air as this build runs (relay entry 125), from the site's shows feed: each show an hour from its start. */
  onAir?: string[];
  /** The site's shows and their confirmed guests (relay entry 125), from its shows feed at build: none when it names no feed. */
  shows?: { date: string; kind: string; title: string | null; time: string; timeLabel: string; airAt: string; thumb: string | null; guests: { id: string; name: string; initials: string; bio: string | null; substack: string | null; website: string | null; headshot: string | null }[] }[];
  /** When this build ran, as the shows are read against it (relay entry 125). */
  builtAt?: string;
  /** The channel's newest videos (relay entry 125), when site.json names a channel: the feed's, or its /videos page's. */
  videos?: { id: string; title: string; url: string; thumb: string; date: string | null; when: string }[];
  /** The site's own icon set (relay entry 59): each network's glyph, as the inside of a 24 by 24 SVG. */
  icons?: Record<string, string>;
  /** What the satire disclosure says on this site (relay entry 59). */
  satire?: string;
  /** How many bands the look has (relay entry 59): none when it names none. */
  bands?: number;
  /** The client's channels, in its order (relay entry 91): each subscribe destination, the Support link, then each social account. */
  channels?: { label: string; to: string; kind: 'subscribe' | 'support' | 'social'; network?: string }[];
}

export type { ImageValue, QueryValue };
