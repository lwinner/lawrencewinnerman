// Subscribe: the way to the newsletter. The site never collects an email address (ONB-1), so this
// is a link out to the publication's own sign-up, never a form on the site, except where a site's
// record says otherwise: the form variant hands the address to the publication's sign-up, and the
// site check allows it only on the pages the record's exceptions.emailForm names (relay entry 57).
import { choice, group, link, text } from '../fields.js';
import { NETWORK_NAMES, NETWORKS } from '../networks.js';
import type { PartDefinition } from '../types.js';

export const subscribe: PartDefinition = {
  type: 'subscribe',
  name: 'Subscribe',
  what: 'The way to your newsletter.',
  schema: {
    publication: link('Publication', 'Your newsletter’s address (for the form, its sign-up address), and the words on its button.', true),
    heading: text('Heading', 60, 'The heading: Get the Next Essay.', true),
    line: text('One line', 400, 'What readers get, in a sentence or two. Optional.'),
    eyebrow: text('Kicker', 60, 'A word or two above the heading. Optional.'),
    note: text('Note', 300, 'A line under the button or the form: what happens next. Optional.'),
    moreHeading: text('Other ways in: heading', 60, 'The heading over the other ways in. Optional.'),
    more: group('Other ways in', 'way', 0, 8, { link: link('Link', 'Where it goes, and its words.', true), note: text('Note', 40, 'A word or two beside it: Open, /feed.xml. Optional.') }, 'Other places to follow: a feed, a channel, a show. Optional.'),
    // Relay entry 59: the publication's accounts, on the Subscribe page.
    followHeading: text('Accounts: heading', 60, 'The words over the accounts: Follow TDWS. Optional.'),
    followOwner: text('Accounts: whose', 40, 'Whose accounts, for each link’s label: TDWS. Optional.'),
    follow: group('Accounts', 'account', 0, 14, { network: choice('Network', NETWORKS.map((n) => [n, NETWORK_NAMES[n]] as const), 'Which network.', true), to: link('Address', 'The account’s address.', true) }, 'The publication’s accounts, each drawn with the site’s own icon. Optional.'),
  },
  variants: [
    { id: 'band', label: 'Band' },
    { id: 'inline', label: 'Inline' },
    // The kit fidelity entry (item 6): centered on a raised card, an accent rule across its top, as lawrencewinnerman.com's.
    { id: 'card', label: 'Card: centered, an accent rule on top' },
    // Relay entry 57: the Press's exception to ONB-1, Lawrence's ruling of October 24.
    { id: 'form', label: 'An email field, for the sign-up (only where the record allows it)', takesEmail: true },
    // Relay entry 59: the Press's Subscribe page and About's closing call.
    { id: 'page', label: 'A Subscribe page: the email field, the accounts, and the other ways in (only where the record allows it)', takesEmail: true },
    { id: 'cta', label: 'A closing call: a heading, and a button to the Subscribe page' },
    { id: 'band-form', label: 'A band with an email field, shared across pages (only where the record allows the band)', takesEmail: true },
  ],
  component: 'subscribe/Subscribe.astro',
  fixtures: [
    {
      type: 'subscribe',
      variant: 'band',
      fields: {
        publication: { to: 'https://lwinner.substack.com/subscribe', label: 'Subscribe on Substack' },
        heading: 'Get the Next Essay',
        line: 'The Hinge & The Near Field, in your inbox. Free, and on Substack.',
      },
    },
  ],
};
