// The content the parts' fixtures draw from (relay entry 52): Lawrence's real stories, chapters,
// videos, and store, as they appear in the scope's mockups ("lawrencewinnerman.com on Heliostet:
// Scope and the Page Builder," October 24, 2026). The images are the mockups' copies, served by the
// example from /gallery/. Where the mockups give no address (a story's Substack post, the booking
// page), the fixture uses the publication's own address and the reply to relay entry 52 says so.
// The one YouTube video is the example's own fictional show, since none of Lawrence's videos in
// the mockups is on YouTube.

import products from './alpacalunch-products.json' with { type: 'json' };
import type { ContentItem, PartContext, ShopifyProduct } from '../types.js';

export const HINGE = 'The Hinge & The Near Field';
export const HINGE_URL = 'https://lwinner.substack.com';
export const TDW = 'The Daily Whatever';
const SERIES = 'The Shattered World';
const BOOK_ONE = 'Book One · Light Shines Through';

const stories: ContentItem[] = [
  // Relay entry 59: a story with the satire disclosure, from relay entry 58's archive.
  {
    id: 'ai-optimists',
    kind: 'story',
    title: 'AI Optimists? AI Researchers Now Smoking Because Superintelligence Will Cure Cancer',
    dek: 'Satire: the researchers have taken up smoking, sure that superintelligence will cure cancer before it matters.',
    date: '2026-10-24T12:00:00.000Z',
    outlet: TDW,
    href: '/writing/ai-optimists',
    byline: 'Lawrence Winnerman',
    topics: ['Technology'],
    disclosure: { kind: 'satire', label: 'Contains satire' },
    tags: ['Friday'],
  },
  {
    id: 'security-key-guide',
    kind: 'story',
    title: 'You Asked for the Security Key Guide. Here It Is.',
    dek: 'Plain-language, tap-by-tap instructions for locking down your accounts, your phone, and your privacy.',
    date: '2026-10-23T12:00:00.000Z',
    outlet: HINGE,
    href: '/writing/security-key-guide',
    byline: 'Lawrence Winnerman',
    topics: ['Security', 'Privacy'],
    image: { src: '/gallery/security-key-guide.jpg', alt: 'Hardware security keys of several shapes on a white table, above the words “Pick a key, any key”' },
  },
  {
    id: 'top-7-good-signs-midterms',
    kind: 'story',
    title: 'Top 7 Good Signs 12 Days Out from the Midterms',
    dek: 'Record-low approval, a double-digit generic ballot, and early voting shattering records.',
    date: '2026-10-22T12:00:00.000Z',
    outlet: TDW,
    href: '/writing/top-7-good-signs-midterms',
    byline: 'Lawrence Winnerman',
    topics: ['Democracy and Power'],
    image: { src: '/gallery/top-7-good-signs-midterms.jpg', alt: 'An illustrated city skyline in bright colors with a checked ballot, under the words “12 days out, 7 good signs, vote early”' },
  },
  {
    id: 'world-war-three-started',
    kind: 'story',
    title: 'World War Three Is Here. We’re Still Arguing About the Start Date.',
    dek: 'Ukraine. Iran. Sabotage in Europe. The war may already be underway.',
    date: '2026-10-20T12:00:00.000Z',
    outlet: HINGE,
    href: '/writing/world-war-three-started',
    byline: 'Lawrence Winnerman',
    topics: ['World', 'World War III', 'Democracy and Power'],
    image: { src: '/gallery/world-war-three-started.jpg', alt: 'A quiz card asking when World War III began, with every answer checked' },
  },
];

const chapter = (id: string, title: string, date: string): ContentItem => ({
  id,
  kind: 'chapter',
  title,
  date: `${date}T12:00:00.000Z`,
  outlet: HINGE,
  href: `/fiction/light-shines-through/${id}`,
  series: SERIES,
  book: BOOK_ONE,
});

/** Book One as the chapter page's index lists it, prologue to Chapter 6. */
const chapters: ContentItem[] = [
  chapter('prologue', 'Prologue: João', '2025-03-26'),
  chapter('chapter-1', '1. Sharon', '2025-07-02'),
  chapter('chapter-2', '2. Jake', '2025-07-13'),
  chapter('chapter-3', '3. Jackie', '2025-07-20'),
  chapter('interstitial', 'Interstitial', '2025-07-21'),
  chapter('chapter-4', '4. Sharon', '2025-07-27'),
  chapter('chapter-5', '5. Jackie', '2025-08-11'),
  chapter('chapter-6', '6. Jake', '2025-08-18'),
];

const videos: ContentItem[] = [
  {
    id: 'the-irkutsk-mystery',
    kind: 'video',
    sourceId: 'the-irkutsk-mystery',
    title: 'The Irkutsk Mystery: What Is Russia Hiding?',
    dek: 'A 28-year-old lab worker is dead, official reports vanished, and Moscow’s story keeps changing.',
    date: '2026-10-07T12:00:00.000Z',
    outlet: HINGE,
    href: '/videos/the-irkutsk-mystery',
    live: true,
    image: { src: '/gallery/video-irkutsk.jpg', alt: 'Three people on a live video call, above the words “What if…?”' },
    video: { host: 'substack', url: HINGE_URL },
  },
  {
    id: 'how-emotions-are-made',
    kind: 'video',
    sourceId: 'how-emotions-are-made',
    title: '“How Emotions Are Made” Live with Ann Kramer',
    date: '2026-10-13T12:00:00.000Z',
    outlet: HINGE,
    href: '/videos/how-emotions-are-made',
    live: true,
    image: { src: '/gallery/video-emotions.jpg', alt: 'Lawrence Winnerman’s sigil, red on cream' },
    video: { host: 'substack', url: HINGE_URL },
  },
];

/** The example's own fictional show, on YouTube, with no poster that can load. */
const episodes: ContentItem[] = [
  {
    id: 'nfh0141',
    kind: 'episode',
    sourceId: 'nfh0141',
    title: 'Episode 141: The budget hearing, annotated',
    dek: 'The county’s budget hearing, line by line, with what each number means for the first week after a disruption.',
    date: '2026-10-08T23:00:00.000Z',
    outlet: 'The Near Field Hour',
    href: '/episode/nfh0141',
    video: { host: 'youtube', id: 'nfh0141' },
  },
];

export const ALPACALUNCH = { name: 'alpacalunch', url: 'https://alpacalunch.com', products: (products as { products: ShopifyProduct[] }).products };

/** The context every fixture draws in. */
export const FIXTURE_CONTEXT: PartContext = {
  timeZone: 'America/New_York',
  // Each story's byline links to the person's page (relay entry 59).
  items: [...stories.map((s) => ({ ...s, credits: s.credits ?? [{ name: s.byline ?? 'Lawrence Winnerman', href: '/about' }] })), ...chapters, ...videos, ...episodes],
  stores: [ALPACALUNCH],
  // Relay entry 59: the site's one person, the satire disclosure's words, and four bands. A site's
  // own icon set comes from the site (the gallery adds the example's); none is here.
  people: [
    {
      id: 'lawrence',
      name: 'Lawrence Winnerman',
      first: 'Lawrence',
      href: '/about',
      card: {
        role: 'Essayist and novelist',
        bio: 'A Gen X writer and strategist working the seam where institutions break: what comes next, and how we build it. He writes *The Hinge & The Near Field*.',
        photo: { src: '/gallery/lawrence-winnerman-headshot-800.jpg', small: '/gallery/lawrence-winnerman-headshot-400.jpg', alt: 'Lawrence Winnerman, with a full white beard, in front of a turquoise wall' },
        links: [
          { network: 'substack', to: HINGE_URL },
          { network: 'rss', to: '/feed.xml' },
          { network: 'web', to: 'https://lawrencewinnerman.com' },
        ],
      },
    },
  ],
  satire: 'Contains satire',
  bands: 4,
};
