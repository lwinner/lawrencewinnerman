// Project cards: the other things this person makes, each with its role and its status.
import { choice, group, image, link, text, yes } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const projectCards: PartDefinition = {
  type: 'project-cards',
  name: 'Project Cards',
  what: 'Other things you make.',
  schema: {
    // The kit fidelity entry (item 2c): this part's own card style, over the Look's.
    card: choice('Cards', [['boxed', 'Boxed, on a panel'], ['open', 'Open, on a rule']] as const, 'How the cards are drawn. Left out, the Look’s card style.'),
    heading: text('Heading', 60, 'The heading: More I Make.'),
    // The kit fidelity entry (item 3): lawrencewinnerman.com's Work, its "Also made" row four across under a small label.
    headingStyle: choice('Heading style', [['heading', 'A heading'], ['label', 'A small label']] as const, 'How the heading is drawn: a heading, or a small label such as Also made. Left out, a heading.'),
    columns: choice('Columns', [['2', 'Two'], ['3', 'Three'], ['4', 'Four']] as const, 'How many across on a wide screen; two on a tablet, one on a phone. Left out, as the look lays them.'),
    visit: yes('Visit links', 'A Visit link under each project that has an address, with its name as plain words.'),
    moreLink: link('More link', 'Where to see every project, and the words on the link. Optional.'),
    cards: group('Projects', 'project', 1, 8, {
      name: text('Name', 60, 'The project’s name.', true),
      role: text('Your role', 40, 'What you are to it: Founder, Creator.'),
      line: text('One line', 300, 'What it is, in a sentence or two.'),
      image: image('Image', 'A picture or logo for it. Optional; describe it.'),
      status: choice('Status', [['active', 'Active'], ['on hiatus', 'On hiatus'], ['archived', 'Archived']], 'Whether it’s running. On hiatus and Archived show on the card.'),
      to: link('Goes to', 'The project’s page or address. Optional.'),
    }, 'One to eight projects.'),
    // Relay entry 59: people's cards, from site.json's people.
    bands: yes('Bands', 'The look’s bands under the cards.'),
  },
  variants: [
    { id: 'grid', label: 'Grid' },
    { id: 'featured', label: 'One featured' },
    { id: 'people', label: 'People: each person’s photo, role, name, bio, page, and accounts, in the site’s order' },
  ],
  component: 'project-cards/ProjectCards.astro',
  fixtures: [
    {
      type: 'project-cards',
      variant: 'grid',
      fields: {
        heading: 'More I Make',
        moreLink: { to: '/projects', label: 'Vellum & Volt and every project' },
        cards: [
          { name: 'Moondark', role: 'Creator', line: 'A web app that tells you when the Moon is void of course.', status: 'active', to: { to: '/projects/moondark' } },
          { name: 'alpacalunch', role: 'Founder', line: 'Tees and merch for rebels, ranters, and smartasses.', status: 'active', to: { to: '/projects/alpacalunch' } },
          { name: 'genXy', role: 'Co-founder', line: 'A generational-writing publication on Medium.', status: 'active', to: { to: '/projects/genxy' } },
          { name: 'Peptidings', role: 'Founder', line: 'Careful, unhyped writing on peptide science.', status: 'on hiatus', to: { to: '/projects/peptidings' } },
        ],
      },
    },
    // Relay entry 59: the site's people, with the look's bands under them.
    {
      type: 'project-cards',
      variant: 'people',
      fields: {
        heading: 'The People',
        cards: [{ name: 'Lawrence Winnerman', to: { to: '/writing', label: 'Stories by Lawrence' } }],
        bands: true,
      },
    },
  ],
};
