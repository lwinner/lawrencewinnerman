// The networks a link can name (relay entry 59), in the order a row of them takes, with each one's
// name. A site's own icon set (look.json's `icons`) draws each by its file, <network>.svg; Heliostet
// carries no network's glyph, so a site without the set draws each link's name instead.

export const NETWORKS = ['substack', 'medium', 'youtube', 'instagram', 'facebook', 'bluesky', 'threads', 'x', 'rss', 'tiktok', 'pinterest', 'linkedin', 'web', 'mail'] as const;
export type Network = (typeof NETWORKS)[number];

export const NETWORK_NAMES: Record<Network, string> = {
  substack: 'Substack', medium: 'Medium', youtube: 'YouTube', instagram: 'Instagram', facebook: 'Facebook', bluesky: 'Bluesky', threads: 'Threads',
  x: 'X', rss: 'RSS', tiktok: 'TikTok', pinterest: 'Pinterest', linkedin: 'LinkedIn', web: 'Website', mail: 'Email',
};

/** The inside of an SVG file, without its title or fills, for drawing inline in currentColor. */
export function glyphOf(svg: string): string {
  return svg
    .replace(/^[\s\S]*?<svg[^>]*>/, '')
    .replace(/<\/svg>\s*$/, '')
    .replace(/<title>[\s\S]*?<\/title>/, '')
    .replace(/\sfill="#[0-9A-Fa-f]{3,8}"/g, '');
}

/** A row of links, in the networks' order, each with its name. */
export function networkRow(links: { network: string; to: string }[]): { network: Network; to: string; name: string }[] {
  return NETWORKS.flatMap((n) => links.filter((l) => l.network === n).map((l) => ({ network: n, to: l.to, name: NETWORK_NAMES[n] })));
}
