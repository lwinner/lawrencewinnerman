// Chapter reader: a serialized chapter's opening, then on to the publication for the rest, with
// the chapters before and after and the series' index.
import { link, number, query, rich, text } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const chapterReader: PartDefinition = {
  type: 'chapter-reader',
  name: 'Chapter Reader',
  what: 'A serialized chapter’s opening, and the way on to the rest.',
  schema: {
    series: text('Series', 80, 'The series’ name: The Shattered World.', true),
    book: text('Book', 80, 'The book within the series: Book One · Light Shines Through.', true),
    number: number('Chapter number', 0, 999, 'The chapter’s number. Leave it empty for a prologue or an interstitial.'),
    title: text('Chapter title', 80, 'The chapter’s title: Sharon.', true),
    placeAndDate: text('Place and date', 160, 'The line that sets the scene, as published.'),
    opening: rich('Opening', 8000, 'The chapter’s first paragraphs, as published.', true),
    publication: text('Publication', 60, 'Where the rest is, by its short name: The Hinge.'),
    readOn: link('Read on', 'Where the full chapter is, and the words that invite readers there: Keep reading on The Hinge.', true),
    previous: link('Previous chapter', 'The chapter before, and its name. Optional.'),
    next: link('Next chapter', 'The chapter after, and its name. Optional.'),
    index: query('Series index', ['chapters'], ['series'], 99, 'The series’ chapters, listed beside the chapter.'),
  },
  variants: [],
  component: 'chapter-reader/ChapterReader.astro',
  fixtures: [
    {
      type: 'chapter-reader',
      fields: {
        series: 'The Shattered World',
        book: 'Book One · Light Shines Through',
        number: 4,
        title: 'Sharon',
        placeAndDate: 'October 2041 — Seattle, Tahoma, Free Republic of Cascadia',
        opening: 'Sharon is sitting at her desk, tapping out an idle rhythm with her pen while thumbing through a pile of daily briefs, purposefully ignoring the Eyes Only economic report sitting on the top of the stack.\n\nShe’s fairly sure she knows what it says — the economy is tanking, inflation isn’t under control, and after nearly twenty years of goosing the economy of Cascadia with every massive Keynesian public works project possible, the golden eggs have run dry.',
        publication: 'The Hinge',
        readOn: { to: 'https://lwinner.substack.com', label: 'Keep reading on The Hinge' },
        previous: { to: '/fiction/light-shines-through/interstitial', label: 'Interstitial' },
        next: { to: '/fiction/light-shines-through/chapter-5', label: 'Chapter 5: Jackie' },
        index: { source: 'chapters', filters: { series: 'The Shattered World' }, count: 99, sort: 'oldest' },
      },
    },
  ],
};
