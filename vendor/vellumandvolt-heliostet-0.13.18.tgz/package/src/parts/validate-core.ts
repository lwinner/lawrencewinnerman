// validatePart's core (relay entries 52 and 91, CMP-5), with nothing that needs Node, so the Cockpit's Worker can run it: one part checked against its type's fields. Each error names
// the part and the field and says what to fix in plain words, for the composer to show beside the
// field: "The third door needs somewhere to go," "This image needs a description." The same check
// runs in the composer and in the site's build. Checks across a whole page and site (links to pages
// that exist, unique addresses, locked pages) come with the page model (relay entry 54).

import type { Field, GroupField, QueryValue } from './fields.js';
import { PARTS, isPartType, variantOf } from './registry.js';
import type { Part, PartError } from './types.js';

const ORDINALS = ['first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth'];
const COUNTS = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'];
const count = (n: number) => COUNTS[n] ?? String(n);
const article = (word: string) => (/^[aeiou]/i.test(word) ? `an ${word}` : `a ${word}`);
const lower = (label: string) => label.charAt(0).toLowerCase() + label.slice(1);
const plural = (one: string, n: number) => (n === 1 ? one : `${one}s`);

/** What's being checked, as a sentence's subject: "This hello" or "The third door". */
interface Subject {
  words: string;
  /** In a group, the entry: messages about a link say where it goes rather than naming the field. */
  inGroup: boolean;
}

/** Whether a required rich-text field says nothing once drawn. The site's build sets the real test (validate.ts:
 *  its Markdown and the one sanitizer, decision 0004); a runtime without the sanitizer, the Cockpit's Worker (relay
 *  entry 91), uses this one or sets its own, so the core imports nothing that needs Node. */
let richEmpty = (v: string): boolean => !v.replace(/<[^>]*>/g, '').replace(/[\s#*_`>~|\-\[\]()!]/g, '');
export function setRichEmpty(test: (v: string) => boolean): void { richEmpty = test; }

const missing = (v: unknown) => v === undefined || v === null || (typeof v === 'string' && !v.trim()) || (Array.isArray(v) && v.length === 0);

/** A page on the site ("/work"), a place on the same page ("#compare"), a web address, or an email address. */
export function goodAddress(to: string): boolean {
  return /^\/(?!\/)\S*$/.test(to) || /^#[\w-]+$/.test(to) || /^https?:\/\/[^\s/]+\.[^\s]+$/.test(to) || /^mailto:[^\s@]+@[^\s@]+$/.test(to);
}

function checkField(value: unknown, field: Field, subject: Subject): string[] {
  const name = lower(field.label);
  if (missing(value) || (field.kind === 'yes' && field.required && value !== true)) {
    if (!field.required && field.kind !== 'group') return [];
    switch (field.kind) {
      case 'link':
        return [subject.inGroup ? `${subject.words} needs somewhere to go.` : `${subject.words} needs ${article(name)} address.`];
      case 'yes':
        return [`${subject.words} needs ${name}. Tick it once it’s given.`];
      case 'group': {
        if (field.min === 0) return [];
        return [`${subject.words} needs at least ${count(field.min)} ${plural(field.one, field.min)}.`];
      }
      case 'query':
        return [`${subject.words} needs to know what to list.`];
      case 'image':
        return [`${subject.words} needs ${article(name)}.`];
      default:
        return [`${subject.words} needs ${article(name)}.`];
    }
  }

  switch (field.kind) {
    case 'text':
      if (typeof value !== 'string') return [`The ${name} should be words.`];
      return value.length > field.max ? [`The ${name} is ${value.length - field.max} ${value.length - field.max === 1 ? 'character' : 'characters'} too long; it can be ${field.max}.`] : [];
    case 'rich': {
      if (typeof value !== 'string') return [`The ${name} should be words.`];
      if (value.length > field.max) return [`The ${name} is ${value.length - field.max} ${value.length - field.max === 1 ? 'character' : 'characters'} too long; it can be ${field.max}.`];
      return field.required && richEmpty(value) ? [`${subject.words} needs ${article(name)}.`] : [];
    }
    case 'link': {
      const v = value as { to?: unknown; label?: unknown } | string;
      const to = typeof v === 'string' ? v : v.to;
      if (typeof to !== 'string' || !goodAddress(to)) return [subject.inGroup ? `${subject.words} doesn’t go to a page on the site or a web address.` : `“${field.label}” isn’t a page on the site or a web address.`];
      if (typeof v === 'object' && v.label !== undefined && (typeof v.label !== 'string' || v.label.length > 60)) return [`The words on the ${name} can be 60 characters.`];
      return [];
    }
    case 'image': {
      const v = value as { src?: unknown; alt?: unknown };
      if (typeof v !== 'object' || typeof v.src !== 'string' || !(/^\/(?!\/)/.test(v.src) || /^https:\/\//.test(v.src))) return [`The ${name} needs its file.`];
      return typeof v.alt !== 'string' || !v.alt.trim() ? [`This ${name} needs a description.`] : [];
    }
    case 'file': {
      const v = value as { src?: unknown; label?: unknown };
      if (typeof v !== 'object' || typeof v.src !== 'string') return [`The ${name} needs its file.`];
      const ext = /\.([a-z0-9]+)$/i.exec(v.src)?.[1]?.toLowerCase() ?? '';
      if (!field.types.includes(ext)) return [`The ${name} should be ${field.types.map((t) => t.toUpperCase()).join(' or ')}.`];
      return typeof v.label !== 'string' || !v.label.trim() ? [`The ${name} needs a name to show.`] : [];
    }
    case 'choice':
      return field.options.some((o) => o.value === value) ? [] : [`The ${name} should be one of: ${field.options.map((o) => o.label).join(', ')}.`];
    case 'number':
      return typeof value === 'number' && Number.isInteger(value) && value >= field.min && value <= field.max ? [] : [`The ${name} should be a whole number from ${field.min} to ${field.max}.`];
    case 'date':
      return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value)) ? [] : [`The ${name} should be a day, such as 2026-10-23.`];
    case 'yes':
      return typeof value === 'boolean' ? [] : [`The ${name} should be ticked or not.`];
    case 'list': {
      if (!Array.isArray(value) || value.some((v) => typeof v !== 'string')) return [`The ${name} should be a list of words.`];
      if (value.length < field.min) return [`${subject.words} needs at least ${count(field.min)} ${name}.`];
      if (value.length > field.max) return [`The ${name} can be ${count(field.max)} at most.`];
      const long = value.findIndex((v: string) => v.length > field.each);
      if (long >= 0) return [`The ${ORDINALS[long] ?? `number ${long + 1}`} of the ${name} is too long; each can be ${field.each} characters.`];
      return value.some((v: string) => !v.trim()) ? [`One of the ${name} is empty.`] : [];
    }
    case 'query': {
      const q = value as Partial<QueryValue>;
      if (typeof q !== 'object' || !q.source || !field.sources.includes(q.source)) return [`The ${name} should list ${field.sources.join(', ')}.`];
      if (typeof q.count !== 'number' || !Number.isInteger(q.count) || q.count < 1 || q.count > field.maxCount) return [`The ${name} can show 1 to ${field.maxCount} items.`];
      if (!['newest', 'oldest', 'order'].includes(q.sort ?? '')) return [`The ${name} should be newest first, oldest first, or in order.`];
      if (q.skip !== undefined && (typeof q.skip !== 'number' || !Number.isInteger(q.skip) || q.skip < 0 || q.skip > field.maxCount)) return [`The ${name} can pass over 0 to ${field.maxCount} items first.`];
      const bad = Object.keys(q.filters ?? {}).find((k) => !(field.filters as readonly string[]).includes(k));
      return bad ? [`The ${name} can’t be filtered by ${bad}.`] : [];
    }
    case 'group':
      return [];
  }
}

function checkGroup(value: unknown, field: GroupField, key: string, partName: string, subject: Subject): PartError[] {
  if (!Array.isArray(value)) return [{ part: partName, field: key, message: `The ${lower(field.label)} should be a list.` }];
  const errors: PartError[] = [];
  if (value.length < field.min) errors.push({ part: partName, field: key, message: `${subject.words} needs at least ${count(field.min)} ${plural(field.one, field.min)}.` });
  if (value.length > field.max) errors.push({ part: partName, field: key, message: `${subject.words} can have ${count(field.max)} ${plural(field.one, field.max)} at most.` });
  value.forEach((entry, i) => {
    const words = `The ${ORDINALS[i] ?? `number ${i + 1}`} ${field.one}`;
    const item = typeof entry === 'object' && entry !== null ? (entry as Record<string, unknown>) : {};
    for (const [name, inner] of Object.entries(field.fields)) {
      for (const message of checkField(item[name], inner, { words, inGroup: true })) errors.push({ part: partName, field: `${key}.${i}.${name}`, message });
    }
  });
  return errors;
}

/**
 * Every problem with one part, or none. `own` names the site's own variants (decision 0019), as
 * "type:variant"; a part in one of them is checked against its type's fields like any other, but not
 * against the rules across fields, which say how Heliostet's own variants draw it.
 */
export function validatePart(part: Part, own: ReadonlySet<string> = new Set()): PartError[] {
  const partName = part.id ?? part.type;
  if (!isPartType(part.type)) return [{ part: partName, field: 'type', message: `There’s no part called “${part.type}.”` }];
  const def = PARTS[part.type];
  const errors: PartError[] = [];
  if (part.variant !== undefined && !def.variants.some((v) => v.id === part.variant) && !own.has(`${part.type}:${part.variant}`)) {
    errors.push({ part: partName, field: 'variant', message: def.variants.length ? `The ${def.name} part comes as ${def.variants.map((v) => v.label).join(', ')}.` : `The ${def.name} part has one form only.` });
  }
  const fields = part.fields ?? {};
  const subject: Subject = { words: `This ${lower(def.name)} part`, inGroup: false };
  for (const [key, field] of Object.entries(def.schema)) {
    const value = fields[key];
    if (field.kind === 'group' && !missing(value)) errors.push(...checkGroup(value, field, key, partName, subject));
    else for (const message of checkField(value, field, subject)) errors.push({ part: partName, field: key, message });
  }
  for (const key of Object.keys(fields)) {
    if (!(key in def.schema)) errors.push({ part: partName, field: key, message: `The ${def.name} part has no field called “${key}.”` });
  }
  // A rule across fields says how Heliostet's own variants read them; a site's own variant reads them its own way.
  const isOwn = part.variant !== undefined && own.has(`${part.type}:${part.variant}`);
  for (const e of isOwn ? [] : (def.check?.(fields, variantOf(def, part.variant)) ?? [])) {
    if (!errors.some((x) => x.field === e.field)) errors.push({ part: partName, ...e });
  }
  return errors;
}
