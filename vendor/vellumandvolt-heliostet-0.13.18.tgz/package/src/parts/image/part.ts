// Image: one picture, with its description, a caption, and a credit.
import { image, text } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const imagePart: PartDefinition = {
  type: 'image',
  name: 'Image',
  what: 'One picture.',
  schema: {
    image: image('Image', 'The picture, and a description of it for people who can’t see it.', true),
    caption: text('Caption', 300, 'A line under the picture. Optional.'),
    credit: text('Credit', 120, 'Who made it. Optional.'),
  },
  variants: [
    { id: 'column', label: 'Column' },
    { id: 'wide', label: 'Wide' },
    { id: 'full', label: 'Full' },
  ],
  component: 'image/Image.astro',
  fixtures: [
    {
      type: 'image',
      variant: 'column',
      fields: {
        image: { src: '/gallery/world-war-three-started.jpg', alt: 'A quiz card asking when World War III began, with every answer checked' },
        caption: 'From “World War Three Is Here. We’re Still Arguing About the Start Date.”',
      },
    },
  ],
};
