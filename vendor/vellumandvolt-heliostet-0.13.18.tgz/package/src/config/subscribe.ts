// FMT-6: the subscribe destinations, in the client's order. The list drives the masthead's
// Subscribe button (the first entry), the subscribe page, and /links. With no list on the
// record, it is built from the sources: Substack, then YouTube, then the site's own feed, so a
// YouTube-only site offers YouTube and RSS and no Substack. The site's feed is always present,
// except on a site with no archive yet and no list, such as a company site, which offers nothing
// to subscribe to until a source is added (relay entry 25).

import type { ClientRecord, DESTINATIONS } from './schema.js';

export interface Destination {
  kind: (typeof DESTINATIONS)[number];
  label: string;
  url: string;
}

export const FEED_PATH = '/feed.xml';

const LABELS: Record<Destination['kind'], string> = {
  substack: 'Subscribe on Substack',
  youtube: 'Subscribe on YouTube',
  'apple-podcasts': 'Apple Podcasts',
  spotify: 'Spotify',
  rss: 'RSS feed',
  other: 'Subscribe',
};

/** The masthead's Subscribe button: the first place in the client's order (FMT-6), as the channels editor says
 *  (Cowork's Gauntlet notes on Entry 103, Major 3). The feed's XML is no page for a reader, so a list led by RSS
 *  opens the subscribe page instead. None when there's nowhere to subscribe. */
export function mastheadSubscribe(record: ClientRecord): { label: string; href: string } | null {
  const first = destinations(record)[0];
  if (!first) return null;
  return { label: 'Subscribe', href: first.kind === 'rss' ? '/subscribe' : first.url };
}

export function destinations(record: ClientRecord): Destination[] {
  const { substack, youtube, medium, podcast } = record.sources;
  const archive = Boolean(substack || youtube || medium || podcast || record.doors.formEditor || record.doors.connector);
  if (!archive && !record.subscribe) return [];
  const listed = record.subscribe ?? [
    ...(record.sources.substack ? [{ kind: 'substack' as const }] : []),
    ...(record.sources.youtube ? [{ kind: 'youtube' as const }] : []),
  ];
  const out = listed.map((d): Destination => {
    const url =
      d.url ??
      (d.kind === 'substack' ? record.sources.substack?.url : d.kind === 'youtube' ? record.sources.youtube?.channel : d.kind === 'rss' ? FEED_PATH : undefined);
    // The schema has already refused a destination with no address to fall back on.
    return { kind: d.kind, label: d.label ?? LABELS[d.kind], url: url ?? FEED_PATH };
  });
  if (!out.some((d) => d.kind === 'rss')) out.push({ kind: 'rss', label: LABELS.rss, url: FEED_PATH });
  return out;
}
