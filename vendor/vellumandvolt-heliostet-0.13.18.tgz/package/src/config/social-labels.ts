// Each social network's name, as a site shows it in its footer and its links (relay entry 91: shared with the Page
// Builder's preview, so the preview names them as the build does).
export const SOCIAL_LABELS: Record<string, string> = {
  bluesky: 'Bluesky',
  facebook: 'Facebook',
  instagram: 'Instagram',
  linkedin: 'LinkedIn',
  threads: 'Threads',
  tiktok: 'TikTok',
  x: 'X',
  mastodon: 'Mastodon',
  discord: 'Discord',
};
