// PAGE-7, FMT-9: top-level pages. Each is one Markdown file at src/content/pages/<slug>.md, so a
// door that writes a page writes one file and never touches client.json. Its frontmatter
// carries the title, the navigation label, the order, and the template; the navigation is
// built from these files (order, then the six-and-More rule in site.ts).

import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { parse } from 'yaml';
import { z } from 'zod';

export const PAGES_DIR = 'src/content/pages/';
// 'own': the site renders the page itself at src/pages/<slug>.astro; the file gives it its place in
// the navigation and nothing else (relay entry 25).
export const TEMPLATES = ['prose', 'services', 'press-kit', 'book', 'clips', 'contact', 'own'] as const;
/** Where a page is linked from: the navigation (the default), the footer, or nowhere (relay entry 25). */
export const PLACES = ['nav', 'footer', 'none'] as const;

const link = z.string().regex(/^(?:https:\/\/|mailto:|\/)/, 'must be an https://, mailto:, or site-relative address');

const frontmatter = z.strictObject({
  title: z.string().trim().min(1).max(120),
  /** The navigation label, in the client's words and sentence case. */
  navLabel: z.string().trim().min(1).max(32),
  order: z.int().min(0),
  template: z.string().regex(/^[a-z-]+$/).default('prose'),
  /** A draft is built on its drafts branch only, and never in the navigation (FORM-3). */
  draft: z.boolean().default(false),
  place: z.enum(PLACES).default('nav'),
  /** Kept out of search engines and the sitemap. */
  noindex: z.boolean().default(false),
  /** The closing line that the page is written by the site's person and not mirrored; off for a company's legal pages. */
  byline: z.boolean().default(true),
  /** The line beneath the title. */
  dek: z.string().trim().min(1).max(300).optional(),
  /** Services: the offers, each a title and a line, and the one call to action (PAGE-7). */
  offers: z.array(z.strictObject({ title: z.string().trim().min(1), text: z.string().trim().min(1) })).optional(),
  action: z.strictObject({ label: z.string().trim().min(1).max(40), href: link }).optional(),
  /** Contact: the address the page offers, as a mailto. */
  email: z.email().optional(),
  /** Book (FMT-9): the book's facts, its retailers in order, and up to three reviews. */
  book: z
    .strictObject({
      cover: z.string().optional(),
      subtitle: z.string().optional(),
      publisher: z.string().optional(),
      published: z.string().optional(),
      isbn: z.string().regex(/^[\d-]{10,17}X?$/).optional(),
      retailers: z.array(z.strictObject({ label: z.string().trim().min(1), href: link })).max(8).default([]),
      reviews: z.array(z.strictObject({ quote: z.string().trim().min(1), by: z.string().trim().min(1) })).max(3).default([]),
    })
    .optional(),
  /** Clips (FMT-9): a dated list of bylines elsewhere; never another outlet's text. */
  clips: z
    .array(z.strictObject({ date: z.iso.date(), outlet: z.string().trim().min(1), headline: z.string().trim().min(1), url: link, kind: z.string().optional() }))
    .optional(),
});

export type PageFields = Omit<z.output<typeof frontmatter>, 'title' | 'navLabel' | 'order' | 'template' | 'draft' | 'place'>;

export interface Page {
  slug: string;
  title: string;
  navLabel: string;
  order: number;
  template: (typeof TEMPLATES)[number];
  draft: boolean;
  place: (typeof PLACES)[number];
  /** The Markdown after the frontmatter. */
  body: string;
  /** The template's own fields from the frontmatter. */
  fields: PageFields;
}

export class PageError extends Error {
  override name = 'PageError';
}

const SLUG = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

/** Splits a Markdown file into its frontmatter and body. */
export function splitFrontmatter(text: string): { data: unknown; body: string } | null {
  const match = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/.exec(text);
  return match ? { data: parse(match[1] ?? '') ?? {}, body: match[2] ?? '' } : null;
}

/** Reads every page under src/content/pages/ in the site at `root`, in navigation order. */
export function loadPages(root: URL, warn: (message: string) => void = () => {}): Page[] {
  const dir = new URL(PAGES_DIR, root);
  if (!existsSync(dir)) return [];
  const pages: Page[] = [];
  for (const name of readdirSync(dir).filter((f) => f.endsWith('.md')).sort()) {
    const where = `${PAGES_DIR}${name}`;
    const slug = name.slice(0, -3);
    if (!SLUG.test(slug)) throw new PageError(`${where}: the file name must be a slug of lowercase letters, digits, and single hyphens.`);
    let split;
    try {
      split = splitFrontmatter(readFileSync(new URL(name, dir), 'utf8'));
    } catch (error) {
      throw new PageError(`${where}: the frontmatter is not valid YAML: ${(error as Error).message}`);
    }
    if (!split) throw new PageError(`${where}: the page has no frontmatter.`);
    const result = frontmatter.safeParse(split.data);
    if (!result.success) {
      const lines = result.error.issues.map((i) => `  ${i.path.join('.') || '(frontmatter)'}: ${i.message}`);
      throw new PageError(`${where} fails the page frontmatter:\n${lines.join('\n')}`);
    }
    const { template, title, navLabel, order, draft, place, ...fields } = result.data;
    const known = (TEMPLATES as readonly string[]).includes(template);
    // An unknown template is never a failed build (mockup 29).
    if (!known) warn(`${where}: the template "${template}" is not one Heliostet knows, so the page uses Prose.`);
    pages.push({ slug, title, navLabel, order, draft, place, template: known ? (template as Page['template']) : 'prose', body: split.body, fields });
  }
  return pages.sort((a, b) => a.order - b.order || a.slug.localeCompare(b.slug));
}
