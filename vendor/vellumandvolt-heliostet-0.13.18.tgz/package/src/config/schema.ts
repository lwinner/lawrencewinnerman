// The client record (FND-1, OPS-7): every setting the BRD says is "recorded", as one zod schema.
// Its JSON mirror is `client.json` at the root of each client repository, and Heliostet builds
// the site from it. The operator's D1 copy holds the same record plus the Confidential fields
// that never enter a repository (SEC-12): principals' sign-in addresses and the sign-in log
// (SEC-3). Those have no field here, and every object is strict, so a record that carries one
// fails the build.
//
// Fields that only happen later (kickoff, terms, flip tests) are optional: the intake form
// creates the record (MKT-5) before any of them exist, and the fleet flags what is missing.

import { z } from 'zod';
import { cleanupSchema } from '../adapters/substack.js';
import { BESPOKE_OVERLAY, HOUSE_LOOKS } from '../build/house-looks.js';
import { ITEM_SOURCES } from '../build/item.js';
import { HEROES, UNITS } from './vocabulary.js';

const date = z.iso.date({ error: 'must be a date written YYYY-MM-DD' });
const https = z.url({ protocol: /^https$/, hostname: z.regexes.domain, error: 'must be an https:// address' });
const slug = z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, 'must be lowercase letters, digits, and single hyphens');
/** A path inside the client repository, never absolute and never climbing out of it. */
const repoPath = z.string().regex(/^(?!\/)(?!.*(?:^|\/)\.\.(?:\/|$))[\w./-]+$/, 'must be a path inside the repository');
const label = (max: number) => z.string().trim().min(1).max(max);
const allowBlock = z.enum(['allow', 'block']);

/** A source item's identifier, `<source>:<id>`; visibility, clips, and joins are keyed by it (ADM-6, ADM-7). */
const itemKey = z
  .string()
  .regex(new RegExp(`^(?:${ITEM_SOURCES.join('|')}):\\S+$`), `must be <source>:<id>, with the source one of ${ITEM_SOURCES.join(', ')}`);

const heliostet = z.strictObject({
  /** Heliostet version this repository pins (FND-1, FND-2, ADM-5). */
  version: z.string().regex(/^\d+\.\d+\.\d+(?:-[\w.]+)?$/, 'must be a version such as 1.4.0'),
  /** The SHA-256 of vendor/vellumandvolt-heliostet-<version>.tgz, which heliostet-new-site records (Step 11). */
  sha256: z.string().regex(/^[0-9a-f]{64}$/, 'must be a SHA-256 in lowercase hex').optional(),
  /** Each Heliostet-managed file's SHA-256 as Heliostet last wrote it, so heliostet-upgrade can tell a changed one (Step 12). */
  managed: z.record(z.string(), z.string().regex(/^[0-9a-f]{64}$/)).optional(),
});

const identity = z.strictObject({
  /** The site's name as the masthead shows it. */
  name: label(80),
  /** The owned domain, without a scheme; canonicals are built on it (ENT-3). */
  domain: z.string().regex(z.regexes.domain, 'must be a domain such as example.com'),
  /** What the site is the home of (ENT-1, PRIN-4, FMT-5): a person, a collective, or a show. */
  brand: z.enum(['person', 'organization', 'show']).default('person'),
  /** The creator's time zone, for dates and show times on the site. */
  timeZone: z
    .string()
    .refine((zone) => {
      try {
        new Intl.DateTimeFormat('en-US', { timeZone: zone });
        return true;
      } catch {
        return false;
      }
    }, 'must be a time zone such as America/New_York')
    .default('UTC'),
  /** The masthead switch (FMT-5). */
  masthead: z.enum(['wordmark', 'photo', 'both']).default('wordmark'),
  /** The logo, copied into the repository by heliostet-match and never hotlinked (DS-5). */
  /**
   * An organization's public facts (ENT-1), for a site whose brand is an organization: the legal
   * entity that operates it, where it is, and which principals founded it (relay entries 25 and 25b).
   */
  organization: z
    .strictObject({
      legalName: label(120).optional(),
      locality: label(80).optional(),
      region: label(80).optional(),
      country: z.string().regex(/^[A-Z]{2}$/, 'must be a two-letter country code such as US').optional(),
      founders: z.array(slug).default([]),
    })
    .optional(),
  logo: z
    .strictObject({
      file: repoPath.regex(/^public\//, 'must be under public/'),
      width: z.int().positive(),
      height: z.int().positive(),
      source: https,
      copied: date,
    })
    .optional(),
});

const sources = z
  .strictObject({
    substack: z
      .strictObject({
        url: https,
        /** How the import cleans each post (relay entry 55): Heliostet's rules, or the Press's. */
        cleanup: cleanupSchema.optional(),
        /**
         * Read the publication's feed at build and add any post not yet imported, so a new post is on
         * the site before the import commits it (relay entry 55). Off by default: a site builds from its files.
         */
        liveFeed: z.boolean().default(false),
      })
      .optional(), // SITE-1, SITE-4, SITE-5, NOTE-1
    youtube: z.strictObject({ channel: https }).optional(), // SITE-2, FMT-4
    medium: z.strictObject({ url: https }).optional(), // SITE-3
    podcast: z.strictObject({ feed: https }).optional(), // FMT-2
  })
  .default({});

const principal = z.strictObject({
  id: slug,
  name: label(80),
  /** Byline spellings the feeds use, for the host page's archive (PRIN-1). */
  aliases: z.array(label(80)).default([]),
  /** Three lengths (FMT-5): short is about 50 words and is the entity's description (ENT-1). */
  bio: z
    .strictObject({ short: z.string().trim().min(1), medium: z.string().trim().min(1).optional(), long: z.string().trim().min(1).optional() })
    .optional(),
  /** The headshot at two sizes (FMT-5). */
  headshot: z.strictObject({ large: repoPath, small: repoPath, alt: label(200) }).optional(),
  /** The Wikidata item (ENT-2, PRIN-2). */
  wikidata: z.string().regex(/^Q[1-9]\d*$/, 'must be a Wikidata QID such as Q42').optional(),
  sameAs: z.array(https).default([]), // ENT-1
  knowsAbout: z.array(label(80)).default([]), // ENT-1
  location: label(80).optional(),
  pronunciation: label(80).optional(),
  /**
   * The person's entity home on their own site: their Person's @id there, such as
   * https://example.com/about#name. The site refers to it and never repeats the person, and builds
   * no host page for them (relay entry 25).
   */
  entityHome: https.optional(),
});

const show = z.strictObject({
  name: label(80),
  /** The schema type the show entity carries (FMT-5): PodcastSeries, or a video series. */
  kind: z.enum(['podcast', 'video']),
  /** Principal ids, linked to the show entity (FMT-5). */
  hosts: z.array(slug).min(1),
});

const plan = z.strictObject({
  edition: z.enum(['mirror', 'editor', 'connector']),
  /** Heliostet Plus: the Authority Report on Editor or Connector (section 4). */
  plus: z.boolean().default(false),
  addOns: z
    .strictObject({
      show: z.boolean().default(false), // SHOW-1 to SHOW-6
      bespoke: z.boolean().default(false), // DS-2
      conciergeSetup: z.boolean().default(false), // ONB-1
      import: z.boolean().default(false), // FMT-7
    })
    .default({ show: false, bespoke: false, conciergeSetup: false, import: false }),
  /** The Social Desk package, by its monthly price in dollars (DESK-1). */
  socialDesk: z.union([z.literal(2500), z.literal(3500), z.literal(5500)]).optional(),
  /** Concierge documents a month (CON-1); Heliostet fills the edition's number when it is left out. */
  allowances: z.strictObject({ conciergeDocuments: z.int().min(0).max(10) }).optional(),
  /** The audit credit toward a build (AUD-4). */
  credits: z.array(z.strictObject({ kind: z.literal('audit'), amount: z.int().positive(), granted: date, expires: date })).default([]),
  /** The per-tier hours budget and its ninety-day review (FIN-4). */
  hoursBudget: z.strictObject({ hoursPerMonth: z.number().positive(), review: date }).optional(),
});

const doors = z
  .strictObject({
    formEditor: z.boolean().default(false), // FORM-1, Editor and up
    connector: z.boolean().default(false), // MCP-1, Connector
    concierge: z.boolean().default(false), // CON-1, Editor and up
  })
  .default({ formEditor: false, connector: false, concierge: false });

const connector = z.strictObject({
  /** What the publishing desk writes to (MCP-1, MCP-7). */
  adapter: z.enum(['heliostet', 'ghost', 'wordpress']).default('heliostet'),
  voiceFile: repoPath.optional(),
});

const merch = z
  .strictObject({
    /** The client's existing store, read for featured products and linked out to (MER-1). */
    store: z.strictObject({ kind: z.enum(['shopify', 'printful', 'etsy']), url: https }).optional(),
    /** Its stores by name, which a merch part names (relay entry 53); Shopify's product list first. */
    stores: z.array(z.strictObject({ name: z.string().trim().min(1).max(60), url: https, kind: z.enum(['shopify']) })).min(1).optional(),
  })
  .refine((m) => m.store || m.stores, { message: 'Merch needs a store: its kind and address, or a list of named stores.' });

const narrareach = z.strictObject({
  /** Set up at onboarding on every edition (section 10); the account is the client's. */
  connected: z.boolean(),
  workspace: label(80).optional(),
  setUp: date.optional(),
});

const crawlers = z.strictObject({
  /** The client's stated choice for training bots (ENT-6). Answer bots are always allowed. */
  training: allowBlock,
  /** No llms.txt unless the client asks (ENT-7). */
  llmsTxt: z.boolean().default(false),
  /** Cloudflare's Search, Training, and Agent switches as set at onboarding (ENT-6). */
  cloudflare: z.strictObject({ search: allowBlock, training: allowBlock, agent: allowBlock, checked: date }).optional(),
});

const look = z
  .discriminatedUnion('kind', [
    // Match (DS-4): the Substack defaults to sources.substack; the overlay to looks/match.json.
    z.strictObject({ kind: z.literal('match'), substack: https.optional(), overlay: repoPath.optional() }),
    // A house look (Step 9): the Sample Show, the Press, and the fallback. Never named in public.
    z.strictObject({ kind: z.literal('house'), name: z.enum(HOUSE_LOOKS) }),
    // Bespoke: an overlay in the client's repository, started from a house look by heliostet-look new.
    z.strictObject({ kind: z.literal('bespoke'), overlay: repoPath.default(BESPOKE_OVERLAY), bespokeFrom: z.enum(HOUSE_LOOKS).optional() }),
    // Vellum & Volt's own brand, unchanged (DS-1): only on a site the operator owns, never sold.
    z.strictObject({ kind: z.literal('brand') }),
  ])
  .default({ kind: 'match' });

const unit = z.union([
  z.enum(UNITS),
  z.strictObject({
    singular: label(24),
    plural: label(24),
    slug,
    /** Whether the word names writing (a Watch item sits beside it) or episodes (videos are the unit). */
    basis: z.enum(['writing', 'episode']),
  }),
]);

const vocabulary = z
  .strictObject({ unit: unit.default('story'), hero: z.enum(HEROES).default('latest-writing') }) // FMT-1
  .default({ unit: 'story', hero: 'latest-writing' });

export const DESTINATIONS = ['substack', 'youtube', 'apple-podcasts', 'spotify', 'rss', 'other'] as const;
// FMT-6: in order; the first is where the masthead's Subscribe button goes. Substack and YouTube
// default to the sources' addresses; RSS is the site's own feed and takes no address.
const destination = z.strictObject({ kind: z.enum(DESTINATIONS), url: https.optional(), label: label(40).optional() });

export const SOCIAL_PLATFORMS = ['bluesky', 'facebook', 'instagram', 'linkedin', 'threads', 'tiktok', 'x', 'mastodon', 'discord', 'other'] as const;
const social = z.strictObject({ platform: z.enum(SOCIAL_PLATFORMS), url: https, label: label(40).optional() }); // PAGE-1

const support = z.strictObject({
  url: https, // PAGE-8: any donation address
  label: label(24).default('Support my work'),
});

const join = z.discriminatedUnion('verb', [
  // ADM-7, Same thing: one piece in more than one place; the canonical item renders.
  z.strictObject({
    verb: z.literal('same-thing'),
    canonical: itemKey,
    items: z.array(z.strictObject({ item: itemKey, role: z.enum(['copy', 'version']).optional() })).min(1),
    /** Made by the automatic episode match (FMT-2), which the client can undo. */
    automatic: z.boolean().default(false),
  }),
  // ADM-7, Goes with: distinct items on one page; the lead supplies the title, URL, and schema.
  z.strictObject({ verb: z.literal('goes-with'), lead: itemKey, companion: itemKey }),
]);

const sponsorSlot = z.strictObject({ name: label(80), url: https, label: z.enum(['Presented by', 'Sponsored', 'Supported by']) });

const flip = z
  .strictObject({
    on: z.boolean().default(false), // FLIP-1; operator-only (SEC-14)
    switched: date.optional(),
    tests: z.array(z.strictObject({ date, result: z.enum(['pass', 'fail']) })).default([]), // FLIP-2
    nextTest: date.optional(),
  })
  .default({ on: false, tests: [] });

const onboarding = z.strictObject({
  path: z.enum(['self-serve', 'concierge']), // ONB-1
  intake: date.optional(),
  audit: date.optional(),
  kickoff: date.optional(), // OPS-4
  /** Concierge setup (ONB-1, DOOR-1): the call, the client's consent, and the dated exit. */
  concierge: z.strictObject({ consent: date, setupCall: date, exitCall: date.optional() }).optional(),
  approved: date.optional(), // section 9, Review
  launched: date.optional(),
  /** The thirty-day cadence (section 9, OPS-4). */
  cadence: z
    .strictObject({ twoWeekCheck: date.optional(), firstMonthlyReport: date.optional(), firstFlipTest: date.optional() })
    .optional(),
  /** ENT-8: both properties verified and the domain added to the fleet monitor. */
  registrations: z
    .strictObject({ googleSearchConsole: date.optional(), bingWebmaster: date.optional(), fleetMonitor: date.optional() })
    .optional(),
  /** ENT-9: the client's other surfaces link here. */
  crossLinks: z
    .strictObject({ substackAbout: date.optional(), youtubeDescription: date.optional(), linkInBio: date.optional() })
    .optional(),
  ownerGuide: date.optional(), // FORM-4
});

/**
 * Measurement beyond Level 1 (MEAS-1, BRD 6.19). Every Level 2 or 3 tool loads only through the
 * client's own Cloudflare Zaraz, never as script in Heliostet’s pages (MEAS-2); the record names
 * each tool and its public ID, which is public by design. It never holds a secret: an API secret,
 * an access token, or a Measurement Protocol secret is refused by name (SEC rules).
 */
export const LEVEL_2_TOOLS = ['plausible', 'fathom'] as const;
export const LEVEL_3_TOOLS = ['ga4', 'google-ads', 'meta-pixel', 'tiktok', 'pinterest', 'linkedin-insight', 'microsoft-clarity'] as const;
const MEASUREMENT_TOOLS = [...LEVEL_2_TOOLS, ...LEVEL_3_TOOLS] as const;
type MeasurementTool = (typeof MEASUREMENT_TOOLS)[number];

/** Each tool's public ID, loosely: tight enough to catch a pasted secret, loose enough for real IDs. */
const TOOL_ID: Record<MeasurementTool, { pattern: RegExp; says: string }> = {
  plausible: { pattern: /^(?=.{3,253}$)[a-z0-9-]+(\.[a-z0-9-]+)+$/, says: 'the site’s domain as Plausible names it' },
  fathom: { pattern: /^[A-Z]{5,12}$/, says: 'a Fathom site ID: capital letters' },
  ga4: { pattern: /^G-[A-Z0-9]{4,16}$/, says: 'a GA4 measurement ID: G- and letters or digits' },
  'google-ads': { pattern: /^AW-\d{6,14}$/, says: 'a Google Ads tag ID: AW- and digits' },
  'meta-pixel': { pattern: /^\d{10,20}$/, says: 'a Meta pixel ID: digits' },
  tiktok: { pattern: /^[A-Z0-9]{10,30}$/, says: 'a TikTok pixel ID: capital letters and digits' },
  pinterest: { pattern: /^\d{8,16}$/, says: 'a Pinterest tag ID: digits' },
  'linkedin-insight': { pattern: /^\d{4,12}$/, says: 'a LinkedIn partner ID: digits' },
  'microsoft-clarity': { pattern: /^[a-z0-9]{6,16}$/, says: 'a Clarity project ID: lowercase letters and digits' },
};

/** Shapes of secrets that never belong in the record, checked before any ID's own format. */
export const SECRET_SHAPES: { pattern: RegExp; is: string }[] = [
  { pattern: /-----BEGIN [A-Z ]*PRIVATE KEY/, is: 'a private key' },
  { pattern: /^EAA[A-Za-z0-9]{20,}/, is: 'a Meta access token' },
  { pattern: /^ya29\./, is: 'a Google OAuth access token' },
  { pattern: /^1\/\/[0-9A-Za-z_-]{20,}/, is: 'a Google OAuth refresh token' },
  { pattern: /^AIza[0-9A-Za-z_-]{30,}/, is: 'a Google API key' },
  { pattern: /^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\./, is: 'a signed token (JWT)' },
  { pattern: /^(sk|rk)_(live|test)_/, is: 'a Stripe secret key' },
  { pattern: /^sk-/, is: 'an API secret key' },
  { pattern: /^(gh[opsu]_|github_pat_)/, is: 'a GitHub token' },
  { pattern: /^xox[abpr]-/, is: 'a Slack token' },
  { pattern: /^act\.[A-Za-z0-9]{20,}/, is: 'a TikTok access token' },
  { pattern: /^[a-f0-9]{32,}$/, is: 'a long hexadecimal token' },
  // A GA4 Measurement Protocol secret, and most API tokens: long, with both cases mixed in. No
  // supported tool's public ID mixes cases.
  { pattern: /^(?=[A-Za-z0-9_-]*[a-z])(?=[A-Za-z0-9_-]*[A-Z])[A-Za-z0-9_-]{20,}$/, is: 'a secret or token (long, mixed case)' },
];

const measurement = z
  .strictObject({
    level: z.union([z.literal(1), z.literal(2), z.literal(3)]).default(1),
    tools: z.array(z.strictObject({ tool: z.enum(MEASUREMENT_TOOLS), id: z.string().trim().min(1).max(253) })).default([]),
  })
  .superRefine((m, ctx) => {
    m.tools.forEach((t, i) => {
      const secret = SECRET_SHAPES.find((s) => s.pattern.test(t.id));
      if (secret) {
        ctx.addIssue({ code: 'custom', path: ['tools', i, 'id'], message: `looks like ${secret.is}; the record holds only a tool's public ID, never a secret (MEAS-1)` });
        return;
      }
      const shape = TOOL_ID[t.tool];
      if (!shape.pattern.test(t.id)) ctx.addIssue({ code: 'custom', path: ['tools', i, 'id'], message: `must be ${shape.says}` });
      if (m.level === 1) ctx.addIssue({ code: 'custom', path: ['tools', i, 'tool'], message: 'Level 1 carries no tools; set measurement.level to 2 or 3 (MEAS-1)' });
      else if (m.level === 2 && !(LEVEL_2_TOOLS as readonly string[]).includes(t.tool)) {
        ctx.addIssue({ code: 'custom', path: ['tools', i, 'tool'], message: `${t.tool} sets cookies; Level 2 takes only ${LEVEL_2_TOOLS.join(' or ')} (MEAS-1)` });
      }
    });
  });

/**
 * The watcher's settings that the sources do not give (SITE-6; relay entry 13): heliostet-watcher-vars
 * writes watcher/wrangler.toml from these and the rest of the record, so the file is never edited.
 */
const watcher = z.strictObject({
  /** The watcher's KV namespace, created in the client's Cloudflare account at setup. */
  kvNamespaceId: z.string().regex(/^[0-9a-f]{32}$/, 'must be a KV namespace ID: 32 lowercase hex digits'),
  /** The YouTube channel's UC… ID, when sources.youtube.channel is a handle address and does not carry it. */
  youtubeChannelId: z.string().regex(/^UC[\w-]{22}$/, 'must be a channel ID: UC and 22 more characters').optional(),
});

const account = z.strictObject({
  /** R10, DOOR-1: the date the operator checked that both accounts are in the client's email. */
  ownerVerified: date.optional(),
  github: z
    .strictObject({
      organization: label(39),
      repository: label(100),
      /** The Vellum & Volt GitHub App's ID, which the watcher signs its token requests with; not a secret. */
      appId: z.int().positive().optional(),
      installationId: z.int().positive().optional(),
    })
    .optional(), // DOOR-1, MCP-1
  terms: z.strictObject({ accepted: date, version: label(20).optional() }).optional(), // LEG-1
  stripeCustomer: z.string().regex(/^cus_[A-Za-z0-9]+$/, 'must be a Stripe customer ID (cus_…)').optional(), // FND-1
});

export const clientRecordSchema = z
  .strictObject({
    $schema: z.string().optional(),
    heliostet,
    identity,
    plan,
    sources,
    principals: z.array(principal).min(1),
    show: show.optional(),
    doors,
    connector: connector.optional(),
    merch: merch.optional(),
    narrareach: narrareach.optional(),
    crawlers,
    look,
    vocabulary,
    subscribe: z.array(destination).optional(),
    social: z.array(social).default([]),
    support: support.optional(),
    startHere: slug.optional(), // FMT-3: a series slug
    visibility: z.record(itemKey, z.enum(['shown', 'unlisted', 'hidden'])).default({}), // ADM-6
    /** Alt text for an item's cover when the source gives none (PAGE-5); written by a person, never generated. */
    alt: z.record(itemKey, label(300)).default({}),
    clips: z.record(itemKey, z.enum(['clip', 'long-form'])).default({}), // FMT-4 override
    joins: z.array(join).default([]),
    /** Pairs the automatic episode match must leave apart: how the client undoes one (FMT-2, ADM-7). */
    unjoined: z.array(z.tuple([itemKey, itemKey])).default([]),
    sponsors: z.strictObject({ presentedBy: sponsorSlot.optional(), story: sponsorSlot.optional(), show: sponsorSlot.optional() }).default({}), // MON-1
    /** MON-2 (1.11): cookieless Cloudflare Web Analytics, on by default; off only by the client's choice. */
    analytics: z.strictObject({ on: z.boolean().default(true) }).default({ on: true }), // MON-2
    /** BRD 6.19: the measurement level and its tools, by public ID (MEAS-1). */
    measurement: measurement.default({ level: 1, tools: [] }),
    flip,
    /** The IndexNow key (ENT-4); public by design, served at /<key>.txt. */
    indexNow: z.strictObject({ key: z.string().regex(/^[a-zA-Z0-9-]{8,128}$/, 'must be 8 to 128 letters, digits, or hyphens') }).optional(),
    export: z.strictObject({ latest: date.optional() }).default({}), // FLIP-3
    onboarding: onboarding.optional(),
    account: account.optional(),
    watcher: watcher.optional(),
    /**
     * A site the operator owns: vellumandvolt.com, the Press, the personal site (relay entry 9,
     * ruling 2). Only such a site's watcher may use a fine-grained GitHub token; a client's mints
     * GitHub App installation tokens (DOOR-1).
     */
    operatorOwned: z.boolean().default(false),
    /**
     * Exceptions to Heliostet's rules for this one site, each with the ruling behind it. `emailForm`:
     * the pages that may carry a form taking an email address (ONB-1), and whether the band shared
     * across pages may (`band`), the Press's alone (relay entry 57, Lawrence's ruling of October 24).
     * No other site has one.
     */
    exceptions: z
      .strictObject({
        emailForm: z.strictObject({ ruled: date, why: z.string().min(1).max(300), band: z.boolean().default(false), pages: z.array(z.string().regex(/^\/[a-z0-9/-]*$/, 'must be a page on the site, such as /subscribe')).min(1) }).optional(),
      })
      .optional(),
  })
  .superRefine((record, ctx) => {
    const issue = (path: (string | number)[], message: string) => ctx.addIssue({ code: 'custom', path, message });
    const { edition } = record.plan;
    const editorUp = edition !== 'mirror';

    if (record.plan.plus && !editorUp) issue(['plan', 'plus'], 'Plus is sold on Editor or Connector, not Mirror.');
    if (record.doors.formEditor && !editorUp) issue(['doors', 'formEditor'], 'The form editor needs the Editor edition or higher.');
    if (record.doors.concierge && !editorUp) issue(['doors', 'concierge'], 'The concierge door needs the Editor edition or higher.');
    if (record.doors.connector && edition !== 'connector') issue(['doors', 'connector'], 'The publishing desk needs the Connector edition.');
    if (record.merch && !editorUp) issue(['merch'], 'Merch needs the Editor edition or higher (MER-1).');

    const ids = new Set<string>();
    record.principals.forEach((p, i) => {
      if (ids.has(p.id)) issue(['principals', i, 'id'], `"${p.id}" is used by two principals.`);
      ids.add(p.id);
    });

    if (record.plan.addOns.show && !record.show) issue(['show'], 'The Show add-on is on, so the record needs a show.');
    record.show?.hosts.forEach((host, i) => {
      if (!ids.has(host)) issue(['show', 'hosts', i], `"${host}" is not a principal's id.`);
    });

    const { hero } = record.vocabulary;
    const writing = record.sources.substack || record.sources.medium || record.doors.formEditor;
    if (hero === 'latest-writing' && !writing) {
      issue(['vocabulary', 'hero'], 'The hero is latest-writing, but the record has no Substack, no Medium, and no form editor to write with.');
    }
    if (hero === 'latest-video' && !record.sources.youtube) issue(['vocabulary', 'hero'], 'The hero is latest-video, but the record has no YouTube source.');
    if (hero === 'show' && !record.plan.addOns.show) issue(['vocabulary', 'hero'], 'The hero is the show block, but the Show add-on is off.');

    if (record.look.kind === 'bespoke' && !record.plan.addOns.bespoke) issue(['look', 'kind'], 'The look is Bespoke, but the bespoke add-on is off.');
    if (record.look.kind === 'brand' && !record.operatorOwned) issue(['look', 'kind'], 'The brand look is Vellum & Volt’s own, for a site the operator owns; a client site is Match or Bespoke.');
    const org = record.identity.organization;
    if (org && record.identity.brand !== 'organization') issue(['identity', 'organization'], 'Organization facts need identity.brand to be organization.');
    org?.founders.forEach((f, i) => {
      if (!ids.has(f)) issue(['identity', 'organization', 'founders', i], `"${f}" is not a principal's id.`);
    });

    record.subscribe?.forEach((d, i) => {
      const at = ['subscribe', i];
      if (d.kind === 'rss' && d.url) issue([...at, 'url'], 'RSS is the site’s own feed and takes no address.');
      if ((d.kind === 'apple-podcasts' || d.kind === 'spotify' || d.kind === 'other') && !d.url) issue([...at, 'url'], `A ${d.kind} destination needs an address.`);
      if (d.kind === 'other' && !d.label) issue([...at, 'label'], 'An other destination needs a label.');
      if (d.kind === 'substack' && !d.url && !record.sources.substack) issue([...at, 'url'], 'A Substack destination needs an address when the record has no Substack source.');
      if (d.kind === 'youtube' && !d.url && !record.sources.youtube) issue([...at, 'url'], 'A YouTube destination needs an address when the record has no YouTube source.');
    });
    record.social.forEach((s, i) => {
      if (s.platform === 'other' && !s.label) issue(['social', i, 'label'], 'An other platform needs a label.');
    });

    const joined = new Map<string, number>();
    record.joins.forEach((j, i) => {
      const keys = j.verb === 'same-thing' ? [j.canonical, ...j.items.map((x) => x.item)] : [j.lead, j.companion];
      for (const key of keys) {
        const earlier = joined.get(key);
        if (earlier === i) issue(['joins', i], `${key} appears twice in this join.`);
        else if (earlier !== undefined) issue(['joins', i], `${key} is already in join ${earlier}; an item belongs to one join at most.`);
        else joined.set(key, i);
      }
    });

    if (record.crawlers.cloudflare && record.crawlers.cloudflare.training !== record.crawlers.training) {
      issue(['crawlers', 'cloudflare', 'training'], `Cloudflare's training switch is "${record.crawlers.cloudflare.training}", but the record's choice is "${record.crawlers.training}"; ENT-6 needs them to agree.`);
    }

    // FLIP-1, SEC-14: the flip is on only with the date it was switched, which heliostet-flip writes.
    if (record.flip.on && !record.flip.switched) issue(['flip', 'switched'], 'The flip is on, so the record needs the date it was switched. Use heliostet-flip, which records it.');

    const ob = record.onboarding;
    if (ob?.path === 'concierge' && !ob.concierge) issue(['onboarding', 'concierge'], 'A Concierge setup needs its consent and setup-call dates.');
    if (ob?.path === 'self-serve' && ob.concierge) issue(['onboarding', 'concierge'], 'A Self-serve setup has no Concierge calls.');
  });

/** The record as written in client.json. */
export type ClientRecordInput = z.input<typeof clientRecordSchema>;
/** The record after parsing, with every default filled. */
export type ClientRecord = z.output<typeof clientRecordSchema>;
