// FMT-1: the site's vocabulary and front-page mode, two settings on the client record.
// The unit of work names the archive in the navigation, the archive headings, and the item
// slugs; the hero picks what leads the front page. Writing units keep the brand book's
// archive name, Latest, beside a Watch item for videos; the episode unit names the archive
// Episodes, and videos are the episodes, so there is no Watch.

export const UNITS = ['story', 'post', 'episode'] as const;
// 'own': the site supplies its own front page at src/pages/index.astro (a company site; relay entry 25).
export const HEROES = ['latest-writing', 'latest-video', 'show', 'own'] as const;

export type UnitName = (typeof UNITS)[number];
export type Hero = (typeof HEROES)[number];
export interface CustomUnit {
  singular: string;
  plural: string;
  slug: string;
  basis: 'writing' | 'episode';
}

export interface Words {
  /** The unit, capitalized: Story. */
  singular: string;
  /** Stories. */
  plural: string;
  /** The item route: /story/<slug>. */
  slug: string;
  basis: 'writing' | 'episode';
  /** The archive's navigation label: Latest, or Episodes. */
  archive: string;
  /** The archive's heading and the front page's link to it: All stories. */
  archiveHeading: string;
}

const BUILT_IN: Record<UnitName, CustomUnit> = {
  story: { singular: 'Story', plural: 'Stories', slug: 'story', basis: 'writing' },
  post: { singular: 'Post', plural: 'Posts', slug: 'post', basis: 'writing' },
  episode: { singular: 'Episode', plural: 'Episodes', slug: 'episode', basis: 'episode' },
};

export function words(unit: UnitName | CustomUnit): Words {
  const u = typeof unit === 'string' ? BUILT_IN[unit] : unit;
  return {
    ...u,
    archive: u.basis === 'writing' ? 'Latest' : u.plural,
    archiveHeading: `All ${u.plural.toLowerCase()}`,
  };
}

/** The front page's hero heading for each mode. */
export function heroHeading(hero: Hero, w: Words, showName?: string): string {
  if (hero === 'own') return '';
  if (hero === 'show') return showName ?? 'The show';
  if (hero === 'latest-video') return w.basis === 'episode' ? `The latest ${w.singular.toLowerCase()}` : 'The latest video';
  return w.basis === 'writing' ? `The latest ${w.singular.toLowerCase()}` : 'The latest writing';
}
