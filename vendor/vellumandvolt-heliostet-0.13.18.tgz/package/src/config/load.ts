// Reads client.json and refuses a record that fails the schema, with every failing field
// named by its path (FND-1).

import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import type { z } from 'zod';
import { clientRecordSchema, type ClientRecord } from './schema.js';

export const RECORD_FILE = 'client.json';

export class ClientRecordError extends Error {
  override name = 'ClientRecordError';
  constructor(
    message: string,
    /** Each failing field's path, such as identity.name or principals[0].id. */
    readonly fields: string[] = [],
  ) {
    super(message);
  }
}

function fieldPath(path: readonly PropertyKey[]): string {
  return path.reduce<string>((out, key) => (typeof key === 'number' ? `${out}[${key}]` : out ? `${out}.${String(key)}` : String(key)), '');
}

function valueAt(data: unknown, path: readonly PropertyKey[]): unknown {
  return path.reduce<unknown>((value, key) => (value !== null && typeof value === 'object' ? (value as Record<PropertyKey, unknown>)[key] : undefined), data);
}

function describe(issue: z.core.$ZodIssue, data: unknown): { field: string; line: string } {
  const field = fieldPath(issue.path);
  if (issue.code === 'unrecognized_keys') {
    const fields = issue.keys.map((key) => (field ? `${field}.${key}` : key));
    return { field: fields.join(', '), line: `${fields.join(', ')}: not a field of the client record` };
  }
  const missing = issue.code !== 'custom' && issue.path.length > 0 && valueAt(data, issue.path) === undefined;
  return { field: field || '(the record)', line: `${field || '(the record)'}: ${missing ? 'is required' : issue.message}` };
}

/** Validates a parsed client.json; `where` names the file in the error. */
export function parseClientRecord(data: unknown, where = RECORD_FILE): ClientRecord {
  const result = clientRecordSchema.safeParse(data);
  if (result.success) return result.data;
  const described = result.error.issues.map((issue) => describe(issue, data));
  const fields = described.flatMap((d) => d.field.split(', '));
  throw new ClientRecordError(
    `The client record at ${where} fails the schema:\n${described.map((d) => `  ${d.line}`).join('\n')}`,
    fields,
  );
}

export function loadClientRecord(file: URL): ClientRecord {
  const where = fileURLToPath(file);
  if (!existsSync(file)) throw new ClientRecordError(`No client record at ${where}. Every site is built from its client.json.`);
  let data: unknown;
  try {
    data = JSON.parse(readFileSync(file, 'utf8'));
  } catch (error) {
    throw new ClientRecordError(`The client record at ${where} is not valid JSON: ${(error as Error).message}`);
  }
  return parseClientRecord(data, where);
}
