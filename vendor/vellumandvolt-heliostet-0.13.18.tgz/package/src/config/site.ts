// The site config: what the templates read, derived from the client record at build. It holds
// only what a public page may show, so nothing operational (plan dates, account, onboarding)
// reaches the virtual module the pages import.

import type { LookOption } from '../build/look.js';
import { PageError, type Page } from './pages.js';
import type { ClientRecord } from './schema.js';
import type { NavFile } from '../site/schema.js';
import { destinations, mastheadSubscribe, type Destination } from './subscribe.js';
import { SOCIAL_LABELS } from './social-labels.js';
import { heroHeading, words, type Hero, type Words } from './vocabulary.js';

export interface NavItem {
  label: string;
  href: string;
  /** Its words on a phone (relay entry 112). */
  short?: string;
}

export interface SiteConfig {
  name: string;
  url: string;
  timeZone: string;
  /** The route writing lives under: the unit's slug, or story when the unit is the episode. */
  writingSlug: string;
  brand: ClientRecord['identity']['brand'];
  masthead: ClientRecord['identity']['masthead'];
  logo: { src: string; width: number; height: number } | null;
  vocabulary: Words & { hero: Hero; heroHeading: string };
  /** The archive items the edition includes, then up to six pages (PAGE-7). */
  nav: NavItem[];
  /** Pages beyond the sixth, under More. */
  more: NavItem[];
  /** Pages placed in the footer rather than the navigation, such as Privacy and Terms (relay entry 25). */
  footer: NavItem[];
  /** The masthead's name and mark, when site/nav.json gives its own (relay entry 54); else the site's. */
  lockup?: { name: string; logo: { src: string; width: number; height: number } | null };
  /** A licensed font kit's stylesheet, linked in every page's head after a preconnect (decision 0018). */
  fontKit?: { origin: string; stylesheet: string };
  /** The Look's images (relay entry 91): the share image for a page with no card of its own, the favicon, and the footer's logo. */
  shareImage?: { src: string; width: number; height: number } | null;
  favicon?: { src: string } | null;
  footerLogo?: { src: string; width: number; height: number; alt?: string | undefined } | null;
  /** The masthead's one primary action; site/nav.json can name its own (relay entry 53). */
  subscribeButton: NavItem | null;
  /** The footer's own links, in order: About, Subscribe, Links, Status, then the footer pages, unless site/nav.json says otherwise. */
  footerLinks: NavItem[];
  /** The footer's credit and legal line, from site.json (relay entry 112). */
  footerCredit?: 'made-with' | 'runs-on';
  footerLegal?: string | null;
  /** Whether the site has an archive at all: a source, or a door to write with. A company site may have none. */
  archive: boolean;
  /** An organization's public facts, when the brand is an organization (ENT-1). */
  organization: { legalName: string | null; locality: string | null; region: string | null; country: string | null; founders: string[] } | null;
  subscribe: Destination[];
  support: { url: string; label: string } | null;
  social: { platform: string; label: string; url: string }[];
  show: { name: string; hosts: string[] } | null;
  /** Public profiles of the principals, for the About, host, and press pages (ENT-1, PRIN-1, FMT-5). */
  principals: Principal[];
  /** Filled sponsor slots (MON-1); empty on every site by default. */
  sponsors: { [slot in 'presentedBy' | 'story' | 'show']?: { name: string; url: string; label: string } | undefined };
  merch: { url: string } | null;
  /** Public facts for the status page (SITE-6, ADM-5). */
  facts: { heliostet: string; exported: string | null; training: 'allow' | 'block'; edition: string; operatorOwned: boolean };
  sources: { substack: string | null; youtube: string | null; medium: string | null; podcast: string | null };
  /** The Start Here series the front page and the series index lead with (FMT-3). */
  startHere: string | null;
  /** The canonical flip (FLIP-1): on, the site is the original and Substack carries copies. */
  flip: { on: boolean; switched: string | null };
  /** The IndexNow key, public by design (ENT-4); null when the site has none. */
  indexNowKey: string | null;
}

export interface Principal {
  id: string;
  name: string;
  bio: { short: string; medium: string | null; long: string | null } | null;
  headshot: { large: string; small: string; alt: string } | null;
  sameAs: string[];
  knowsAbout: string[];
  location: string | null;
  pronunciation: string | null;
  wikidata: string | null;
  /** Their Person's @id on their own site, when it lives there; the site refers to it and builds no host page. */
  entityHome: string | null;
}

/** A repository path under public/ as the address the site serves it at. */
const served = (path: string) => `/${path.replace(/^public\//, '')}`;

/** Pages the navigation shows before the rest go under More (PAGE-7). */
export const MAX_NAV_PAGES = 6;

/** Whether the record gives the site an archive: any source, or a door that writes posts. */
export const hasArchive = (record: ClientRecord) =>
  Boolean(record.sources.substack || record.sources.youtube || record.sources.medium || record.sources.podcast || record.doors.formEditor || record.doors.connector);

export function navigation(record: ClientRecord, w: Words, pages: Page[] = []): { nav: NavItem[]; more: NavItem[]; footer: NavItem[] } {
  const editorUp = record.plan.edition !== 'mirror';
  if (pages.length > 0 && !editorUp) throw new PageError('Top-level pages need the Editor edition or higher (PAGE-7), and this record is on Mirror.');
  // A site with no archive yet has no Latest; it appears when a source does (relay entry 25).
  const archive: NavItem[] = hasArchive(record) ? [{ label: w.archive, href: '/latest' }] : [];
  if (w.basis === 'writing' && record.sources.youtube) archive.push({ label: 'Watch', href: '/watch' });
  if (record.plan.addOns.show && record.show) archive.push({ label: 'Show', href: '/show' });
  archive.push({ label: 'About', href: '/about' });
  if (editorUp && record.merch) archive.push({ label: 'Merch', href: '/merch' });
  if (editorUp && record.sources.substack) archive.push({ label: 'Notes', href: '/notes' });

  // The pages arrive in their frontmatter order; drafts never reach the navigation, and a page
  // placed in the footer, or nowhere, is not in it either.
  const live = pages.filter((p) => !p.draft);
  const items = live.filter((p) => p.place === 'nav').map((p) => ({ label: p.navLabel, href: `/${p.slug}` }));
  const footer = live.filter((p) => p.place === 'footer').map((p) => ({ label: p.navLabel, href: `/${p.slug}` }));
  return { nav: [...archive, ...items.slice(0, MAX_NAV_PAGES)], more: items.slice(MAX_NAV_PAGES), footer };
}

/** The menu, footer, and lockup site/nav.json sets, over the ones the record implies, as the build draws them; the
 *  Cockpit's channels preview draws the same (relay entry 103, Major 4). nav.json's own Subscribe button wins; without
 *  one, it's the first subscribe link (Major 3). */
export function withNav(site: SiteConfig, nav: NavFile): SiteConfig {
  return {
    ...site,
    nav: nav.menu.map((n) => ({ label: n.label, href: n.to })),
    more: [],
    subscribeButton: nav.subscribe ? { label: nav.subscribe.label, href: nav.subscribe.to, ...(nav.subscribe.short ? { short: nav.subscribe.short } : {}) } : site.subscribeButton,
    footerLinks: nav.footer.map((n) => ({ label: n.label, href: n.to })),
    ...(nav.lockup ? { lockup: { name: nav.lockup.name, logo: nav.lockup.mark ?? null } } : {}),
  };
}

export function siteConfig(record: ClientRecord, pages: Page[] = []): SiteConfig {
  const w = words(record.vocabulary.unit);
  const { nav, more, footer } = navigation(record, w, pages);
  const org = record.identity.organization;
  const logo = record.identity.logo;
  return {
    name: record.identity.name,
    url: `https://${record.identity.domain}`,
    timeZone: record.identity.timeZone,
    writingSlug: w.basis === 'writing' ? w.slug : 'story',
    brand: record.identity.brand,
    masthead: record.identity.masthead,
    logo: logo ? { src: served(logo.file), width: logo.width, height: logo.height } : null,
    vocabulary: { ...w, hero: record.vocabulary.hero, heroHeading: heroHeading(record.vocabulary.hero, w, record.show?.name) },
    nav,
    more,
    footer,
    subscribeButton: mastheadSubscribe(record),
    footerLinks: [
      { label: 'About', href: '/about' },
      ...(destinations(record).length > 0 ? [{ label: 'Subscribe', href: '/subscribe' }] : []),
      ...(destinations(record).length > 0 || record.social.length > 0 ? [{ label: 'Links', href: '/links' }] : []),
      { label: 'Status', href: '/status' },
      ...footer,
    ],
    archive: hasArchive(record),
    organization:
      record.identity.brand === 'organization' && org
        ? { legalName: org.legalName ?? null, locality: org.locality ?? null, region: org.region ?? null, country: org.country ?? null, founders: org.founders }
        : null,
    subscribe: destinations(record),
    support: record.support ?? null,
    social: record.social.map((s) => ({ platform: s.platform, label: s.label ?? SOCIAL_LABELS[s.platform] ?? s.platform, url: s.url })),
    show: record.plan.addOns.show && record.show ? { name: record.show.name, hosts: record.show.hosts } : null,
    principals: record.principals.map((p) => ({
      id: p.id,
      name: p.name,
      bio: p.bio ? { short: p.bio.short, medium: p.bio.medium ?? null, long: p.bio.long ?? null } : null,
      headshot: p.headshot ? { large: served(p.headshot.large), small: served(p.headshot.small), alt: p.headshot.alt } : null,
      sameAs: p.sameAs,
      knowsAbout: p.knowsAbout,
      location: p.location ?? null,
      pronunciation: p.pronunciation ?? null,
      wikidata: p.wikidata ?? null,
      entityHome: p.entityHome ?? null,
    })),
    sponsors: record.sponsors,
    merch: record.plan.edition !== 'mirror' && record.merch ? { url: (record.merch.store?.url ?? record.merch.stores?.[0]?.url) as string } : null,
    facts: { heliostet: record.heliostet.version, exported: record.export.latest ?? null, training: record.crawlers.training, edition: record.plan.edition, operatorOwned: record.operatorOwned },
    sources: {
      substack: record.sources.substack?.url ?? null,
      youtube: record.sources.youtube?.channel ?? null,
      medium: record.sources.medium?.url ?? null,
      podcast: record.sources.podcast?.feed ?? null,
    },
    startHere: record.startHere ?? null,
    flip: { on: record.flip.on, switched: record.flip.switched ?? null },
    indexNowKey: record.indexNow?.key ?? null,
  };
}

/**
 * The look the record names, with the Match Substack defaulting to the Substack source (DS-4).
 * The brand look is no option at all: Vellum & Volt's own tokens, with no overlay.
 */
export function lookOption(record: ClientRecord): LookOption | undefined {
  if (record.look.kind === 'brand') return undefined;
  if (record.look.kind === 'bespoke' || record.look.kind === 'house') return record.look;
  const substack = record.look.substack ?? record.sources.substack?.url;
  return { kind: 'match', ...(substack ? { substack } : {}), ...(record.look.overlay ? { overlay: record.look.overlay } : {}) };
}
