// heliostet-new-site: starts a client repository from the template (Step 11).
//   heliostet-new-site <dir>
// Copies template/, packs this Heliostet into vendor/, and fills client.json's heliostet.version and heliostet.sha256.
// Run it from Heliostet’s repository; then fill client.json, run pnpm install, and commit.

import { resolve } from 'node:path';
import { newSite, NewSiteError } from '../build/new-site.js';

const dir = process.argv[2];
if (!dir) {
  console.error('Usage: heliostet-new-site <dir>');
  process.exit(2);
}
try {
  const site = newSite(resolve(dir));
  console.log(`Started a site in ${site.dir} with Heliostet ${site.version} (sha256 ${site.sha256}). Fill client.json, then run pnpm install.`);
} catch (error) {
  if (!(error instanceof NewSiteError)) throw error;
  console.error(error.message);
  process.exit(1);
}
