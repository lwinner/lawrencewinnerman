// heliostet-import: imports a site's sources into the repository, so the build never depends on them.
//   heliostet-import all                                                              (every source in client.json)
//   heliostet-import substack [--url https://name.substack.com] [--all] [--limit N]   (SITE-1)
//   heliostet-import youtube  [--url https://www.youtube.com/@handle]                 (SITE-2)
//   heliostet-import podcast  [--url https://host/feed.xml]                           (FMT-2)
//   heliostet-import medium   [--url https://medium.com/feed/@name]                   (SITE-3)
// Each address defaults to the source in client.json. Every body is sanitized (SEC-1) and
// each file is written only when it changed. The YouTube import reads the client's Data API
// key from the YOUTUBE_API_KEY environment variable; it is never printed or written. After
// any import, new automatic episode matches are written into client.json's joins.

import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { importMediumFeed, MEDIUM_DIR } from '../adapters/medium.js';
import { importFeed, PODCAST_DIR } from '../adapters/podcast.js';
import { importArchive, SUBSTACK_DIR } from '../adapters/substack.js';
import { importChannel, YOUTUBE_DIR } from '../adapters/youtube.js';
import { loadItems } from '../build/content.js';
import { mediaUrls } from '../build/localize.js';
import { rehost } from '../build/media-store.js';
import { recordMatches } from '../build/record-matches.js';
import { loadClientRecord, RECORD_FILE } from '../config/load.js';

const USAGE = 'Usage: heliostet-import all|substack|youtube|podcast|medium [--url address] [--all] [--limit N]';
const { values, positionals } = parseArgs({
  allowPositionals: true,
  options: { url: { type: 'string' }, all: { type: 'boolean' }, limit: { type: 'string' } },
});

const source = positionals[0];
const root = pathToFileURL(`${process.cwd()}/`);
const sources = () => loadClientRecord(new URL(RECORD_FILE, root)).sources;
const dirFor = (folder: string) => new URL(folder, root);

function address(found: string | undefined, name: string): string {
  const url = values.url ?? found;
  if (!url) {
    console.error(`The client record names no ${name}; pass --url.`);
    process.exit(2);
  }
  return url;
}

/** Imports one source; false when it could not run. */
async function importSource(name: string, all = false): Promise<boolean> {
  switch (name) {
    case 'substack': {
      const url = address(sources().substack?.url, 'Substack');
      const limit = values.limit ? Number(values.limit) : undefined;
      const cleanup = sources().substack?.cleanup;
      const result = await importArchive(url, dirFor(SUBSTACK_DIR), { all: values.all ?? false, ...(limit ? { limit } : {}), ...(cleanup ? { cleanup } : {}) });
      console.log(`Listed ${result.listed} posts, fetched ${result.fetched}, wrote ${result.written} to ${SUBSTACK_DIR}.`);
      for (const skipped of result.skipped) console.error(`Skipped ${skipped}`);
      return result.skipped.length === 0;
    }
    case 'youtube': {
      const url = address(sources().youtube?.channel, 'YouTube channel');
      const apiKey = process.env.YOUTUBE_API_KEY;
      if (!apiKey) {
        console.error('Set YOUTUBE_API_KEY to the client’s YouTube Data API key for this command; it is read here and never written down.');
        if (all) return false;
        process.exit(2);
      }
      const result = await importChannel(url, dirFor(YOUTUBE_DIR), { apiKey });
      console.log(`Listed ${result.listed} videos and wrote ${result.written} to ${YOUTUBE_DIR}.`);
      return true;
    }
    case 'podcast': {
      const result = await importFeed(address(sources().podcast?.feed, 'podcast feed'), dirFor(PODCAST_DIR));
      console.log(`Listed ${result.listed} episodes and wrote ${result.written} to ${PODCAST_DIR}.`);
      return true;
    }
    case 'medium': {
      const medium = sources().medium?.url;
      const feed = values.url ?? (medium ? medium.replace(/^https:\/\/medium\.com\/(@[^/]+).*$/, 'https://medium.com/feed/$1') : undefined);
      const result = await importMediumFeed(address(feed, 'Medium'), dirFor(MEDIUM_DIR));
      console.log(`Listed ${result.listed} stories and wrote ${result.written} to ${MEDIUM_DIR}.`);
      return true;
    }
    default:
      console.error(USAGE);
      process.exit(2);
  }
}

if (source === 'all') {
  // Every source the record names, as the rebuild workflow runs it (SITE-6, SITE-7). One source
  // that fails is named and the others still import; the command then exits 1.
  if (values.url) {
    console.error('heliostet-import all reads every address from client.json; --url names one source.');
    process.exit(2);
  }
  const named = Object.entries(sources()).filter(([, v]) => v).map(([k]) => k).filter((k) => ['substack', 'youtube', 'podcast', 'medium'].includes(k));
  for (const name of named) {
    const ok = await importSource(name, true).catch((error: unknown) => {
      console.error(`The ${name} import failed: ${error instanceof Error ? error.message : String(error)}`);
      return false;
    });
    if (!ok) process.exitCode = 1;
  }
} else if (!(await importSource(source ?? ''))) process.exitCode = 1;

// Every image the site shows is copied into public/media/ (Step 7; LEG-4, ENT-5).
const record = loadClientRecord(new URL(RECORD_FILE, root));
const media = await rehost(root, mediaUrls(loadItems(root, record)));
console.log(`Copied ${media.copied} new ${media.copied === 1 ? 'image' : 'images'} into public/media/.`);
for (const failure of media.failed) console.error(failure);

// The automatic episode match is recorded here, not at build (FMT-2, ADM-7).
for (const join of recordMatches(root)) {
  console.log(`Recorded ${join.page} and ${join.others.map((o) => o.item).join(', ')} as the same episode in client.json. Unjoin it to keep them apart.`);
}
