// heliostet-indexnow: sends the pages a deploy changed to IndexNow (ENT-4).
//   heliostet-indexnow <previous sitemap.xml> <dist directory> [--all]
// Run by the deploy workflow after a deploy, with the sitemap the site served before it. --all
// sends every page, as after the canonical flip (FLIP-1). The key is the site's indexNow.key in
// client.json, which is public by design.

import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { changedUrls, pingIndexNow } from '../build/indexnow.js';
import { loadClientRecord, RECORD_FILE } from '../config/load.js';

const { values, positionals } = parseArgs({ allowPositionals: true, options: { all: { type: 'boolean' } } });
const [previous, dist] = positionals;
if (!dist) {
  console.error('Usage: heliostet-indexnow <previous sitemap.xml> <dist directory> [--all]');
  process.exit(2);
}
const record = loadClientRecord(new URL(RECORD_FILE, pathToFileURL(`${process.cwd()}/`)));
const key = record.indexNow?.key;
if (!key) {
  console.log('The client record has no indexNow key; nothing was sent.');
  process.exit(0);
}
const before = previous && existsSync(previous) ? readFileSync(previous, 'utf8') : '';
const urls = changedUrls(before, readFileSync(join(dist, 'sitemap.xml'), 'utf8'), values.all ?? false);
const sent = await pingIndexNow(`https://${record.identity.domain}`, key, urls);
console.log(`Sent ${sent} ${sent === 1 ? 'URL' : 'URLs'} to IndexNow.`);
