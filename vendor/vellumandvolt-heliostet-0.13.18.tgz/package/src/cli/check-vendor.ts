// heliostet-check-vendor: the deploy workflow's first check (Step 11). It confirms Heliostet this repository
// builds with is the one client.json names: the tarball for heliostet.version is in vendor/, its SHA-256
// matches heliostet.sha256, and the installed Heliostet reports that version. The build checks the same; this
// runs it before anything is built, so a wrong version fails first and plainly.

import { pathToFileURL } from 'node:url';
import { checkVendored, HeliostetVersionError } from '../build/vendor.js';
import { loadClientRecord, RECORD_FILE } from '../config/load.js';

const root = pathToFileURL(`${process.cwd()}/`);
try {
  const record = loadClientRecord(new URL(RECORD_FILE, root));
  if (!record.heliostet.sha256) throw new HeliostetVersionError('client.json has no heliostet.sha256; a client repository records the hash of its vendored kit.');
  checkVendored(root, record.heliostet);
  console.log(`Heliostet ${record.heliostet.version}: the vendored tarball is present, its hash matches, and it is the version installed.`);
} catch (error) {
  console.error(`${(error as Error).name}: ${(error as Error).message}`);
  process.exit(1);
}
