// heliostet-match: writes a site's Match overlay (DS-4) so the build never depends on Substack, and
// copies the publication's logo into the site (DS-5), recording it in client.json.
//   heliostet-match <substack-url> [--out looks/match.json] [--html saved-page.html] [--record client.json] [--skip-logo]
// Prints every flag in plain language. When the theme cannot be read it writes nothing,
// says so, and exits 1; the build then falls back to Newsroom on its own.

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { loadHouseLook, DEFAULT_MATCH_OVERLAY } from '../build/look.js';
import { copyLogo, LogoError } from '../build/logo.js';
import { fromHtml, match } from '../build/match.js';
import { RECORD_FILE } from '../config/load.js';

const { values, positionals } = parseArgs({
  allowPositionals: true,
  options: { out: { type: 'string' }, html: { type: 'string' }, record: { type: 'string' }, 'skip-logo': { type: 'boolean' } },
});

const url = positionals[0];
if (!url) {
  console.error('Usage: heliostet-match <substack-url> [--out looks/match.json] [--html saved-page.html] [--record client.json] [--skip-logo]');
  process.exit(2);
}

const newsroom = loadHouseLook('newsroom');
const result = values.html ? fromHtml(readFileSync(values.html, 'utf8'), newsroom) : await match(url, { newsroom });
for (const message of result.messages) console.log(`Flag: ${message}`);

if (result.look !== 'match') {
  console.error('No Match overlay was written. The site will build in the Newsroom look until the theme can be read.');
  process.exit(1);
}

const out = resolve(values.out ?? DEFAULT_MATCH_OVERLAY);
mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, JSON.stringify(result.overlay, null, 2) + '\n');
console.log(`Wrote the Match look for ${result.source?.name ?? url} to ${out}.`);

// DS-5: the logo goes into the repository and the record, never a hotlink.
const recordFile = resolve(values.record ?? RECORD_FILE);
const logo = result.source?.logo;
if (values['skip-logo']) {
  console.log('The logo was not copied (--skip-logo).');
} else if (!logo) {
  console.log('The publication has no logo to copy.');
} else if (!existsSync(recordFile)) {
  console.log(`No client record at ${recordFile}, so the logo was not copied.`);
} else {
  try {
    const copied = await copyLogo(logo, pathToFileURL(dirname(recordFile) + '/'));
    const record = JSON.parse(readFileSync(recordFile, 'utf8')) as { identity?: Record<string, unknown> };
    record.identity = { ...record.identity, logo: copied };
    writeFileSync(recordFile, JSON.stringify(record, null, 2) + '\n');
    console.log(`Copied the logo to ${copied.file} (${copied.width} by ${copied.height}) and recorded it in ${recordFile}.`);
  } catch (error) {
    if (!(error instanceof LogoError)) throw error;
    console.error(`Flag: ${error.message} The masthead shows the name alone until a logo is copied.`);
    process.exitCode = 1;
  }
}
