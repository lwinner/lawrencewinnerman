// heliostet-upgrade: upgrades a client site to this version of Heliostet (Step 12).
//   heliostet-upgrade <site-dir> --to <version> [--force]
// Run it from Heliostet at <version>. It changes the folder only; then run pnpm install and a build in
// the site, and commit the result to a drafts branch.

import { resolve } from 'node:path';
import { parseArgs } from 'node:util';
import { HeliostetUpgradeError, upgradeSite } from '../build/upgrade.js';

const { values, positionals } = parseArgs({ allowPositionals: true, options: { to: { type: 'string' }, force: { type: 'boolean' } } });
const [dir] = positionals;
if (!dir || !values.to) {
  console.error('Usage: heliostet-upgrade <site-dir> --to <version> [--force]');
  process.exit(2);
}
try {
  const done = upgradeSite(resolve(dir), values.to, { force: values.force ?? false });
  for (const line of done.migrated) console.log(`Moved to the new name: ${line}.`);
  console.log(`Upgraded ${dir} from Heliostet ${done.from} to ${done.to}; refreshed ${done.refreshed.length} Heliostet-managed files${done.overwritten.length ? `, overwriting ${done.overwritten.join(', ')}` : ''}; ${done.watcher === 'generated' ? 'wrote watcher/wrangler.toml from client.json' : 'copied the watcher skeleton, since client.json has no watcher fields yet'}; ${done.substackZone ? `wrote the Substack check's schedule for ${done.substackZone}` : 'left the Substack check unscheduled, since client.json names no Substack'}. Now run pnpm install and a build, then commit to a drafts branch.`);
} catch (error) {
  if (!(error instanceof HeliostetUpgradeError)) throw error;
  console.error(`HeliostetUpgradeError: ${error.message}`);
  process.exit(1);
}
