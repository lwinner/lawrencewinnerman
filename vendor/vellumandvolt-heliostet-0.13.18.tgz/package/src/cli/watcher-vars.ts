// heliostet-watcher-vars: writes the files generated from client.json (Step 8; relay entry 9, ruling 2;
// relay entries 13 and 22a): watcher/wrangler.toml from Heliostet’s skeleton, and the Substack check's
// .github/workflows/substack.yml with its schedule in the client's time zone. A client site gets the
// GitHub App's installation; only a record with operatorOwned gets a fine-grained token. The secrets
// are named, never written.
//   heliostet-watcher-vars            write the files
//   heliostet-watcher-vars --check    fail with a named error if a file is not what it would write

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { checkSubstackWorkflow, scheduleOf, SUBSTACK_WORKFLOW_PATH, substackWorkflow, SubstackWorkflowStaleError } from '../build/substack-schedule.js';
import { checkWatcherConfig, WATCHER_CONFIG, watcherConfig, WatcherConfigStaleError, WatcherVarsError } from '../build/watcher-vars.js';
import { loadClientRecord, RECORD_FILE } from '../config/load.js';

const { values } = parseArgs({ options: { check: { type: 'boolean' } } });
const dir = process.cwd();
const write = (path: string, text: string) => {
  const file = join(dir, path);
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, text);
};
try {
  const record = loadClientRecord(new URL(RECORD_FILE, pathToFileURL(`${dir}/`)));
  // The zone from the file as written: the parsed record fills a default, and an unset zone means Eastern here.
  const { zone, substack } = scheduleOf(JSON.parse(readFileSync(join(dir, RECORD_FILE), 'utf8')));
  if (values.check) {
    checkSubstackWorkflow(dir, zone, substack);
    checkWatcherConfig(dir, record);
    console.log(`${SUBSTACK_WORKFLOW_PATH} and ${WATCHER_CONFIG} are current.`);
  } else {
    write(SUBSTACK_WORKFLOW_PATH, substackWorkflow(zone, substack));
    console.log(substack ? `Wrote ${SUBSTACK_WORKFLOW_PATH} for ${zone}.` : `Wrote ${SUBSTACK_WORKFLOW_PATH} with no schedule, since client.json names no Substack.`);
    write(WATCHER_CONFIG, watcherConfig(record));
    console.log(`Wrote ${WATCHER_CONFIG} from client.json. Commit both to a drafts branch.`);
  }
} catch (error) {
  if (!(error instanceof WatcherVarsError || error instanceof WatcherConfigStaleError || error instanceof SubstackWorkflowStaleError)) throw error;
  console.error(`${error.name}: ${error.message}`);
  process.exit(1);
}
