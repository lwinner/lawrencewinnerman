// heliostet-flip: the canonical flip, for the operator only (FLIP-1, SEC-14).
//   heliostet-flip                       the dry-run report: what the flip would change
//   heliostet-flip on --confirm <domain> turn it on; the site's own domain, typed back
//   heliostet-flip off                   turn it off again, the one-command revert
// It writes flip in client.json and nothing else; the next build makes the change, and the
// deploy sends every page to IndexNow again.

import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { loadItems } from '../build/content.js';
import { flipReport, setFlip } from '../build/flip.js';
import { resolve } from '../build/resolve.js';
import { loadClientRecord, RECORD_FILE } from '../config/load.js';
import { loadPages } from '../config/pages.js';
import { siteConfig } from '../config/site.js';

const { values, positionals } = parseArgs({ allowPositionals: true, options: { confirm: { type: 'string' } } });
const root = pathToFileURL(`${process.cwd()}/`);
const recordFile = new URL(RECORD_FILE, root);
const record = loadClientRecord(recordFile);
const action = positionals[0];

if (action === 'on' || action === 'off') {
  setFlip(recordFile, action === 'on', values.confirm);
  console.log(action === 'on' ? `The flip is on for ${record.identity.domain}. Rebuild and deploy, then send every page to IndexNow (heliostet-indexnow --all).` : 'The flip is off. Rebuild and deploy.');
} else {
  const site = siteConfig(record, loadPages(root));
  const report = flipReport(resolve(loadItems(root, record), record, site));
  console.log(`The flip is ${record.flip.on ? `on, since ${record.flip.switched}` : 'off'}. Turning it ${record.flip.on ? 'off' : 'on'} would:`);
  console.log(`  ${record.flip.on ? 'give back' : 'move'} the Substack source of ${report.stories} stories ${record.flip.on ? 'to isBasedOn' : 'from isBasedOn to sameAs'};`);
  console.log(`  keep ${report.redirects} /p/<slug> redirects to the site's story pages;`);
  console.log(`  ${record.flip.on ? 'remove' : 'add'} the line on the About page saying the site is the primary home;`);
  console.log('  and send every page to IndexNow again after the deploy.');
  console.log(record.flip.on ? 'To revert: heliostet-flip off' : `To turn it on: heliostet-flip on --confirm ${record.identity.domain}`);
}
