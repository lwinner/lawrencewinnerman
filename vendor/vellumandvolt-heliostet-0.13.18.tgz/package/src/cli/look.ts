// heliostet-look: starts a Bespoke look from a house look (Step 9).
//   heliostet-look new --from <newsroom|broadcast|study> [--force]
// Run in the client repository. It writes src/look/bespoke.json and src/look/bespoke.md and records
// the look in client.json; it refuses an unknown base, a record without the Bespoke add-on, and an
// existing bespoke.json unless --force is given.

import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { BespokeError, newBespoke } from '../build/bespoke.js';

const USAGE = 'Usage: heliostet-look new --from <newsroom|broadcast|study> [--force]';
const { values, positionals } = parseArgs({ allowPositionals: true, options: { from: { type: 'string' }, force: { type: 'boolean' } } });
if (positionals[0] !== 'new' || !values.from) {
  console.error(USAGE);
  process.exit(2);
}
try {
  const made = newBespoke(pathToFileURL(`${process.cwd()}/`), values.from, { force: values.force ?? false });
  console.log(`Started the Bespoke look from ${values.from}: ${made.overlay} and ${made.notes}, recorded in client.json.`);
} catch (error) {
  if (!(error instanceof BespokeError)) throw error;
  console.error(error.message);
  process.exit(1);
}
