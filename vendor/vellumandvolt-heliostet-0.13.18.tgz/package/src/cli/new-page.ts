// heliostet-new-page: adds a page to a site from a stock recipe (CMP-4, relay entry 53).
//   heliostet-new-page <recipe> <id> [--address /work] [--title "Work With Me"]
// Run in the client repository. It writes site/pages/<id>.json (or site/templates/<id>.json for the
// Story and Chapter recipes) from the recipe's stand-in fields, and refuses a file that exists.

import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';
import { newPage, NewPageError, RECIPES } from '../site/recipes.js';

const USAGE = `Usage: heliostet-new-page <${RECIPES.join('|')}> <id> [--address /work] [--title "Work With Me"]`;
const { values, positionals } = parseArgs({ allowPositionals: true, options: { address: { type: 'string' }, title: { type: 'string' } } });
const [recipe, id] = positionals;
if (!recipe || !id) {
  console.error(USAGE);
  process.exit(2);
}
try {
  const path = newPage(pathToFileURL(`${process.cwd()}/`), recipe, id, { ...(values.address ? { address: values.address } : {}), ...(values.title ? { title: values.title } : {}) });
  console.log(`Wrote ${path} from the ${recipe} recipe. Fill in its stand-in fields, then build.`);
} catch (error) {
  if (!(error instanceof NewPageError)) throw error;
  console.error(error.message);
  process.exit(1);
}
