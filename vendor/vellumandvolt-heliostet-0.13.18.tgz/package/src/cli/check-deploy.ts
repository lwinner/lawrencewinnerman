// heliostet-check-deploy: the deploy workflow's check before Wrangler (Step 11). It refuses a production
// deploy, with a named error, when client.json lacks account.ownerVerified or (on a client's site)
// account.terms, and confirms the built site is there. On success it writes the site's domain to the
// step's outputs, for the IndexNow step.
//   heliostet-check-deploy [dist directory]

import { appendFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { checkDeploy, readyLine } from '../build/deploy-check.js';
import { loadClientRecord, RECORD_FILE } from '../config/load.js';

const dist = process.argv[2] ?? 'dist';
try {
  const record = loadClientRecord(new URL(RECORD_FILE, pathToFileURL(`${process.cwd()}/`)));
  const { domain } = checkDeploy(record);
  if (!existsSync(join(dist, 'index.html'))) throw Object.assign(new Error(`There is no built site in ${dist}/; build before deploying.`), { name: 'DeployRefusedError' });
  console.log(readyLine(record));
  if (process.env.GITHUB_OUTPUT) appendFileSync(process.env.GITHUB_OUTPUT, `domain=${domain}\n`);
} catch (error) {
  console.error(`${(error as Error).name}: ${(error as Error).message}`);
  process.exit(1);
}
