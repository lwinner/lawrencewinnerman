// heliostet-verify-dispatch: the rebuild workflow's first step on a dispatch (SEC-8). It checks the
// watcher's signature and writes go=true or go=false to the step's outputs; every later step runs
// only on go=true, so an unsigned or forged dispatch is ignored, not failed. It reads:
//   DISPATCH_PAYLOAD, DISPATCH_SIGNATURE   the workflow_dispatch inputs
//   WATCHER_DISPATCH_KEY                   the shared key, a GitHub secret
//   GITHUB_REPOSITORY, GITHUB_OUTPUT       set by GitHub Actions
// It prints the verdict and the sources, never the key, the payload, or the signature.

import { appendFileSync } from 'node:fs';
import { verifyDispatch } from '../build/dispatch.js';

const env = process.env;
const verdict = await verifyDispatch(env.DISPATCH_PAYLOAD ?? '', env.DISPATCH_SIGNATURE ?? '', env.WATCHER_DISPATCH_KEY ?? '', { repo: env.GITHUB_REPOSITORY ?? '' });
if (verdict.ok) console.log(`Signed dispatch from the watcher: ${verdict.payload.sources.join(', ') || 'no source named'} changed.`);
else console.log(`::notice::Dispatch ignored: ${verdict.reason}.`);
if (env.GITHUB_OUTPUT) appendFileSync(env.GITHUB_OUTPUT, `go=${verdict.ok}\n`);
