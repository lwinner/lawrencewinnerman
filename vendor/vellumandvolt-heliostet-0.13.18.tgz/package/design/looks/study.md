# The Study Look

Warm neutral, generous measure. For essayists, parenting and faith writers, memoirists, anyone whose readers stay for twenty minutes.

A house look, not a product: it is never shown to a prospect by name. It is the fallback when no Substack theme can be read (Newsroom), a starting point for a Bespoke build, and a look for the Sample Show and the Press. A house look is an overlay: `looks/study.json` carries the tokens that replace the brand's tokens of the same name on a site built in this look, and nothing else changes. The status and family tokens, the spacing and radius scales, and every component come from the system unchanged, so a status page in Study is the same status page with a different ground. Heliostet consumes the overlay as its one token file (PAGE-4); swapping it restyles every page.

## Palette

Ground `surface` #f4ede2, raised #faf6ef, sunken #ebe2d3; `ink` #2f2a24, `ink-muted` #5e564c, `ink-faint` #6f6757; `rule` #dcd2c2 and `rule-strong` #8d8270; `surface-inverse` #2f2a24 with `on-inverse` #f4ede2. The accent, in the `volt` slot, is terracotta #9c4a2a, with `on-volt` #f4ede2, `volt-text` #8a3f22, and `volt-soft` #f1dfd4. Every text pair in the overlay's usage notes holds 4.5:1 and `rule-strong` holds 3:1 on `surface`; the accent reads as text on `surface` at better than 5:1. The brand's chartreuse appears on a Study site only inside the footer credit's link underline.

## Type

Display is Lora at weight 500 for the masthead name, story titles, and card titles; reading is Source Serif 4 at 19px on 32px with the measure at 720px; the interface stays IBM Plex Sans. All three are Google-licensed faces under the Open Font License, so the client's site carries them without a license of its own. Heliostet self-hosts them from its own copies (DS-5) and emits no font stylesheet link; the overlay's `meta.googleFonts` only records where the faces come from. Fallbacks are system serifs and sans so the page reads before the fonts arrive.

## Layout

A quiet masthead: the lockup slot centered over a hairline, navigation in ui beneath it, no band. One story at a time on the front page, title in Lora 500 at 40px, dek in dek, then the first paragraph in body at measure before the Read on link in the accent. Space-8 between stories; no kickers; dates in small-serif only.

## Why This Look

The look the Press never needed: a parenting writer or a faith writer should never see a satire newsroom. The warm ground and the wide measure slow the page down, the terracotta is warm without being orange, and Lora's calligraphic serif is distinct from the brand's Fraunces so the client's site never looks like ours.
