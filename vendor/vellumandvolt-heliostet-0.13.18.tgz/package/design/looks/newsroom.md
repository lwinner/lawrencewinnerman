# The Newsroom Look

Ivory, serif heads, dense. For reporters, satirists, political writers, anyone with a daily rhythm and a lot of archive.

A house look, not a product: it is never shown to a prospect by name. It is the fallback when no Substack theme can be read (Newsroom), a starting point for a Bespoke build, and a look for the Sample Show and the Press. A house look is an overlay: `looks/newsroom.json` carries the tokens that replace the brand's tokens of the same name on a site built in this look, and nothing else changes. The status and family tokens, the spacing and radius scales, and every component come from the system unchanged, so a status page in Newsroom is the same status page with a different ground. Heliostet consumes the overlay as its one token file (PAGE-4); swapping it restyles every page.

## Palette

Ground `surface` #f5f0e6, raised #fbf8f2, sunken #ebe4d4; `ink` #141210, `ink-muted` #4a443b, `ink-faint` #6b645a; `rule` #d6ccb8 and `rule-strong` #8c8066; `surface-inverse` #141210 with `on-inverse` #f5f0e6. The accent, in the `volt` slot, is newsprint blue #1f3a93, with `on-volt` #f5f0e6, `volt-text` #1f3a93, and `volt-soft` #dde3f3. Every text pair in the overlay's usage notes holds 4.5:1 and `rule-strong` holds 3:1 on `surface`; the accent reads as text on `surface` at better than 5:1. The brand's chartreuse appears on a Newsroom site only inside the footer credit's link underline.

## Type

Display is Fraunces at weight 700 for the masthead name, story titles, and card titles; reading is Source Serif 4 at 17px on 26px with the measure at 640px; the interface stays IBM Plex Sans. All three are Google-licensed faces under the Open Font License, so the client's site carries them without a license of its own. Heliostet self-hosts them from its own copies (DS-5) and emits no font stylesheet link; the overlay's `meta.googleFonts` only records where the faces come from. Fallbacks are system serifs and sans so the page reads before the fonts arrive.

## Layout

A masthead band in surface-inverse with the lockup slot reversed, a hairline rule in rule-strong beneath the navigation, and a kicker above every story in label style. Story lists are dense: title in headline at 28px, dek in dek, byline and date in small-serif on one line, a rule between items and no card borders.

## Why This Look

The generalized B2 direction the Press runs on, with Adelle replaced by Fraunces at a heavier weight and Source Serif for the body. The blue is the one newsprint color that never collides with the status triad on the public status page.
