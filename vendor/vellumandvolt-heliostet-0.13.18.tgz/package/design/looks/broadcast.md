# The Broadcast Look

Deep single color, bold sans, show-forward. For shows, podcasts, two-host networks, anyone whose front page is the next episode.

A house look, not a product: it is never shown to a prospect by name. It is the fallback when no Substack theme can be read (Newsroom), a starting point for a Bespoke build, and a look for the Sample Show and the Press. A house look is an overlay: `looks/broadcast.json` carries the tokens that replace the brand's tokens of the same name on a site built in this look, and nothing else changes. The status and family tokens, the spacing and radius scales, and every component come from the system unchanged, so a status page in Broadcast is the same status page with a different ground. Heliostet consumes the overlay as its one token file (PAGE-4); swapping it restyles every page.

## Palette

Ground `surface` #0b3d40, raised #104a4e, sunken #072e31; `ink` #f2f7f6, `ink-muted` #c4d9d8, `ink-faint` #9fbcbb; `rule` #1d5d61 and `rule-strong` #5f9397; `surface-inverse` #f2f7f6 with `on-inverse` #0b3d40. The accent, in the `volt` slot, is sky #8fd3ff, with `on-volt` #0b3d40, `volt-text` #8fd3ff, and `volt-soft` #16545a. Every text pair in the overlay's usage notes holds 4.5:1 and `rule-strong` holds 3:1 on `surface`; the accent reads as text on `surface` at better than 5:1. The brand's chartreuse appears on a Broadcast site only inside the footer credit's link underline.

## Type

Display is Archivo at weight 800 for the masthead name, story titles, and card titles; reading is Source Sans 3 at 18px on 28px with the measure at 640px; the interface stays IBM Plex Sans. All three are Google-licensed faces under the Open Font License, so the client's site carries them without a license of its own. Heliostet self-hosts them from its own copies (DS-5) and emits no font stylesheet link; the overlay's `meta.googleFonts` only records where the faces come from. Fallbacks are system serifs and sans so the page reads before the fonts arrive.

## Layout

No band: the whole page is the deep color, and the lockup slot sits top-left in on-inverse at 40px. The show block leads the front page at full width: Next, Last, and Coming up with the episode thumbnail at 1280 by 720, the watch button in the accent, and guest headshots at 800 by 800 cropped round. Story titles are in Archivo 800, uppercase at label tracking for kickers only, never for titles. The overlay says so with `type.label.textTransform`.

## Why This Look

The A teal direction drawn for the Press but never implemented, made generic: the single deep color is the client's to change, the accent is a cool sky that reads on it at 7:1 and sits nowhere near amber or red, and Archivo gives the bold sans the brief asked for without Impact's cartoon weight.
