import heliostet from '@vellumandvolt/heliostet';
import { defineConfig } from 'astro/config';

// Heliostet reads client.json for everything else, the site's address included.
export default defineConfig({
  output: 'static',
  devToolbar: { enabled: false },
  integrations: [heliostet()],
});
