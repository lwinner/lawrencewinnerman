# Your Site

This repository is your website. Everything the site shows is here as plain files: your posts, videos, and episodes, copied from where you publish them, along with your pages, your settings in `client.json`, and the code that turns them into the site. When something changes at one of your sources, the site rebuilds itself and goes live within minutes.

## What You Own

You own this repository, the Cloudflare account the site runs on, and your domain. All three are in your name and your email. Vellum & Volt keeps the site running for you, but nothing here belongs to us, and nothing here needs us. The code the site is built with is in this repository, in `vendor/`, so the site builds without any account or service of ours.

## What Vellum & Volt Can Do Here

- Write to this repository through our GitHub App, which you installed. Every change goes on a drafts branch and is merged into `main`; we never write to `main` directly, and you can see every change in the history.
- Run this repository's workflows, which build the site, check it, and publish it to your Cloudflare account.

Our App reaches this repository only: its files and its workflows. It has no access to your organization's other repositories, its members, or its settings.

## What Vellum & Volt Cannot Do

- Read your email, or sign in as you anywhere.
- Take your domain, move it, or change who owns it.
- Put anything on your site except by a change merged to `main`. The site goes live only from `main`.
- Stop your site from building or serving if we part ways. The code is here, and so is everything it reads.

## How the Site Stays Current

A small worker on your Cloudflare account checks your sources every five minutes. Substack does not answer Cloudflare, so the Check Substack workflow checks it from GitHub instead: every 30 minutes from 7 a.m. to 11 p.m. in your time zone, and hourly overnight. A new post appears within about 45 minutes in the daytime and 75 overnight. When a source changes, the Rebuild workflow brings in the new posts, merges them, and runs the Deploy workflow. The site also rebuilds once a day, whatever the checks saw. The Deploy workflow is the only way the site goes live.

## Files Up to 50 MB

Files offered on the site live at `/files/<name>`.
- **Up to 25 MB:** served with the site's pages.
- **Over 25 MB, up to 50 MB:** served from the site's own file bucket on your Cloudflare account. The Deploy workflow puts each one there.

**To make the bucket**, once:
1. In the terminal, in this repository, run `pnpm exec wrangler r2 bucket create CLIENT-site-files`.
2. In `wrangler.toml`, remove the `# ` from the start of the three lines under "The site's own file bucket."
3. Commit that change. The next deploy uses the bucket.

**Cost:** storage beyond 10 GB a month costs about 1.5 cents per GB, and nothing is charged for sending files out.

Until the bucket is there, a file over 25 MB stops the Deploy workflow, naming the file.

## How to Remove Vellum & Volt in Five Minutes

You can end our access at any time, in this order:

1. **Uninstall our GitHub App.** In GitHub, open your organization, then Settings, then GitHub Apps (under Third-party Access). Next to Vellum & Volt, choose Configure, then Uninstall.
2. **Remove us as a member.** In your organization, open People, find the Vellum & Volt member, open the menu beside it, and choose Remove from organization.
3. **Delete or roll the Cloudflare API token we used.** In Cloudflare, open My Profile, then API Tokens (or, for an account token, Manage Account, then Account API Tokens). Find the token named for this site, and choose Roll or Delete. To keep publishing from GitHub, create a token of your own and put it in this repository's `CLOUDFLARE_API_TOKEN` secret, under Settings, then Secrets and variables, then Actions.
4. **Remove the watcher's secrets, or delete the watcher.** In Cloudflare, open Workers & Pages, then the worker whose name ends in `-watcher`. Under Settings, then Variables and Secrets, delete its secrets; or, under Settings, choose Delete to remove the worker. Without it, the site still rebuilds once a day.
5. **That is all.** Your site keeps serving as it is. To keep publishing new posts, put a Cloudflare token of your own in the `CLOUDFLARE_API_TOKEN` secret, as in step 3. The copy of Heliostet the site is built with is in this repository, and nothing it needs comes from us.

## Where Things Are

- `client.json` holds your site's settings, such as your name, your sources, and the order of your pages.
- `src/content/` holds everything the site shows, as files.
- `src/content/redirects.json` lists old addresses on your domain and the pages they now go to.
- `vendor/` holds the copy of Heliostet the site is built with; `client.json` records its version and its fingerprint.
- `.github/workflows/` holds the Rebuild, Deploy, Check Substack, and Deploy the watcher workflows.
- `wrangler.toml` sets up the site on Cloudflare. `watcher/wrangler.toml` sets up the watcher; it is written from `client.json`, so change `client.json` rather than this file.
