// A Heliostet site's Worker (relay entry 91, Lawrence's ruling of October 29): the built pages are static assets, as
// before; a file in /files/ is served from the site's own R2 bucket (FILES) when the bucket has it, so files up to
// 50 MB work, past the static assets' 25 MiB. Without the bucket's binding, everything is the static assets, as before.
// It adds no script to any page (PAGE-6): it only answers requests.

const TYPES = { pdf: 'application/pdf', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', epub: 'application/epub+zip', zip: 'application/zip', png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp' };

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (env.FILES && (request.method === 'GET' || request.method === 'HEAD') && /^\/files\/[a-z0-9]+(?:-[a-z0-9]+)*\.(pdf|docx|epub|zip|png|jpg|webp)$/.test(url.pathname)) {
      const key = url.pathname.slice(1);
      const object = request.method === 'HEAD' ? await env.FILES.head(key) : await env.FILES.get(key);
      if (object) {
        const ext = /\.([a-z0-9]+)$/.exec(key)[1];
        const headers = new Headers({ 'content-type': object.httpMetadata?.contentType || TYPES[ext] || 'application/octet-stream', 'cache-control': 'public, max-age=3600', etag: object.httpEtag, 'content-length': String(object.size), 'x-content-type-options': 'nosniff' });
        return new Response(request.method === 'HEAD' ? null : object.body, { headers });
      }
    }
    return env.ASSETS.fetch(request);
  },
};
