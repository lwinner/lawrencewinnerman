// Fingerprints: the newest three IDs from each source, read as cheaply as each allows. From the
// Press's watcher (tdws-sync-watch), generalized: the addresses come from the Worker's variables
// rather than the code, the podcast feed is a source, and YouTube is read from the channel's own
// RSS feed instead of its 1.3 MB /videos page.
//
// Substack is not polled here. It refuses Cloudflare's egress with 429, so the client repository's
// substack.yml checks it from GitHub Actions (every 30 minutes by day, hourly overnight), and the watcher reports that
// job's newest run on /_heliostet/status (decision 0014; @vellumandvolt/heliostet/substack).

export type SourceName = 'youtube' | 'medium' | 'podcast';
export const SOURCE_NAMES: SourceName[] = ['youtube', 'medium', 'podcast'];

export class SourceError extends Error {
  override name = 'SourceError';
}

/** A fetch that is retried once, after `retryMs`, when the answer is 429. */
export type Get = (url: string, headers: Record<string, string>) => Promise<Response>;

const TIMEOUT = 15_000;
// Medium sometimes answers Cloudflare's egress with 429; a browser's headers help.
const BROWSER = {
  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36',
  'accept-language': 'en-US,en;q=0.9',
};

export function retryingGet(retryMs: number): Get {
  return async (url, headers) => {
    const once = () => fetch(url, { headers, signal: AbortSignal.timeout(TIMEOUT) });
    const res = await once();
    if (res.status !== 429) return res;
    await new Promise((r) => setTimeout(r, retryMs));
    return once();
  };
}

/** The first `n` distinct contents of `tag` in an XML document. */
function firstTags(xml: string, tag: string, n = 3): string[] {
  const ids: string[] = [];
  const pattern = new RegExp(`<${tag}(?:\\s[^>]*)?>\\s*(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?\\s*</${tag}>`, 'g');
  for (const m of xml.matchAll(pattern)) {
    const id = (m[1] ?? '').trim();
    if (id && !ids.includes(id)) ids.push(id);
    if (ids.length >= n) break;
  }
  return ids;
}

async function text(res: Response): Promise<string> {
  if (!res.ok) throw new SourceError(`HTTP ${res.status}`);
  return res.text();
}

/** The channel's newest uploads, from YouTube's per-channel feed. */
export async function youtube(channel: string, get: Get): Promise<string[]> {
  const id = /UC[\w-]{22}/.exec(channel)?.[0];
  if (!id) throw new SourceError('the channel is not a UC… id');
  const res = await get(`https://www.youtube.com/feeds/videos.xml?channel_id=${id}`, { 'user-agent': BROWSER['user-agent'], accept: 'application/atom+xml, application/xml' });
  return firstTags(await text(res), 'yt:videoId');
}

/** A Medium or podcast RSS feed's newest items, by guid. */
export async function feed(url: string, get: Get): Promise<string[]> {
  const res = await get(url, { ...BROWSER, accept: 'application/rss+xml, application/xml, text/xml' });
  return firstTags(await text(res), 'guid');
}

export interface SourceConfig {
  /** The Substack's address: not polled here, but its presence puts the Actions check on /status. */
  SUBSTACK?: string;
  YOUTUBE_CHANNEL?: string;
  MEDIUM_FEED?: string;
  PODCAST_FEED?: string;
}

/** The sources this site has, each with the reader that fingerprints it. */
export function configured(env: SourceConfig): Partial<Record<SourceName, (get: Get) => Promise<string[]>>> {
  const out: Partial<Record<SourceName, (get: Get) => Promise<string[]>>> = {};
  if (env.YOUTUBE_CHANNEL) out.youtube = (get) => youtube(env.YOUTUBE_CHANNEL as string, get);
  if (env.MEDIUM_FEED) out.medium = (get) => feed(env.MEDIUM_FEED as string, get);
  if (env.PODCAST_FEED) out.podcast = (get) => feed(env.PODCAST_FEED as string, get);
  return out;
}

/** Medium runs on one tick in three (every 15 minutes); the others on every tick (SITE-6). */
export const due = (name: SourceName, at: number) => name !== 'medium' || Math.floor(at / 300_000) % 3 === 0;
