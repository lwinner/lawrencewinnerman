// The watcher (SITE-6, SITE-7, SEC-7, SEC-8): a Worker in the client's Cloudflare account that
// fingerprints each source every five minutes (Medium every third tick) and, when one changes,
// starts the site's rebuild workflow on GitHub with a signed payload. Substack is the exception: it
// refuses Cloudflare's egress, so the repository's substack.yml checks it from GitHub Actions about
// every 30 minutes by day and hourly overnight and rebuilds on a change, and each tick here reads that job's newest run to
// report it (decision 0014). Public GET /_heliostet/status, a
// route on the client's own domain (relay entry 9, ruling 1), says per source ok or degraded, and
// when the watcher last checked; nothing else. The site's static page at /status links to it.
//
// From the Press's tdws-sync-watch, generalized:
// - A source that fails to fetch keeps its last fingerprint and never triggers a rebuild. A 429 is
//   retried once, about two seconds later, in the same tick.
// - New fingerprints are saved only after GitHub accepts the dispatch (204), so a failed dispatch
//   is tried again on the next tick. The first run only records; it never dispatches.
// - The sources' addresses, the repository, and the workflow are variables; the GitHub App's key
//   (or, on a site the operator owns, a token) and the signing key are secrets. Nothing is in the
//   code (SEC-8). The credential is github.ts.
// - /_heliostet/status names sources by kind, never by address, and carries no error text, no IDs, and no
//   dispatch detail, which the Press's /status did (SEC-7). It is rate limited per address.

import { signDispatch } from '@vellumandvolt/heliostet/dispatch';
import { type CheckState, checkState, lastRun } from '@vellumandvolt/heliostet/substack';
import { CredentialError, type GitHubEnv, githubToken } from './github.js';
import { configured, due, type Get, retryingGet, SOURCE_NAMES, type SourceConfig, type SourceName } from './sources.js';

export interface Env extends SourceConfig, GitHubEnv {
  /** The watcher's state: one key. */
  WATCH: KVNamespace;
  /** Sixty requests a minute per address (SEC-7). */
  STATUS_LIMIT: RateLimit;
  /** owner/name of the client repository. */
  REPO: string;
  /** The rebuild workflow's file name. */
  WORKFLOW: string;
  /** The branch the workflow runs on; main unless set. */
  BRANCH?: string;
  /** Secret: the key the dispatch is signed with; the workflow holds the same one. */
  DISPATCH_KEY?: string;
  /** Milliseconds before a 429 is retried; for tests. */
  RETRY_MS?: string;
}

interface SourceState {
  ok: boolean;
  fingerprint: string | null;
  checked: string | null;
  failures: number;
}

export interface State {
  checked: string;
  sources: Partial<Record<SourceName, SourceState>>;
  /** Sources checked from GitHub Actions: their newest run's state, and when it finished. */
  actions?: { substack?: { state: CheckState; checked: string | null } };
  /** For the operator's logs and the fleet's later use; never on /status. */
  dispatch: { at: string; status: number | null } | null;
}

const KEY = 'state';
/** The watcher's one public path (relay entry 9, ruling 1). */
const STATUS_PATH = '/_heliostet/status';
/** The address from before the rename to Heliostet (0.2.0): a permanent redirect, so nothing polling it breaks. */
const OLD_STATUS_PATH = '/_kit/status';
const UA = 'vellumandvolt-watcher';

async function dispatch(env: Env, sources: SourceName[], at: string): Promise<number | null> {
  if (!env.DISPATCH_KEY) {
    console.error('A change was seen, but DISPATCH_KEY is not set; nothing was dispatched.');
    return null;
  }
  const { payload, signature } = await signDispatch({ repo: env.REPO, sources, at }, env.DISPATCH_KEY);
  try {
    const token = await githubToken(env);
    const res = await fetch(`https://api.github.com/repos/${env.REPO}/actions/workflows/${env.WORKFLOW}/dispatches`, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${token}`,
        accept: 'application/vnd.github+json',
        'x-github-api-version': '2022-11-28',
        'user-agent': UA,
        'content-type': 'application/json',
      },
      body: JSON.stringify({ ref: env.BRANCH ?? 'main', inputs: { payload, signature } }),
      signal: AbortSignal.timeout(15_000),
    });
    return res.status;
  } catch (error) {
    console.error(error instanceof CredentialError ? `No dispatch: ${error.message}` : `The dispatch failed: ${(error as Error).message}`);
    return null;
  }
}

/**
 * Substack's row: the newest finished run of the repository's substack.yml, read with the
 * watcher's own GitHub credential (Actions: read). When GitHub cannot be read, the last state
 * stands, so one failed read does not change the row.
 */
async function substackCheck(env: Env, at: number, last: NonNullable<State['actions']>['substack']): Promise<{ state: CheckState; checked: string | null }> {
  try {
    const run = await lastRun(env.REPO, await githubToken(env), { branch: env.BRANCH ?? 'main', userAgent: UA });
    return { state: checkState(run, at), checked: run?.at ?? null };
  } catch (error) {
    console.error(`substack: the Actions check could not be read: ${(error as Error).message}`);
    return last ?? { state: 'pending', checked: null };
  }
}

async function tick(env: Env, at: number, get: Get = retryingGet(Number(env.RETRY_MS ?? 2000))): Promise<State> {
  const now = new Date(at).toISOString();
  const prev = await env.WATCH.get<State>(KEY, 'json');
  const readers = configured(env);
  const names = SOURCE_NAMES.filter((n) => readers[n]);
  // A source with no state yet runs on any tick, so there is always a state to carry over.
  const run = names.filter((n) => due(n, at) || !prev?.sources[n]);
  const results = await Promise.allSettled(run.map((n) => (readers[n] as (g: Get) => Promise<string[]>)(get)));

  const sources: State['sources'] = {};
  const changed: SourceName[] = [];
  for (const name of names) {
    const old = prev?.sources[name];
    const i = run.indexOf(name);
    if (i < 0) {
      if (old) sources[name] = old;
      continue;
    }
    const r = results[i];
    if (r?.status === 'fulfilled' && r.value.length > 0) {
      const fingerprint = r.value.join('|');
      if (old?.fingerprint && old.fingerprint !== fingerprint) changed.push(name);
      sources[name] = { ok: true, fingerprint, checked: now, failures: 0 };
    } else {
      const reason = r?.status === 'rejected' ? String((r.reason as Error)?.message ?? r.reason) : 'empty response';
      console.error(`${name}: ${reason}`);
      sources[name] = { ok: false, fingerprint: old?.fingerprint ?? null, checked: now, failures: (old?.failures ?? 0) + 1 };
    }
  }

  const state: State = { checked: now, sources, dispatch: prev?.dispatch ?? null };
  if (env.SUBSTACK) state.actions = { substack: await substackCheck(env, at, prev?.actions?.substack) };
  if (!prev) {
    console.log('First run: fingerprints recorded, no dispatch.');
  } else if (changed.length) {
    const status = await dispatch(env, changed, now);
    state.dispatch = { at: now, status };
    if (status === 204) {
      console.log(`Change at ${changed.join(', ')}: rebuild dispatched.`);
    } else {
      // Keep the old fingerprints so the next tick sees the change again and tries again.
      for (const name of changed) {
        const s = state.sources[name];
        if (s) s.fingerprint = prev.sources[name]?.fingerprint ?? null;
      }
      console.error(`Change at ${changed.join(', ')}, but the dispatch was not accepted (${status ?? 'no answer'}).`);
    }
  }
  await env.WATCH.put(KEY, JSON.stringify(state));
  return state;
}

type PublicStatus = {
  checked: string | null;
  sources: Record<string, 'ok' | 'degraded'>;
  /** Checked from GitHub Actions, not from the edge: Heliostet's state and when the run finished. */
  actions?: { substack: { state: CheckState; checked: string | null } };
};

/**
 * The public status (SEC-7): per edge source ok or degraded, and when the watcher last checked;
 * and, under `actions`, Substack's check from GitHub Actions in Heliostet's states (OK, Warning,
 * Problem, or Pending) with when its newest run finished.
 */
function publicStatus(state: State | null): PublicStatus {
  if (!state) return { checked: null, sources: {} };
  const sources: Record<string, 'ok' | 'degraded'> = {};
  for (const name of SOURCE_NAMES) {
    const s = state.sources[name];
    if (s) sources[name] = s.ok ? 'ok' : 'degraded';
  }
  const substack = state.actions?.substack;
  return substack ? { checked: state.checked, sources, actions: { substack: { state: substack.state, checked: substack.checked } } } : { checked: state.checked, sources };
}

const HEADERS = { 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'access-control-allow-origin': '*' };

export default {
  async scheduled(event: ScheduledController, env: Env, ctx: ExecutionContext) {
    ctx.waitUntil(tick(env, event.scheduledTime).then(() => undefined));
  },

  async fetch(request: Request, env: Env): Promise<Response> {
    const address = request.headers.get('cf-connecting-ip') ?? 'unknown';
    const { success } = await env.STATUS_LIMIT.limit({ key: address });
    if (!success) return new Response('Too many requests\n', { status: 429, headers: { ...HEADERS, 'retry-after': '60', 'content-type': 'text/plain' } });
    const { pathname } = new URL(request.url);
    if (pathname === OLD_STATUS_PATH) return new Response(null, { status: 301, headers: { ...HEADERS, location: STATUS_PATH } });
    if (pathname !== STATUS_PATH) return new Response('Not found\n', { status: 404, headers: { ...HEADERS, 'content-type': 'text/plain' } });
    if (request.method !== 'GET' && request.method !== 'HEAD') return new Response('Method not allowed\n', { status: 405, headers: { ...HEADERS, allow: 'GET, HEAD', 'content-type': 'text/plain' } });
    return Response.json(publicStatus(await env.WATCH.get<State>(KEY, 'json')), { headers: HEADERS });
  },
} satisfies ExportedHandler<Env>;
