// The watcher's GitHub credential (relay entry 9, ruling 2; DOOR-1). A client site's watcher holds
// no long-lived GitHub token: it holds the Vellum & Volt GitHub App's private key as a Worker
// secret and mints a one-hour installation token for the client's repository when it needs one,
// keeping it in memory until five minutes before it expires. A fine-grained token is allowed only on
// a site the operator owns (the record's operatorOwned, which heliostet-watcher-vars turns into
// GITHUB_CREDENTIAL = "token" and OPERATOR_OWNED = "true"): vellumandvolt.com, the Press, and the
// personal site.

export interface GitHubEnv {
  /** "app" (the default) or "token". */
  GITHUB_CREDENTIAL?: string;
  /** "true" only when the record says operatorOwned. */
  OPERATOR_OWNED?: string;
  /** Secret, operator-owned sites only: a fine-grained token (Actions: read and write, one repository). */
  GITHUB_TOKEN?: string;
  /** The App's ID. */
  GITHUB_APP_ID?: string;
  /** The App's installation on the client's repository. */
  GITHUB_APP_INSTALLATION_ID?: string;
  /** Secret: the App's private key, as GitHub gives it (PKCS#1) or as PKCS#8, in PEM. */
  GITHUB_APP_PRIVATE_KEY?: string;
}

export class CredentialError extends Error {
  override name = 'CredentialError';
}

const UA = 'vellumandvolt-watcher';
/** A cached token is used until this long before it expires. */
export const TOKEN_MARGIN_MS = 5 * 60 * 1000;

let cached: { key: string; token: string; expires: number } | null = null;

const encoder = new TextEncoder();
const base64url = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const base64urlText = (text: string) => base64url(encoder.encode(text));

/** A DER length. */
function derLength(n: number): number[] {
  if (n < 0x80) return [n];
  const bytes: number[] = [];
  for (let v = n; v > 0; v >>= 8) bytes.unshift(v & 0xff);
  return [0x80 | bytes.length, ...bytes];
}

/** The PKCS#8 wrapping of a PKCS#1 RSA key: SEQUENCE { 0, rsaEncryption, OCTET STRING key }. */
function pkcs1ToPkcs8(pkcs1: Uint8Array): Uint8Array {
  const algorithm = [0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01, 0x05, 0x00];
  const octets = [0x04, ...derLength(pkcs1.length)];
  const body = [0x02, 0x01, 0x00, ...algorithm, ...octets];
  const out = new Uint8Array(1 + derLength(body.length + pkcs1.length).length + body.length + pkcs1.length);
  out.set([0x30, ...derLength(body.length + pkcs1.length), ...body]);
  out.set(pkcs1, out.length - pkcs1.length);
  return out;
}

async function signingKey(pem: string): Promise<CryptoKey> {
  const pkcs1 = /-----BEGIN RSA PRIVATE KEY-----/.test(pem);
  if (!pkcs1 && !/-----BEGIN PRIVATE KEY-----/.test(pem)) throw new CredentialError('GITHUB_APP_PRIVATE_KEY is not a PEM private key.');
  const der = Uint8Array.from(atob(pem.replace(/-----[A-Z ]+-----/g, '').replace(/\s+/g, '')), (c) => c.charCodeAt(0));
  return crypto.subtle.importKey('pkcs8', pkcs1 ? pkcs1ToPkcs8(der) : der, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
}

/** The App's JSON Web Token: RS256, issued a minute ago for clock drift, good for nine minutes. */
export async function appJwt(appId: string, pem: string, now = Date.now()): Promise<string> {
  const iat = Math.floor(now / 1000) - 60;
  const head = `${base64urlText(JSON.stringify({ alg: 'RS256', typ: 'JWT' }))}.${base64urlText(JSON.stringify({ iat, exp: iat + 600, iss: appId }))}`;
  const signature = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', await signingKey(pem), encoder.encode(head));
  return `${head}.${base64url(new Uint8Array(signature))}`;
}

/** The token the dispatch is sent with. Throws a CredentialError when the watcher has none it may use. */
export async function githubToken(env: GitHubEnv): Promise<string> {
  if (env.GITHUB_CREDENTIAL === 'token') {
    if (env.OPERATOR_OWNED !== 'true') throw new CredentialError('A fine-grained GitHub token is allowed only on a site the operator owns; a client site uses the GitHub App.');
    if (!env.GITHUB_TOKEN) throw new CredentialError('GITHUB_TOKEN is not set.');
    return env.GITHUB_TOKEN;
  }
  const { GITHUB_APP_ID: appId, GITHUB_APP_INSTALLATION_ID: installation, GITHUB_APP_PRIVATE_KEY: pem } = env;
  if (!appId || !installation || !pem) throw new CredentialError('GITHUB_APP_ID, GITHUB_APP_INSTALLATION_ID, and GITHUB_APP_PRIVATE_KEY must all be set.');
  const key = `${appId}/${installation}`;
  if (cached?.key === key && cached.expires - TOKEN_MARGIN_MS > Date.now()) return cached.token;
  const res = await fetch(`https://api.github.com/app/installations/${encodeURIComponent(installation)}/access_tokens`, {
    method: 'POST',
    headers: { authorization: `Bearer ${await appJwt(appId, pem)}`, accept: 'application/vnd.github+json', 'x-github-api-version': '2022-11-28', 'user-agent': UA },
    signal: AbortSignal.timeout(15_000),
  });
  if (res.status !== 201) throw new CredentialError(`GitHub did not issue an installation token (${res.status}).`);
  const body = (await res.json()) as { token?: string; expires_at?: string };
  const expires = Date.parse(body.expires_at ?? '');
  if (!body.token || Number.isNaN(expires)) throw new CredentialError('GitHub’s answer carried no token.');
  cached = { key, token: body.token, expires };
  return body.token;
}
