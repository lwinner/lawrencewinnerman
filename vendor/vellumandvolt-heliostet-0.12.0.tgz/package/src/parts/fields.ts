// The kinds of field a part is made of (decision 0017, relay entry 52). Each field says what it
// holds, whether it's required, its limits, and a line of help written for the person filling it
// in, not for a developer. The composer draws its form from these, and validatePart checks a part
// against them, so the two can never disagree about what a part needs.

/** Every field shares a label, its help, and whether a part can go live without it. */
interface Base {
  /** The field's name in the form, in sentence case: "Tagline." */
  label: string;
  /** One plain line for the person filling it in. */
  help: string;
  required?: boolean;
  /** The looks that use it, when not all do: the Page Builder shows it only under those (relay entry 99). */
  only?: readonly string[];
}

/** One line of plain text, up to a length. */
export interface TextField extends Base {
  kind: 'text';
  max: number;
}

/** Written text with headings, links, lists, and emphasis, cleaned by the one sanitizer (0004). */
export interface RichField extends Base {
  kind: 'rich';
  max: number;
}

/** Somewhere to go: a page on the site ("/work") or an address ("https://…", "mailto:…"). */
export interface LinkField extends Base {
  kind: 'link';
}

/** A picture: its file and a description of it for people who can't see it, which is required. */
export interface ImageField extends Base {
  kind: 'image';
}

/** A file to download, such as a PDF or the mark's files. */
export interface FileField extends Base {
  kind: 'file';
  /** The file types it takes, by extension: ["pdf"]. */
  types: readonly string[];
}

/** One of a short list. */
export interface ChoiceField extends Base {
  kind: 'choice';
  options: readonly { value: string; label: string }[];
}

/** A whole number within limits. */
export interface NumberField extends Base {
  kind: 'number';
  min: number;
  max: number;
}

/** A calendar day, as 2026-10-23. */
export interface DateField extends Base {
  kind: 'date';
}

/** A box to tick: yes or no. A required one must be ticked (a quote's permission). */
export interface YesField extends Base {
  kind: 'yes';
}

/** A short list of one-line entries: a person's roles, a story's topics. */
export interface ListField extends Base {
  kind: 'list';
  min: number;
  max: number;
  /** Each entry's length limit. */
  each: number;
}

/** The same few fields, repeated: doors, services, products, links. */
export interface GroupField extends Base {
  kind: 'group';
  min: number;
  max: number;
  /** What one entry is called, for messages: "door" gives "The third door needs…". */
  one: string;
  fields: Record<string, Field>;
}

/** Which items a part shows from the site's own content: where from, filtered, how many, in what order. */
export interface QueryField extends Base {
  kind: 'query';
  sources: readonly QuerySource[];
  filters: readonly QueryFilter[];
  maxCount: number;
}

export type QuerySource = 'stories' | 'chapters' | 'episodes' | 'videos';
/** tag: a card tag the site's drawing rules set, by its label (relay entry 125: the Press's Friday episodes). */
export type QueryFilter = 'outlet' | 'topic' | 'series' | 'byline' | 'tag';
export type QuerySort = 'newest' | 'oldest' | 'order';

export type Field = TextField | RichField | LinkField | ImageField | FileField | ChoiceField | NumberField | DateField | YesField | ListField | GroupField | QueryField;
export type Schema = Record<string, Field>;

/** The value an image field holds: the file, and what it shows. */
export interface ImageValue {
  src: string;
  alt: string;
}

/** The value a file field holds: the file, and what to call it. */
export interface FileValue {
  src: string;
  label: string;
}

/** The value a query field holds. */
export interface QueryValue {
  source: QuerySource;
  filters?: Partial<Record<QueryFilter, string>>;
  count: number;
  sort: QuerySort;
  /** How many to pass over first, such as the one a page features above the list (relay entry 55). */
  skip?: number;
}

/** A field the named looks use and the others don't (relay entry 99): "In pricing, its price." */
export const onlyIn = <F extends Base>(looks: readonly string[], f: F): F => ({ ...f, only: looks });

export const text = (label: string, max: number, help: string, required = false): TextField => ({ kind: 'text', label, max, help, required });
export const rich = (label: string, max: number, help: string, required = false): RichField => ({ kind: 'rich', label, max, help, required });
export const link = (label: string, help: string, required = false): LinkField => ({ kind: 'link', label, help, required });
export const image = (label: string, help: string, required = false): ImageField => ({ kind: 'image', label, help, required });
export const file = (label: string, types: readonly string[], help: string, required = false): FileField => ({ kind: 'file', label, types, help, required });
export const choice = (label: string, options: readonly (readonly [string, string])[], help: string, required = false): ChoiceField => ({ kind: 'choice', label, options: options.map(([value, l]) => ({ value, label: l })), help, required });
export const number = (label: string, min: number, max: number, help: string, required = false): NumberField => ({ kind: 'number', label, min, max, help, required });
export const date = (label: string, help: string, required = false): DateField => ({ kind: 'date', label, help, required });
export const yes = (label: string, help: string, required = false): YesField => ({ kind: 'yes', label, help, required });
export const list = (label: string, min: number, max: number, each: number, help: string, required = false): ListField => ({ kind: 'list', label, min, max, each, help, required });
export const group = (label: string, one: string, min: number, max: number, fields: Record<string, Field>, help: string): GroupField => ({ kind: 'group', label, one, min, max, fields, help, required: min > 0 });
export const query = (label: string, sources: readonly QuerySource[], filters: readonly QueryFilter[], maxCount: number, help: string, required = false): QueryField => ({ kind: 'query', label, sources, filters, maxCount, help, required });
