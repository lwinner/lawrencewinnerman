// Merch: products from a store the person owns, from the store's own public product list (MER-1).
// Each card links out to the product on the store; the site holds no cart and no checkout.
import { choice, group, link, text } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const merch: PartDefinition = {
  type: 'merch',
  name: 'Merch',
  what: 'Products from your store, each linking to it.',
  schema: {
    store: text('Store', 60, 'Which of your stores, by its name on your record: alpacalunch.', true),
    heading: text('Heading', 60, 'The heading: From the Shop.'),
    line: text('One line', 200, 'A line about the store. Optional.'),
    products: group('Products', 'product', 0, 8, {
      handle: text('Product', 160, 'The product’s handle, the last part of its address on the store.', true),
    }, 'Up to eight products, in the order you want them. Or name a collection instead.'),
    moreLink: link('More link', 'Where the whole shop is, and the words on the link: The whole shop. On a teaser, each product links there too. Optional.'),
    collection: text('Collection', 160, 'A collection’s handle, to show its products instead of picking them.'),
    whenSoldOut: choice('When one sells out', [['skip', 'Skip it'], ['next', 'Show the next one'], ['hide', 'Hide the whole part']], 'What happens when a product sells out.', true),
  },
  variants: [
    { id: 'cards', label: 'Cards' },
    { id: 'sidebar-list', label: 'Sidebar list' },
    { id: 'band', label: 'Band' },
    { id: 'teaser', label: 'Teaser: four products under the heading and its link, each to the site’s shop page' },
  ],
  component: 'merch/Merch.astro',
  fixtures: [
    {
      type: 'merch',
      variant: 'cards',
      fields: {
        store: 'alpacalunch',
        heading: 'From the Shop',
        line: 'Tees and mugs from alpacalunch, my shop for rebels, ranters, and smartasses.',
        products: [{ handle: 'unisex-t-shirt-4' }, { handle: 'queer-as-a-three-dollar-bill-dryblend®-t-shirt' }, { handle: 'white-glossy-mug' }],
        whenSoldOut: 'skip',
      },
    },
  ],
  check: (f) => (!(Array.isArray(f.products) && f.products.length) && !f.collection ? [{ field: 'products', message: 'Pick at least one product, or name a collection.' }] : []),
};
