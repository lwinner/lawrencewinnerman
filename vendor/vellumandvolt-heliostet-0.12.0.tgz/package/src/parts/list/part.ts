// List: any feed of the site's own items, newest first or in order, with an optional filter bar
// and a link to the rest.
import { choice, group, link, query, text, yes } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const listPart: PartDefinition = {
  type: 'list',
  name: 'List',
  what: 'Any feed of items: stories, chapters, episodes, or videos.',
  schema: {
    heading: text('Heading', 60, 'The list’s heading: Just Published.'),
    query: query('What it lists', ['stories', 'chapters', 'episodes', 'videos'], ['outlet', 'topic', 'series', 'byline', 'tag'], 99, 'Where the items come from, which ones, how many, and in what order.', true),
    filterBar: yes('Filter bar', 'Show a row of outlets and topics a reader can pick from.'),
    featureFirst: yes('Feature the first', 'In cards, the first item runs the full width, with the rest two across.'),
    moreLink: link('More link', 'Where to see all of them, and the words on the link. Optional.'),
    // The front page's top (relay entry 125): the lead's kicker and line, and its side column.
    kicker: text('Lead’s tag', 40, 'On a front, the tag above the lead story: Front Page. Optional.'),
    leadLine: text('Lead’s line', 60, 'On a front, the words beside the tag: Unhinged but Accurate. Optional.'),
    sideEyebrow: text('Side kicker', 80, 'On a front, the kicker over the side’s show: The Daily Whatever Show · Live. Optional.'),
    sideTitle: text('Side title', 60, 'On a front, the side’s show title: Fucked-Up Friday. Optional.'),
    sideShow: text('Side’s show', 80, 'On a front, the show, as the shows feed names it, whose next date and guests the side shows. Optional.'),
    sideTime: text('Side’s time', 30, 'On a front, the show’s time when the feed has none: 10 am ET. Optional.'),
    sideCopy: text('Side copy', 300, 'On a front, the side’s words when no guest is booked. Optional.'),
    sideAction: link('Side button', 'On a front, the side’s button, and its words. Optional.'),
    episodeTag: text('Episodes’ tag', 40, 'On shows, the card tag that marks the show’s episodes: Friday. Optional.'),
    peopleLabel: text('People label', 40, 'On a front, the label over the site’s people: The Hosts. Optional.'),
    clock: choice('Times', [['am', '10 am'], ['a.m.', '10 a.m.']], 'How a front writes a show’s time.'),
    moreButton: text('More button', 40, 'On a band, a button under the cards to the More link, and its words: More from the Press. Optional.'),
    // Relay entry 59: a page's own list, and a person's.
    eyebrow: text('Kicker', 60, 'A word or two above the heading, on an index. Optional.'),
    filters: group('Filter row', 'link', 0, 8, { link: link('Link', 'Where it goes, and its words.', true), current: yes('This page', 'The link to the page this list is on: it shows as the current one.') }, 'Links to the lists a reader can switch to, on an index. Optional.'),
    filterPeople: yes('People in the filter row', 'Each person with a page, by first name, after the first link, in the site’s order.'),
    hideBylines: yes('Leave off the bylines', 'For a list of one person’s stories, where every byline is theirs.'),
  },
  variants: [
    { id: 'cards', label: 'Cards' },
    { id: 'rows', label: 'Rows' },
    { id: 'numbered', label: 'Numbered' },
    { id: 'grouped', label: 'Grouped' },
    // Relay entry 59: the Press's Latest and its host pages' lists, drawn in its look.
    { id: 'index', label: 'Index: the page’s heading, a filter row, story cards, and the pager, for a page that lists everything' },
    { id: 'shows', label: 'Shows: a show’s next date and guests, its last episode, and the weeks coming up' },
    { id: 'front', label: 'Front: the lead story large, beside a show’s next date and guests and the site’s people' },
    { id: 'episodes', label: 'Episodes: three across, each with its date and guests' },
    { id: 'band', label: 'Band: a heading and its link over story cards, and a button to the rest' },
    { id: 'section', label: 'Section: a heading with the count, story cards, and the pager, for a list within a page' },
  ],
  component: 'list/List.astro',
  fixtures: [
    {
      type: 'list',
      variant: 'cards',
      fields: {
        heading: 'Just Published',
        query: { source: 'stories', count: 3, sort: 'newest' },
        filterBar: false,
        moreLink: { to: '/writing', label: 'All my writing' },
      },
    },
  ],
};
