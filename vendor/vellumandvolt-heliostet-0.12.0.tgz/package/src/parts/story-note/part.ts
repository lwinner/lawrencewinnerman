// Story note: the host's note for one piece, indexed on the site, with the way on to the full text.
import { date, image, link, list, rich, text } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const storyNote: PartDefinition = {
  type: 'story-note',
  name: 'Story Note',
  what: 'The host’s note for one piece, and the way on to it.',
  schema: {
    headline: text('Headline', 140, 'The piece’s headline, as published.', true),
    dek: text('Dek', 300, 'The line under the headline.'),
    date: date('Date', 'The day the piece was published.', true),
    outlet: text('Outlet', 80, 'Where it was published: The Hinge & The Near Field.', true),
    leadImage: image('Lead image', 'The piece’s picture. Describe it.'),
    note: rich('Your note', 6000, 'A few paragraphs on why you wrote it.', true),
    readOn: link('Read on', 'The full piece’s address, where readers go next.', true),
    topics: list('Topics', 0, 8, 40, 'A few topics, a word or two each.'),
    // The story page (relay entry 125): the words around a story on its own page, the same for every story.
    kicker: text('Kicker', 60, 'On a story page, the words beside its tags: Unhinged but Accurate. Optional.'),
    disclosureLine: text('Disclosure line', 160, 'On a story page, the line under its tags when it carries the disclosure. Optional.'),
    sourcesHeading: text('Sources heading', 40, 'On a story page, the heading over its sources: Receipts. Optional.'),
    sourcesElsewhere: text('No sources here', 80, 'On a story page with none, where they are: Receipts Are on the Substack Original. Optional.'),
    continueLabel: text('Continue reading', 60, 'On a story page with only part of it here, the button to the rest: Continue Reading on Substack. Optional.'),
    moreHeading: text('More heading', 60, 'On a story page, the heading over three more stories: More From the Press. Optional.'),
    shopHeading: text('Shop heading', 60, 'On a story page, the heading over a product from the shop. Optional.'),
    watchHeading: text('Watch heading', 60, 'On a story page, the heading over the newest video. Optional.'),
    watchFrom: text('Watch line', 60, 'On a story page, the words under the newest video: TDWS on YouTube. Optional.'),
  },
  variants: [{ id: 'note', label: 'Note' }, { id: 'page', label: 'Story page' }],
  component: 'story-note/StoryNote.astro',
  fixtures: [
    {
      type: 'story-note',
      fields: {
        headline: 'World War Three Is Here. We’re Still Arguing About the Start Date.',
        dek: 'Ukraine. Iran. Sabotage in Europe. The next world war may already be underway—and Trump is making America’s promises impossible to trust.',
        date: '2026-10-20',
        outlet: 'The Hinge & The Near Field',
        leadImage: { src: '/gallery/world-war-three-started.jpg', alt: 'A quiz card asking when World War III began, with every answer checked' },
        note: '## Why I wrote it\n\nThe Financial Times asked whether we’re sleepwalking into World War III, and its answer was that the line hasn’t been crossed yet. I think it’s drawn in the wrong place. Nobody in 1937 had a name for what they were living through, and the Second World War still has no agreed-upon birthday.\n\nI lay out the rhythm that came before 1914 and 1939, then set our own sequence beside it, from Georgia to Ukraine, Gaza, and Iran. The wiring today is the supply chain, not a set of treaties. What we still get to decide is how bad it gets.',
        readOn: { to: 'https://lwinner.substack.com', label: 'Read on Substack' },
        topics: ['World', 'World War III', 'Democracy and Power'],
      },
    },
  ],
};
