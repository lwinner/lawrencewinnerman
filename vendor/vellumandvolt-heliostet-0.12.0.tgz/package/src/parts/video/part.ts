// Video: one video, picked or the newest. A YouTube video plays in place, behind the same play
// facade the Press's episode block uses; a video uploaded to Substack shows its cover and
// "Watch on Substack," because Substack's feed carries only its audio.
import { choice, link, text } from '../fields.js';
import type { PartDefinition } from '../types.js';

export const video: PartDefinition = {
  type: 'video',
  name: 'Video',
  what: 'One video, or the newest.',
  schema: {
    heading: text('Heading', 60, 'A heading above the video: Watch. Optional.'),
    moreLink: link('More link', 'Where to see every video, and the words on the link: All my videos. Optional.'),
    source: choice('Which video', [['picked', 'One I pick'], ['newest-videos', 'The newest of my videos'], ['newest-episodes', 'The show’s newest episode']], 'Pick one video, or always show the newest.', true),
    // Named by its source's ID, so it survives a page moving (relay entry 53).
    video: text('The video', 120, 'The video you picked, by its ID where it lives: its YouTube ID, or its Substack post’s address name.'),
    caption: text('Caption', 200, 'A line under the video. Optional.'),
  },
  variants: [
    { id: 'inline', label: 'Inline' },
    { id: 'band', label: 'Band: the channel’s three newest videos under the heading and its link' },
    { id: 'featured', label: 'Featured' },
    { id: 'sidebar', label: 'Sidebar' },
  ],
  component: 'video/Video.astro',
  fixtures: [
    { type: 'video', variant: 'inline', fields: { heading: 'Watch', moreLink: { to: '/videos', label: 'All my videos' }, source: 'picked', video: 'the-irkutsk-mystery', caption: 'Live on The Hinge & The Near Field.' } },
    { type: 'video', variant: 'inline', fields: { source: 'newest-episodes' } },
  ],
  check: (f) => (f.source === 'picked' && !f.video ? [{ field: 'video', message: 'Pick the video to show.' }] : []),
};
