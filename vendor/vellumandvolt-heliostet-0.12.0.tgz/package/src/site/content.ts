// The site's own content as parts draw it (relay entry 53): the mirrored stories, videos, and
// episodes the build already resolves, the chapters of a serialized book, and the stores on the
// record. A collection's page is its template with one part bound to the item: a story note, a
// chapter reader, or a featured video whose fields come from the item instead of the file.

import { DEFAULT_DRAWING, drawItem, type Drawing } from './drawing.js';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { z } from 'zod';
import { plainText } from '../build/sanitize.js';
import type { SitePage } from '../build/resolve.js';
import type { ContentItem, ShopifyProduct, Store } from '../parts/types.js';
import { address, type Collection, type CollectionsFile } from './schema.js';

/** A chapter of a serialized book, as a file in src/content/chapters/, until the ingest writes them. */
export const chapterSchema = z.strictObject({
  slug: z.string().regex(/^[a-z0-9-]+$/),
  series: z.string().min(1),
  book: z.string().min(1),
  bookSlug: z.string().regex(/^[a-z0-9-]+$/),
  number: z.number().int().min(0).optional(),
  title: z.string().min(1),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  placeAndDate: z.string().optional(),
  /** Markdown. */
  opening: z.string().min(1),
  publication: z.string().optional(),
  readOn: z.strictObject({ to: z.string(), label: z.string().optional() }),
});
export type ChapterFile = z.infer<typeof chapterSchema>;

export const CHAPTERS_DIR = 'src/content/chapters/';
export const STORES_DIR = 'src/content/stores/';

/** One item of a collection: its page address, what parts list, and its bound fields. */
export interface CollectionEntry {
  collection: Collection;
  slug: string;
  address: string;
  /** Its address before the collection moved it, when collections.json says where that was. */
  previously?: string;
  /** The route's parameters: slug, and book for a chapter. */
  params: Record<string, string>;
  item: ContentItem;
  fields: Record<string, unknown>;
}

export function readChapters(root: URL): ChapterFile[] {
  const dir = new URL(CHAPTERS_DIR, root);
  if (!existsSync(dir)) return [];
  return readdirSync(dir)
    .filter((f) => f.endsWith('.json'))
    .sort()
    .map((f) => {
      const parsed = chapterSchema.safeParse(JSON.parse(readFileSync(new URL(f, dir), 'utf8')));
      if (!parsed.success) throw new Error(`${CHAPTERS_DIR}${f} doesn’t match a chapter: ${parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ')}`);
      return parsed.data;
    });
}

/** The stores the record names, each with the product list the store sync saved (src/content/stores/<name>.json). */
export function readStores(root: URL, stores: { name: string; url: string }[]): Store[] {
  return stores.map((s) => {
    const file = new URL(`${STORES_DIR}${s.name}.json`, root);
    const products = existsSync(file) ? ((JSON.parse(readFileSync(file, 'utf8')) as { products?: ShopifyProduct[] }).products ?? []) : [];
    return { name: s.name, url: s.url, products };
  });
}

const fill = (pattern: string, values: Record<string, string>) => pattern.replace(/\{(\w+)\}/g, (_, k: string) => values[k] ?? '');
const day = (iso: string) => iso.slice(0, 10);

/** Every item of every collection the site defines, with its address and bound fields. */
export function collectionEntries(resolved: SitePage[], chapters: ChapterFile[], collections: CollectionsFile, siteName: string): CollectionEntry[] {
  const entries: CollectionEntry[] = [];
  const stories = collections.stories;
  if (stories) {
    for (const page of resolved.filter((p) => p.item.kind === 'story' && !p.noindex)) {
      const { item } = page;
      const at = fill(stories.address, { slug: item.slug });
      const outlet = item.source === 'medium' ? 'Medium' : siteName;
      const first = plainText(item.body.html).split(/\n\s*\n/)[0]?.trim() ?? '';
      entries.push({
        collection: 'stories',
        slug: item.slug,
        address: at,
        params: { slug: item.slug },
        item: { id: item.id, kind: 'story', sourceId: item.slug, title: item.title, dek: item.dek, date: item.date, readMinutes: item.readMinutes, sourceUrl: item.sourceUrl, outlet, href: at, topics: item.tags, byline: item.author.name, bylines: item.bylines.map((b) => b.name), people: item.bylines.flatMap((b) => (b.principal ? [b.principal] : [])), ...(item.cover?.src ? { image: { src: item.cover.src, alt: item.cover.alt || item.title } } : {}) },
        fields: {
          headline: item.title,
          ...(item.dek ? { dek: item.dek } : {}),
          date: day(item.date),
          outlet,
          ...(item.cover?.src ? { leadImage: { src: item.cover.src, alt: item.cover.alt || item.title } } : {}),
          note: item.dek || first || item.title,
          readOn: { to: item.sourceUrl },
          topics: item.tags.slice(0, 8),
        },
      });
    }
  }
  const videos = collections.videos;
  if (videos) {
    for (const page of resolved.filter((p) => p.item.kind === 'video' && p.item.video && !p.noindex)) {
      const { item } = page;
      const at = fill(videos.address, { slug: item.slug });
      const id = item.video!.id;
      entries.push({
        collection: 'videos',
        slug: item.slug,
        address: at,
        params: { slug: item.slug },
        item: { id: item.id, kind: 'video', sourceId: id, title: item.title, dek: item.dek, date: item.date, outlet: siteName, href: at, video: { host: 'youtube', id }, ...(item.video!.poster ? { image: { src: item.video!.poster, alt: '' } } : {}) },
        fields: { source: 'picked', video: id },
      });
    }
  }
  const chapterCollection = collections.chapters;
  if (chapterCollection) {
    for (const c of chapters) {
      const at = fill(chapterCollection.address, { slug: c.slug, book: c.bookSlug });
      entries.push({
        collection: 'chapters',
        slug: c.slug,
        address: at,
        params: { slug: c.slug, book: c.bookSlug },
        item: { id: `chapter:${c.slug}`, kind: 'chapter', sourceId: c.slug, title: c.number === undefined ? c.title : `${c.number}. ${c.title}`, date: `${c.date}T12:00:00.000Z`, outlet: siteName, href: at, series: c.series, book: c.book },
        fields: {
          series: c.series,
          book: c.book,
          ...(c.number === undefined ? {} : { number: c.number }),
          title: c.title,
          ...(c.placeAndDate ? { placeAndDate: c.placeAndDate } : {}),
          opening: c.opening,
          ...(c.publication ? { publication: c.publication } : {}),
          readOn: c.readOn,
          index: { source: 'chapters', filters: { series: c.series }, count: 99, sort: 'oldest' },
        },
      });
    }
    // Each chapter links to the chapters either side of it in its series.
    const bySeries = new Map<string, CollectionEntry[]>();
    for (const e of entries.filter((x) => x.collection === 'chapters')) bySeries.set(e.item.series ?? '', [...(bySeries.get(e.item.series ?? '') ?? []), e]);
    for (const list of bySeries.values()) {
      list.sort((a, b) => a.item.date.localeCompare(b.item.date));
      list.forEach((e, i) => {
        const prev = list[i - 1];
        const next = list[i + 1];
        if (prev) e.fields.previous = { to: prev.address, label: prev.item.title.replace(/^(\d+)\.\s*/, 'Chapter $1: ') };
        if (next) e.fields.next = { to: next.address, label: next.item.title.replace(/^(\d+)\.\s*/, 'Chapter $1: ') };
      });
    }
  }
  for (const e of entries) {
    const before = collections[e.collection]?.previously;
    if (before) e.previously = fill(before, { slug: e.slug, book: (e.params.book as string | undefined) ?? '' });
    if (!address.safeParse(e.address).success) throw new Error(`The ${e.collection} item ${e.slug} would be at ${e.address}, which isn’t an address.`);
  }
  return entries;
}

/** What parts list from: every collection item, and the site's other items that have no collection. */
export function partItems(resolved: SitePage[], entries: CollectionEntry[], siteName: string, drawing: Drawing = DEFAULT_DRAWING): ContentItem[] {
  const listed = new Set(entries.map((e) => e.item.id));
  const others: ContentItem[] = resolved
    .filter((p) => !listed.has(p.item.id) && !p.noindex)
    .map((p) => {
      const { item } = p;
      const kind = item.kind === 'story' ? 'story' : item.kind === 'episode' ? 'episode' : 'video';
      const image = item.video?.poster || item.cover?.src;
      return {
        id: item.id,
        kind,
        sourceId: item.video?.id ?? item.slug,
        title: item.title,
        dek: item.dek,
        date: item.date,
        readMinutes: item.readMinutes,
        sourceUrl: item.sourceUrl,
        outlet: siteName,
        href: p.path,
        topics: item.tags,
        byline: item.author.name,
        bylines: item.bylines.map((b) => b.name),
        people: item.bylines.flatMap((b) => (b.principal ? [b.principal] : [])),
        ...(image ? { image: { src: image, alt: item.cover?.alt ?? '' } } : {}),
        ...(item.video ? { video: { host: 'youtube' as const, id: item.video.id } } : {}),
      };
    });
  // Each item as the site draws it (relay entry 59): one place, so every part agrees.
  const sources = new Map(resolved.map((p) => [p.item.id, p.item]));
  return [...entries.map((e) => e.item), ...others].map((i) => drawItem(i, sources.get(i.id), drawing, siteName));
}
