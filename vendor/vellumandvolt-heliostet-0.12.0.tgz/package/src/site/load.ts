// Reading a site's site/ folder (relay entry 53). Every file is checked against its schema here; the
// site check (validateSite, relay entry 54) then checks what the files say together, once the build
// knows every address. Each error names the file and says what to fix. A site with no
// site/ folder has no site data, and builds exactly as before from client.json and the reading
// templates.

import { DEFAULT_DRAWING, type Drawing } from './drawing.js';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import type { z } from 'zod';
import { issueLine, validateSite } from './validate.js';
import {
  collectionsSchema,
  lookSchema,
  navSchema,
  pageSchema,
  sharedSchema,
  siteFileSchema,
  templateSchema,
  type CollectionsFile,
  type LookFile,
  type NavFile,
  type PageFile,
  type SharedFile,
  type TemplateFile,
} from './schema.js';

export const SITE_DIR = 'site/';

export class SiteDataError extends Error {
  override name = 'SiteDataError';
}

export interface SiteData {
  pages: PageFile[];
  templates: Map<string, TemplateFile>;
  shared: SharedFile;
  nav: NavFile | null;
  look: LookFile | null;
  collections: CollectionsFile;
  locked: string[];
  /** Heliostet's own pages the site leaves out (relay entry 55). */
  without: ('status' | 'links')[];
  /** Whose share images the pages carry: Heliostet's, drawn at build, or the site's own (relay entry 55). */
  shareImages: 'heliostet' | 'own';
  /** How the parts draw stories: title case, bylines, card tags, satire, pictures (relay entry 59). */
  drawing: Drawing;
  /** A Show client's shows feed (relay entry 125), read at build. */
  shows?: { feed: string; headshots?: string | undefined; thumbs?: string | undefined } | undefined;
  /** The channel a video band reads its newest videos from (relay entry 125). */
  youtube?: { channelId: string; handle: string } | undefined;
  /** The site's own reading of a story (relay entry 125): its module's path from the site's root. */
  reading?: string | undefined;
  /** The footer's credit and legal line (relay entry 112). */
  footer?: { credit: 'made-with' | 'runs-on'; legal: string | null };
  /** Every file read, for the dev server to watch. */
  files: URL[];
}

function read<T extends z.ZodType>(file: URL, schema: T, root: URL): z.infer<T> {
  const where = fileURLToPath(file).slice(fileURLToPath(root).length).replace(/\\/g, '/');
  let json: unknown;
  try {
    json = JSON.parse(readFileSync(file, 'utf8'));
  } catch (error) {
    throw new SiteDataError(`${where} is not valid JSON: ${(error as Error).message}`);
  }
  const parsed = schema.safeParse(json);
  if (!parsed.success) {
    throw new SiteDataError(`${where} doesn't match its schema:\n${parsed.error.issues.map((i) => `  ${i.path.join('.') || '(the file)'}: ${i.message}`).join('\n')}`);
  }
  return parsed.data;
}

const jsonFiles = (dir: URL) => (existsSync(dir) ? readdirSync(dir).filter((f) => f.endsWith('.json')).sort() : []);

/** The site's data, checked; null when the site has no site/ folder. */
export function loadSiteData(root: URL): SiteData | null {
  const dir = new URL(SITE_DIR, root);
  if (!existsSync(dir)) return null;
  const files: URL[] = [];
  const optional = <T extends z.ZodType>(name: string, schema: T): z.infer<T> | null => {
    const file = new URL(name, dir);
    if (!existsSync(file)) return null;
    files.push(file);
    return read(file, schema, root);
  };
  const pages = jsonFiles(new URL('pages/', dir)).map((name) => {
    const file = new URL(`pages/${name}`, dir);
    files.push(file);
    const page = read(file, pageSchema, root);
    if (`${page.id}.json` !== name) throw new SiteDataError(`site/pages/${name} has the id “${page.id}”; a page file is named for its id.`);
    // A hidden row is kept in the file for later, and left out of the page (relay entry 91).
    return { ...page, rows: page.rows.filter((r) => !r.hidden) };
  });
  const templates = new Map(
    jsonFiles(new URL('templates/', dir)).map((name) => {
      const file = new URL(`templates/${name}`, dir);
      files.push(file);
      return [name.replace(/\.json$/, ''), read(file, templateSchema, root)] as const;
    }),
  );
  const siteFile = optional('site.json', siteFileSchema);
  const data: SiteData = {
    pages,
    templates,
    shared: optional('shared.json', sharedSchema) ?? { parts: [] },
    nav: optional('nav.json', navSchema),
    look: optional('look.json', lookSchema),
    collections: optional('collections.json', collectionsSchema) ?? {},
    locked: siteFile?.locked ?? [],
    without: siteFile?.without ?? [],
    shareImages: siteFile?.shareImages ?? 'heliostet',
    footer: { credit: siteFile?.footer?.credit ?? 'made-with', legal: siteFile?.footer?.legal ?? null },
    drawing: siteFile ? { titles: siteFile.titles, titleWords: siteFile.titleWords, bylines: siteFile.bylines, cardTags: siteFile.cardTags, satire: siteFile.satire, imageResizing: siteFile.imageResizing, people: siteFile.people } : DEFAULT_DRAWING,
    files,
    shows: siteFile?.shows,
    youtube: siteFile?.youtube,
    reading: siteFile?.reading,
  };
  return data;
}

/** What the files disagree about, as one error naming every problem: validateSite with what the files alone can say. */
export function checkSiteData(data: SiteData): void {
  const { errors } = validateSite({ pages: data.pages, templates: data.templates, shared: data.shared, nav: null, collections: data.collections, locked: data.locked });
  if (errors.length) throw new SiteDataError(`The site’s pages don’t check out:\n${errors.map((e) => `  ${issueLine(e)}`).join('\n')}`);
}
