// The build data the integration serves to the templates (src/index.ts).
declare module 'virtual:vellumandvolt/site' {
  export const site: import('./config/site.js').SiteConfig;
  /** The one stylesheet, inline in every page's head (PAGE-6). */
  export const css: string;
  /** Heliostet's stylesheet, inline in the head of the tool pages only (the status page). */
  export const toolCss: string;
}
declare module 'virtual:vellumandvolt/pages' {
  export const resolved: import('./build/resolve.js').Resolved;
  /** Top-level pages (PAGE-7), rendered. */
  export const pages: import('./build/markdown.js').RenderedPage[];
  /** The About copy, rendered; empty when the site has none. */
  export const about: import('./build/sanitize.js').SafeHtml;
}

declare module 'virtual:vellumandvolt/gallery' {
  /** The parts gallery's looks (relay entry 52): each one's token layer, set after the site's own; the site's look is empty. */
  export const looks: Record<string, string>;
  /** The parts' stylesheet, while the gallery is on. */
  export const partsCss: string;
}

declare module 'virtual:vellumandvolt/site-data' {
  type Rows = import('./site/layout.js').LayoutRow<import('./parts/types.js').Part & { id: string; bind?: 'item' }>[];
  /** A page made of parts, from site/pages/ (relay entry 53), with its shared parts in place. */
  export interface SitePageData {
    address: string;
    title: string;
    eyebrow?: string;
    intro?: string;
    header: 'page' | 'hello' | 'part';
    seo?: { title?: string; description?: string; shareImage?: string; noindex?: boolean; graph?: 'website' | 'about' | 'page'; type?: 'website' | 'profile' | 'article' };
    frame?: 'parts' | 'stack' | 'article' | 'article-prose' | 'none';
    frameOptions?: Record<string, string | number | boolean>;
    paginate?: { part: string };
    rows: Rows;
  }
  /** One item of a collection, with its template's rows and its bound fields. */
  export interface SiteEntryData {
    collection: 'stories' | 'chapters' | 'videos';
    address: string;
    params: Record<string, string>;
    title: string;
    description: string;
    fields: Record<string, unknown>;
    frame?: 'parts' | 'stack' | 'article' | 'article-prose' | 'none';
    frameOptions?: Record<string, string | number | boolean>;
    rows: Rows;
  }
  export const sitePages: SitePageData[];
  export const entries: SiteEntryData[];
  export const ctx: import('./parts/types.js').PartContext;
  /** The parts' and the rows' stylesheet, inline on every page made of parts. */
  export const pageCss: string;
}

declare module 'virtual:vellumandvolt/own' {
  /**
   * The site's own frame (decision 0019): the page around the parts, with its head, masthead, and
   * footer, drawn by the site's component; null when the site uses Heliostet's.
   */
  export const OwnFrame: ((props: import('./site/own.js').OwnFrameProps) => unknown) | null;
  /** The site's own variants of Heliostet's parts, by "type:variant". */
  export const ownVariants: Record<string, (props: Record<string, unknown>) => unknown>;
}

declare module 'virtual:vellumandvolt/reading' {
  /** The site's own reading of a story (relay entry 125), from the module site.json names; null when it names none. */
  export const reading: import('./parts/types.js').ReadStory | null;
}

declare module 'wawoff2' {
  const wawoff2: { decompress(input: Uint8Array): Promise<Uint8Array> };
  export default wawoff2;
}
