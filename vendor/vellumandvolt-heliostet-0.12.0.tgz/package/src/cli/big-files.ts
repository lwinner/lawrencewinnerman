// heliostet-big-files dist: at deploy, after the build (relay entry 91), each file in dist/files/ over 25 MiB goes into
// the site's own R2 bucket, named in wrangler.toml, and out of dist, so the static assets stay under their limit and the
// site's Worker serves it from the bucket. With no bucket, a file that big stops the deploy, named.
import { execFileSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync, rmSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { BigFileError, filesBucket, filesBucketJsonc, planBigFiles } from '../build/big-files.js';

const dist = process.argv[2] ?? 'dist';
try {
  const dir = join(dist, 'files');
  const files = existsSync(dir) ? readdirSync(dir).map((name) => ({ path: `files/${name}`, bytes: statSync(join(dir, name)).size })) : [];
  const bucket = existsSync('wrangler.toml') ? filesBucket(readFileSync('wrangler.toml', 'utf8')) : existsSync('wrangler.jsonc') ? filesBucketJsonc(readFileSync('wrangler.jsonc', 'utf8')) : null;
  const plan = planBigFiles(files, bucket);
  for (const f of plan) {
    // pnpm's own sites run it through pnpm; an npm site (the Press) through npx.
    const viaPnpm = /^pnpm\//.test(process.env.npm_config_user_agent ?? '');
    execFileSync(viaPnpm ? 'pnpm' : 'npx', [...(viaPnpm ? ['exec'] : []), 'wrangler', 'r2', 'object', 'put', `${bucket}/${f.key}`, '--file', join(dist, f.path), '--remote'], { stdio: 'inherit', shell: process.platform === 'win32' });
    rmSync(join(dist, f.path));
  }
  console.log(plan.length ? `Put ${plan.length} ${plan.length === 1 ? 'file' : 'files'} over 25 MB in the site's file bucket: ${plan.map((f) => f.key).join(', ')}.` : 'No file over 25 MB; nothing for the file bucket.');
} catch (error) {
  if (error instanceof BigFileError) {
    console.error(`::error title=A file too big for the site::${error.message}`);
    process.exit(1);
  }
  throw error;
}
